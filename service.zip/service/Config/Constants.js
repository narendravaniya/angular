module.exports = {
	ATTENDY_TYPE: {
		EMPLOYEE	: 1,
		VISITOR		: 2
	},
	PLATFORM: {
		WEB		: 1,
		MOBILE	: 2,
		TABLET	: 3,
		GOOGLE	: 4,
		OFFICE	: 5
	},
	MEETING: {
		AVAILABLE	: 1,
		IN_PROGRESS	: 2,
		COMPLETED	: 3,
		CANCELLED	: 4
	}
}
