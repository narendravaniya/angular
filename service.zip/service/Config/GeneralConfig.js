require('dotenv').config();
var config = require('./Database');
var azure = require('azure');
var connectionString = process.env.SERVICE_BUS_CONNECTION_STRING;
var serviceBusService = azure.createServiceBusService(connectionString);
var lodash = require('lodash');
var IotSync = require('./IotSync');
var iotSync = new IotSync();

var Authenticate = require('../Config/Authenticate');
authenticate = new Authenticate();

var topics = {
	SMART_OFFICE_TOPIC: "fleet" + process.env.ENVIRONMENT
};

var subscribers = {
	SMART_OFFICE: "fleet"
};

function getDateTimeUTC(date = "") {
	date = (date != '') ? new Date(date) : new Date();
	newDate = date.toISOString().replace(/T/, ' ').replace(/\..+/, '');
	return newDate;
}

function getUserInfo(req) {
	if (req.headers.authorization) {
		var accessToken = req.headers.authorization.split(" ")[1];
		if (accessToken && accessToken !== 'null') {
			var obj = authenticate.decode(accessToken);
			return obj.user;
		} else {
			return {
				userId: '',
			};
		}
	} else {
		return {
			userId: '',
		};
	}
}

function generateGUID() {
	function s4() {
		return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
	}
	return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
}

var getSubscribeData = function () {
	subscriptionData(topics.SMART_OFFICE_TOPIC)
};

function subscriptionData(topicName) {
	try {
		serviceBusService.createTopicIfNotExists(topicName, function (error, res) {
			if (!error) {
				serviceBusService.getSubscription(topicName, subscribers.SMART_OFFICE, function (error, res) {
					if (lodash.isNull(res) || lodash.isNull(res.SubscriptionName) || lodash.isUndefined(res.SubscriptionName) || lodash.isEmpty(res.SubscriptionName)) {
						serviceBusService.createSubscription(topicName, subscribers.SMART_OFFICE, function (error) {
							if (!error) {
								serviceBusService.receiveSubscriptionMessage(topicName, subscribers.SMART_OFFICE, receivedMessageHandler);
							}
						});
					} else {
						serviceBusService.receiveSubscriptionMessage(topicName, subscribers.SMART_OFFICE, receivedMessageHandler);
					}
				})
			} else {
				console.log('Error in subscriptionData : ', error);
			}
		});
	} catch (e) {
		console.log('Catch error in subscriptionData : ', e);
	}
}

var receivedMessageHandler = function (err, receivedMessage) {
	if (receivedMessage) {
		subscribeDataOperation(JSON.parse(receivedMessage.body));
	}
	serviceBusService.receiveSubscriptionMessage(topics.SMART_OFFICE_TOPIC, subscribers.SMART_OFFICE, receivedMessageHandler);
};

function subscribeDataOperation(res) {
	try {
		iotSync.syncData(res);
	}
	catch (e) {
		console.log("err catch................", e.message);
	}
}

module.exports = {
	getUserInfo: getUserInfo,
	getDateTimeUTC: getDateTimeUTC,
	generateGUID: generateGUID,
	getSubscribeData: getSubscribeData,
	subscriptionData: subscriptionData,
	subscribeDataOperation: subscribeDataOperation
};