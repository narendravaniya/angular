const Sequelize = require('sequelize');

require('dotenv').config();
var modelsDir = {
	path 		: __dirname + '/../Models',
	master_path : __dirname + '/../Models'
};

var environment = 'qa';
var mqttClient 	= 'mqtt://52.170.198.117';
var mqttOption 	= {
	username	: "SO_QA:qapublisher",
	password	: "softweb#123",
	clean		: false
};
var databases 	= {
	path		: {
		path	: __dirname + '/../Models',
	},
	master_path	: {
		path	: __dirname + '/../Models'
	}
};

var connection = new Sequelize(
	process.env.MASTER_DATABASE_NAME,
    process.env.MASTER_DATABASE_USERNAME,
    process.env.MASTER_DATABASE_PASSWORD,
	{
		host: process.env.MASTER_DATABASE_HOST,
        port: process.env.DB_PORT,
        dialect: process.env.MASTER_DATABASE_CONNECTION,
        logging: false,
		timezone: 'Etc/GMT'
	}
);

connection.authenticate().then(() => {
  	console.log("Connected to Database  :)");
}).catch((err) => {
  	console.log("Failed to connect to Database ");
});

global.database 	= connection;
global.Sequelize 	= Sequelize;

require('../Schema/Company');
require('../Schema/Roles');
require('../Schema/Users');
require('../Schema/Drivers');
require('../Schema/DevicesStatusLog');
require('../Schema/CompanyUsers');
require('../Schema/Devices');
require('../Schema/DeviceTemplate');
require('../Schema/Notifications');
require('../Schema/Trips');

module.exports = {
    databases		: databases,
    environment		: environment,
    master_db 		: connection,
	modelsDir 		: modelsDir,
    mqttClient 		: mqttClient,
    mqttOption		: mqttOption,
};