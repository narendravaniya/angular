var jwt = require('jsonwebtoken');
var privateKey = ']_JhC!ARh+w~T`t45i&Ml-H]nmJAPE';

class Authenticate {
	encode(data) {
		var token = jwt.sign({ data: data }, privateKey, { algorithm: 'HS256'});
		return token;
	}

	verifyToken(token, callback) {
		jwt.verify(token, privateKey, { algorithms: ['HS256'] }, function (err, payload) {
			if (err) {
				callback(false, err);
			} else {
				callback(true, payload);
			}
		});
	}

	decode(token) {
		var decoded = jwt.decode(token, { complete: true });
		return decoded.payload;
	}
}

module.exports = Authenticate;