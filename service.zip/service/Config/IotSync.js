var companySchema = require('../Schema/Company');
var CompanyUserSchema = require('../Schema/CompanyUsers');
var userSchema = require('../Schema/Users');
var roleSchema = require('../Schema/Roles');
var deviceTemplateSchema = require('../Schema/DeviceTemplate');
var deviceSchema = require('../Schema/Devices');

class IotSync {
	syncData(res) {
		var msgType = res.msgType;
		var action = res.action;
		console.log("===============================================================================")
		console.log("TCL: IotSync -> syncData -> msgType", msgType)
		console.log("TCL: IotSync -> syncData -> action", action)
		console.log("TCL: IotSync -> syncData -> res", res)
		var companyGuid = res.company.toUpperCase();
		console.log("===============================================================================")

		if (msgType === "company") {
			var data = res.data.item;
			companySchema.findAll({
				where: {
					company_id: companyGuid.toUpperCase()
				}
			}).then(company => {
				var reqData = {
					company_id: data.guid.toUpperCase(),
					cpid: data.cpId.toUpperCase(),
					company_name: data.name,
					status: 1
				}
				if (company.length === 0) {
					companySchema.create(reqData).then(companyData => {
						console.log("Company has been added successfully.")
					}).catch(error => {
						console.log("Add error", error)
					})
				} else {
					companySchema.update(reqData, {
						where: {
							company_id: data.guid.toUpperCase()
						}
					}).then(companyData => {
						console.log("Company has been updated successfully.")
					}).catch(error => {
						console.log("Update error", error)
					})
				}
			});
		} else if (msgType === "role") {
			var data = res.data.item;
			roleSchema.findAll({
				where: {
					role_id: data.guid.toUpperCase()
				}
			}).then(role => {
				var reqData = {
					role_id: data.guid.toUpperCase(),
					role_name: data.name,
					description: data.description,
					status: data.isActive,
					isDeleted: data.isDeleted,
					company_id: companyGuid,
					status: 1
				}
				if (role.length === 0) {
					roleSchema.create(reqData).then(roleData => {
						console.log("Role has been added successfully.")
					}).catch(error => {
						console.log("Add error", error)
					})
				} else {
					roleSchema.update(reqData, {
						where: {
							role_id: data.guid.toUpperCase()
						}
					}).then(roleData => {
						console.log("Role has been updated successfully.")
					}).catch(error => {
						console.log("Update error", error)
					})
				}
			});
		} else if (msgType === "user") {
			var data = res.data.item;
			userSchema.findAll({
				where: {
					user_id: data.guid.toUpperCase()
				}
			}).then(user => {
				var data = res.data.item;
				if (action === 'delete') {
					if (user.length > 0) {
						var deleteReqData = {
							user_id: data.guid.toUpperCase(),
							isDeleted: 1
						};
						CompanyUserSchema.update(deleteReqData, {
							where: {
								user_id: data.guid.toUpperCase()
							}
						}).then(companyData => {
							console.log("Company has been deleted successfully.")
						}).catch(error => {
							console.log("Update error", error)
						})
					}
				} else {
					var userReqData = {
						user_id: data.guid.toUpperCase(),
						first_name: data.firstname,
						last_name: data.lastname,
						email: data.userid,
						timezone: data.timezoneGuid.toUpperCase(),
						phone_number: data.contactNo,
						status: 1
					};
					if (user.length === 0) {
						userSchema.create(userReqData).then(userData => {
							console.log("User has been added successfully.")
						}).catch(error => {
							console.log("Add User error", error)
						});

						var companyUserReqData = {
							user_id: data.guid.toUpperCase(),
							company_id: companyGuid.toUpperCase(),
							user_type: data.roleguid.toUpperCase(),
							isDeleted: 0,
							status: 1
						};
						CompanyUserSchema.create(companyUserReqData).then(userData => {
							console.log("CompanyUser has been added successfully.")
						}).catch(error => {
							console.log("Add CompanyUser error", error)
						});
					} else {
						userSchema.update(userReqData, {
							where: {
								user_id: data.guid.toUpperCase()
							}
						}).then(userData => {
							console.log("User has been updated successfully.")
						}).catch(error => {
							console.log("Update error", error)
						})
					}
				}
			});
		} else if (msgType === "template") {
			var data = res.data.item;
			deviceTemplateSchema.findAll({
				where: {
					device_template_id: data.guid.toUpperCase()
				}
			}).then(role => {
				var reqData = {
					device_template_id: data.guid.toUpperCase(),
					name: data.name,
					code: data.code,
					firmwareGuid: data.firmware_guid,
					company_id: companyGuid,
					isDeleted: data.isDeleted
				}
				if (role.length === 0) {
					deviceTemplateSchema.create(reqData).then(templateData => {
						console.log("Template has been added successfully.")
					}).catch(error => {
						console.log("Add error", error)
					})
				} else {
					deviceTemplateSchema.update(reqData, {
						where: {
							device_template_id: data.guid.toUpperCase()
						}
					}).then(templateData => {
						console.log("Template has been updated successfully.")
					}).catch(error => {
						console.log("Update error", error)
					})
				}
			});
		} else if (msgType === "device") {
			var data = res.data.items;
			deviceSchema.findAll({
				where: {
					device_id: data[0].item.guid.toUpperCase()
				}
			}).then(deviceData => {
				var reqData = {
					device_id: data[0].item.guid.toUpperCase(),
					uniqueId: data[0].item.uniqueId,
					displayName: data[0].item.displayName,
					space_id: data[0].item.entityGuid.toUpperCase(),
					device_template_id: data[0].item.deviceTemplateGuid.toUpperCase(),
					status: data[0].item.isActive,
					isDeleted: data[0].item.isDeleted,
					note: data[0].item.note
				}
				console.log("TCL: IotSync -> syncData -> reqData", reqData)
				if (deviceData.length === 0) {
					reqData['type'] = 1;
					deviceSchema.create(reqData).then(deviceResponseData => {
						console.log("Device has been added successfully.")
					}).catch(error => {
						console.log("Add error", error)
					})
				} else {
					deviceSchema.update(reqData, {
						where: {
							device_id: data[0].item.guid.toUpperCase()
						}
					}).then(deviceResponseData => {
						console.log("Device has been updated successfully.")
					}).catch(error => {
						console.log("Update error", error)
					})
				}
			});
		}
	}
}

module.exports = IotSync