const generateUuid = require('uuid/v4');

var Notifications = database.define('Notifications', {
	notification_id: {
		primaryKey: true,
		type: Sequelize.UUID,
		defaultValue: function () {
			return generateUuid().toUpperCase()
		}
	},
	message:Sequelize.STRING(),
	date:Sequelize.STRING(),
	severity_level:Sequelize.INTEGER(1),
	category_level:Sequelize.INTEGER(1),
}, {
		underscored: true
	}
);

Notifications.sync({
	logging: false
});

var defaultRecords = [{
	message: "Truck Breakdown",
	severity_level: 1,
	category_level: 3,
	date: "2019-08-10",
},
{
	message: "Heavy Traffic",
	severity_level: 2,
	category_level: 2,
	date: "2019-08-12",
},
{
	message: "Truck Delivery Overdue",
	severity_level: 3,
	category_level: 3,
	date: "2019-08-11",
},
{
	message: "Storm Warning On Route",
	severity_level: 2,
	category_level: 1,
	date: "2019-08-10",
},
{
	message: "Driver 6hr Rest Period Violation",
	severity_level: 1,
	category_level: 2,
	date: "2019-08-15",
},
{
	message: "Truck Breakdown",
	severity_level: 2,
	category_level: 3,
	date: "2019-08-19",
},
{
	message: "Heavy Traffic",
	severity_level: 3,
	category_level: 2,
	date: "2019-09-05",
},
{
	message: "Truck Delivery Overdue",
	severity_level: 1,
	category_level: 3,
	date: "2019-09-01",
},
{
	message: "Storm Warning On Route",
	severity_level: 3,
	category_level: 1,
	date: "2019-08-30",
},
{
	message: "Driver 6hr Rest Period Violation",
	severity_level: 3,
	category_level: 2,
	date: "2019-09-06",
},
{
	message: "Truck Breakdown",
	severity_level: 1,
	category_level: 2,
	date: "2019-09-10",
},
{
	message: "Heavy Traffic",
	severity_level: 2,
	category_level: 3,
	date: "2019-09-09",
},
{
	message: "Truck Delivery Overdue",
	severity_level: 3,
	category_level: 2,
	date: "2019-08-19",
},
{
	message: "Storm Warning On Route",
	severity_level: 1,
	category_level: 3,
	date: "2019-08-20",
},
{
	message: "Driver 6hr Rest Period Violation",
	severity_level: 2,
	category_level: 1,
	date: "2019-08-25",
},
{
	message: "Truck Breakdown",
	severity_level: 2,
	category_level: 2,
	date: "2019-08-24",
}
];

Notifications.findAll().then(notificationsData => {
	if (notificationsData.length === 0) {
		Notifications.bulkCreate(defaultRecords).then(spaceTypesResponse => {
			console.log("Default notifications has been added into database.");
		});
	}
});
module.exports = Notifications;