const generateUuid = require('uuid/v4');

var Roles = database.define('Roles', {
	role_id: {
		primaryKey: true,
		type: Sequelize.UUID,
		defaultValue: function () {
			return generateUuid().toUpperCase()
		}
	},
	role_name: Sequelize.STRING(50),
	company_id: Sequelize.UUID,
	description: Sequelize.TEXT,
	status: Sequelize.INTEGER(1),
	isDeleted: Sequelize.INTEGER(1)
}, {
		underscored: true
	}
);

var Company = require('./Company');
Roles.belongsTo(Company, {
	foreignKey: 'company_id'
});

Company.hasMany(Roles, {
	foreignKey: 'company_id'
});

Roles.sync({
	logging: false
});
module.exports = Roles;