const generateUuid = require('uuid/v4');

var Drivers = database.define('Drivers', {
	driver_id: {
		primaryKey: true,
		type: Sequelize.UUID,
		defaultValue: function () {
			return generateUuid().toUpperCase()
		}
	},
	first_name: Sequelize.STRING,
	last_name: Sequelize.STRING,
	email: Sequelize.STRING(50),
	phone_number: Sequelize.STRING(20),
	address: Sequelize.STRING,
	company_id: Sequelize.UUID,
	device_id: {
		type: Sequelize.UUID,
		allowNull: false,
		unique: true
	},
	country_guid: Sequelize.STRING,
	state_guid: Sequelize.STRING,
	city: Sequelize.STRING,
	zip_code: Sequelize.STRING,
	image: Sequelize.STRING,
	status: {
		type: Sequelize.STRING(1),
		defaultValue: 1
	}
}, {
	underscored: true
}
);

var Company = require('./Company');
Drivers.belongsTo(Company, {
	foreignKey: 'company_id'
});

Company.hasMany(Drivers, {
	foreignKey: 'company_id'
});

var Device = require('./Devices');
Drivers.belongsTo(Device, {
	foreignKey: 'device_id'
});

Device.hasOne(Drivers, {
	foreignKey: 'device_id'
});

Drivers.sync({
	logging: false
});

module.exports = Drivers;