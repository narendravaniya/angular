const generateUuid = require('uuid/v4');

var CompanyUsers = database.define('CompanyUsers', {
	company_user_id: {
		primaryKey: true,
		type: Sequelize.UUID,
		defaultValue: function () {
			return generateUuid().toUpperCase()
		}
	},
	user_id: Sequelize.UUID,
	company_id: Sequelize.UUID,
	user_type: Sequelize.UUID,
	isDeleted: {
		type: Sequelize.INTEGER(4),
		defaultValue: 0
	},
	status: {
		type: Sequelize.INTEGER(4),
		defaultValue: 1
	},
	deleted_at: Sequelize.DATE
}, {
		underscored: true
	}
);

var Users = require('./Users');
CompanyUsers.belongsTo(Users, {
	foreignKey: 'user_id'
});

Users.hasOne(CompanyUsers, {
	foreignKey: 'user_id'
});

var Roles = require('./Roles');
CompanyUsers.belongsTo(Roles, {
	foreignKey: 'user_type'
});

Roles.hasOne(CompanyUsers, {
	foreignKey: 'user_type'
});

var Company = require('./Company');
CompanyUsers.belongsTo(Company, {
	foreignKey: 'company_id'
});

Company.hasMany(CompanyUsers, {
	foreignKey: 'company_id'
});

CompanyUsers.sync({
	logging: false
});
module.exports = CompanyUsers;