const generateUuid = require('uuid/v4');

var Company = database.define('Company', {
	company_id: {
		primaryKey: true,
		type: Sequelize.UUID,
		defaultValue: function () {
			return generateUuid().toUpperCase()
		}
	},
	cpid: Sequelize.STRING,
	company_name: Sequelize.STRING,
	company_email: Sequelize.STRING,
	company_address1: Sequelize.STRING,
	company_address2: Sequelize.STRING,
	company_city: Sequelize.STRING,
	company_state: Sequelize.STRING,
	company_zip: Sequelize.STRING,
	company_phone: Sequelize.STRING,
	company_logo: Sequelize.STRING,
	company_domain_prefix: Sequelize.STRING,
	company_db_name: Sequelize.STRING,
	timezone: Sequelize.STRING,
	time_difference: Sequelize.STRING,
	status: Sequelize.INTEGER
}, {
		underscored: true
	}
);

Company.sync({
	logging: false
});
module.exports = Company;