var Trips = database.define('Trips', {
	trip_id: {
		primaryKey: true,
		autoIncrement: true,
		type: Sequelize.INTEGER,
	},
	device_id: Sequelize.UUID,
	from:Sequelize.STRING,
	to:Sequelize.STRING,
	start_time: Sequelize.STRING,
	end_time: Sequelize.STRING,
	eta:Sequelize.STRING,
	total_miles:Sequelize.INTEGER(6),
	completed_miles:Sequelize.INTEGER(6),
	actual_start_time: Sequelize.STRING,
	actual_end_time: Sequelize.STRING,
	fromLat:Sequelize.STRING,
	fromLng:Sequelize.STRING,
	toLat:Sequelize.STRING,
	toLng:Sequelize.STRING,
	currentLat:Sequelize.STRING,
	currentLng:Sequelize.STRING,
	status: {
		type: Sequelize.INTEGER(4),
		defaultValue: 1
	}
}, {
		underscored: true
	}
);

var Devices = require('./Devices');
Trips.belongsTo(Devices, {
	foreignKey: 'device_id'
});
Devices.hasMany(Trips, {
	foreignKey: 'device_id'
});

Trips.sync({
	logging: false
});

module.exports = Trips;