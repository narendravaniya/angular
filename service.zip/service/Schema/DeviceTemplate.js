const generateUuid = require('uuid/v4');

var DeviceTemplate = database.define('DeviceTemplate', {
	device_template_id: {
		primaryKey: true,
		type: Sequelize.UUID,
		defaultValue: function () {
			return generateUuid().toUpperCase()
		}
	},
	code: Sequelize.STRING(50),
	name: Sequelize.STRING(100),
	firmwareGuid: Sequelize.UUID,
	company_id: Sequelize.UUID,
	isDeleted: Sequelize.INTEGER(4),
	hasAttribute: Sequelize.INTEGER(4)
}, {
		underscored: true
	}
);

var Company = require('./Company');
DeviceTemplate.belongsTo(Company, {
	foreignKey: 'company_id'
});

Company.hasOne(DeviceTemplate, {
	foreignKey: 'company_id'
});

DeviceTemplate.sync({
	logging: false
});

module.exports = DeviceTemplate;