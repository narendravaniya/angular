const generateUuid = require('uuid/v4');

var Devices = database.define('Devices', {
	device_id: {
		primaryKey: true,
		type: Sequelize.UUID,
		defaultValue: function () {
			return generateUuid().toUpperCase()
		}
	},
	uniqueId: Sequelize.UUID,
	displayName: Sequelize.STRING(100),
	device_template_id: Sequelize.UUID,
	image: Sequelize.STRING,
	type: Sequelize.INTEGER(1),
	status: Sequelize.INTEGER(1),
	isDeleted: Sequelize.INTEGER(1),
	note: Sequelize.TEXT
}, {
		underscored: true
	}
);

var DeviceTemplate = require('./DeviceTemplate');
Devices.belongsTo(DeviceTemplate, {
	foreignKey: 'device_template_id',
});

DeviceTemplate.hasMany(Devices, {
	foreignKey: 'device_template_id'
});

Devices.sync({
	logging: false
});
module.exports = Devices;