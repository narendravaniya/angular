const generateUuid = require('uuid/v4');

var Users = database.define('Users', {
	user_id: {
		primaryKey: true,
		type: Sequelize.UUID,
		defaultValue: function () {
			return generateUuid().toUpperCase()
		}
	},
	first_name: Sequelize.STRING,
	last_name: Sequelize.STRING,
	email: Sequelize.STRING(50),
	phone_number: Sequelize.STRING(20),
	profile_picture: Sequelize.STRING,
	timezone: Sequelize.STRING,
	zip: Sequelize.STRING(11),
	address: Sequelize.STRING,
	country_guid: Sequelize.UUID,
	qrCode: Sequelize.TEXT,
	status: {
		type: Sequelize.INTEGER(4),
		defaultValue: 1
	}
}, {
		underscored: true
	}
);

Users.sync({
	logging: false
});

module.exports = Users;