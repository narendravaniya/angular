const generateUuid = require('uuid/v4');

var DevicesStatusLog = database.define('DevicesStatusLog', {
	device_status_id: {
		primaryKey: true,
		type: Sequelize.UUID,
		defaultValue: function () {
			return generateUuid().toUpperCase()
		}
	},
	device_id: Sequelize.UUID,
	uniqueId: Sequelize.UUID,
	displayName: Sequelize.STRING,
	status: Sequelize.INTEGER(1),
	date: Sequelize.STRING(100),
}, {
	underscored: true
});

DevicesStatusLog.sync({
	logging: false
});

module.exports = DevicesStatusLog;