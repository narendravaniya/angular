//SERVER CONFIG
var express = require('express');
var cors = require('cors');
var fs = require('fs');
var http = require('http');
var https = require('https');
var app = express();
var credentials = {
	key: fs.existsSync('./Config/ssl-certificate/private_key.key') ? fs.readFileSync('./Config/ssl-certificate/private_key.key') : '',
	cert: fs.existsSync('./Config/ssl-certificate/8b428f6e4aad06d3.crt') ? fs.readFileSync('./Config/ssl-certificate/8b428f6e4aad06d3.crt') : '',
	ca: fs.existsSync('./Config/ssl-certificate/gd_bundle-g2-g1.crt') ? fs.readFileSync('./Config/ssl-certificate/gd_bundle-g2-g1.crt') : ''
};

require('dotenv').config()

var PORT = process.env.PORT || 3722;
var HTTPS_PORT = process.env.HTTPS_PORT || 3723;

var Authenticate = require('./Config/Authenticate');
authenticate = new Authenticate();

var generalConfig = require('./Config/GeneralConfig');

//PARSING POST REQUEST
var bodyParser = require('body-parser');

var cookieParser = require('cookie-parser');
app.use(cookieParser());

var session = require('express-session');
app.use(session({
	secret: 'BD7I4um/JuiAxgLkirV6KRT4FVaMq1cLxulaFB5hbC8=',
	resave: false,
	saveUninitialized: false
}));

app.use(cors());
app.use(bodyParser.urlencoded({ limit: "50mb", extended: true, parameterLimit: 50000 }));
app.use(bodyParser.json({ limit: "50mb" }));

app.use('/', function (req, res, next) {
	let requestsToByPass = ['/api/user/basic-token', '/api/user/login', '/api-docs/', '/api-docs/swagger-ui.css', '/api-docs/swagger-ui-bundle.js', '/api-docs/swagger-ui-init.js', '/api-docs/swagger-ui-standalone-preset.js', '/api-docs/favicon-32x32.png', '/api-docs/favicon-16x16.png'];
	if (requestsToByPass.indexOf(req.path) != -1) {
		next();
	} else {
		if (req.headers.authorization) {
			authenticate.verifyToken(req.headers.authorization.split(' ')[1], function (status, response) {
				if (status) {
					var decodeResponse = authenticate.decode(req.headers.authorization.split(' ')[1])
					req.headers.authorization = "Bearer " + decodeResponse.data;
					next();
				} else {
					res.status(500).json({
						status: 500,
						data: [],
						message: 'Malformed header.'
					});
				}
			})
		} else {
			res.status(500).json({
				status: 500,
				data: [],
				message: "Authentication failed"
			});
		}
	}
})

var expressValidator = require('express-validator');
app.use(expressValidator({
	customValidators: {
		isJason: function (value, filename) {
			var extension = (path.extname(filename)).toLowerCase();
			switch (extension) {
				case '.json':
					return true;
				default:
					return false;
			}
		}
	}
}));

app.use(function (req, res, next) {
	res.setHeader('Access-Control-Allow-Origin', '*');
	res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
	res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
	res.setHeader('Access-Control-Allow-Credentials', true);
	next();
});

// Swagger UI
var swaggerJsdoc = require('swagger-jsdoc');
var swaggerUi = require('swagger-ui-express');
var swaggerRoute = [
	'./Routes/User.js',
	'./Routes/Driver.js',
	'./Routes/Dashboard.js',
	'./Routes/Device.js',
	'./Routes/Trip.js',
];

var options = {
	swaggerDefinition: {
		info: {
			title: 'Fleet API',
			version: '1.0.0',
			description: 'Fleet Api documentation.',
		},
		components: {
			securitySchemes: {
				bearerAuth: {
					type: "http",
					scheme: "bearer",
					bearerFormat: "JWT"
				}
			}
		},
		openapi: "3.0.0",
	},
	apis: swaggerRoute,
};
var specs = swaggerJsdoc(options);
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(specs));

//STARTING SERVER
var httpsServer = https.createServer(credentials, app);
httpsServer.listen(HTTPS_PORT, function () {
	var runningPort = httpsServer.address().port;
	generalConfig.getSubscribeData();
	console.log("\n\nHTTPS Server started on : ", runningPort);
});

var httpServer = http.createServer(app);
var server = httpServer.listen(PORT, () => {
	var runningPort = server.address().port;
	generalConfig.getSubscribeData();
	console.log("HTTP Server started on : ", runningPort);
});
global.io = require('socket.io').listen(server);

// user Routes
var userRoutes = require('./Routes/User');
new userRoutes(app);

// Device Management  Routes
var deviceRoute = require('./Routes/Device');
new deviceRoute(app);

// Dashboard Routes
var dashboardRoutes = require('./Routes/Dashboard');
new dashboardRoutes(app);

// Driver Routes
var driverRoutes = require('./Routes/Driver');
new driverRoutes(app);

// Trip Routes
var tripsRoute = require('./Routes/Trip');
new tripsRoute(app);