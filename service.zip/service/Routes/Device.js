'use strict';
var multipart = require('connect-multiparty');
var multipartMiddleware = multipart();
var deviceController = require('../Controllers/Device');

module.exports = function (app) {
	/**
	 * @swagger
	 * /api/device/template/lookup:
	 *   get:
	 *     tags:
	 *       - Truck
	 *     name: Truck template list
	 *     summary: Get truck template list
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Truck template list get successfully
	 */
	app.get('/api/device/template/lookup', deviceController.getTemplateLookup);
	
	/**
	 * @swagger
	 * /api/device/lookup:
	 *   get:
	 *     tags:
	 *       - Truck
	 *     name: Truck loockup
	 *     summary: Get truck loockup
	  *     parameters:
	 *       - in: query
	 *         name: hasDriver
	 *         required: false
	 *         schema:
	 *           type: string
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Truck loockup get successfully
	 */
	app.get('/api/device/lookup/:hasDriver?', deviceController.getDeviceLookup);

	/**
	 * @swagger
	 * /api/device:
	 *   get:
	 *     tags:
	 *       - Truck
	 *     name: Truck list
	 *     summary: Get truck list
	 *     parameters:
	 *       - in: query
	 *         name: searchText
	 *         required: false
	 *         schema:
	 *           type: string
	 *       - in: query
	 *         name: sortBy
	 *         required: false
	 *         schema:
	 *           type: string
	 *       - in: query
	 *         name: pageSize
	 *         required: false
	 *         schema:
	 *           type: string
	 *       - in: query
	 *         name: pageNumber
	 *         required: false
	 *         schema:
	 *           type: string
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Truck list get successfully
	 */
	app.get('/api/device', deviceController.getList);

	/**
	 * @swagger
	 * /api/device:
	 *   post:
	 *     tags:
	 *       - Truck
	 *     name: Add Device
	 *     summary: add Device in system
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     requestBody:
	 *       required: true
	 *       content:
	 *         application/json:
	 *           schema:
	 *             type: object
	 *             properties:
	 *               display_name:
	 *                 type: string
	 *               unique_id:
	 *                 type: string
	 *               device_template_id:
	 *                 type: string
	 *               note:
	 *                 type: string
	 *               type:
	 *                 type: string
	 *             required:
	 *               - display_name
	 *               - unique_id
	 *               - device_template_id
	 *               - note
	 *               - type
	 *     responses:
	 *       200:
	 *         description: Device added successfully
	 */
	app.post('/api/device', deviceController.add);

	/**
	 * @swagger
	 * /api/device/{id}:
	 *   put:
	 *     tags:
	 *       - Truck
	 *     name: Edit Device
	 *     summary: Edit Device in system
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     parameters:
	 *       - in: path
	 *         name: id
	 *         required: true
	 *         schema:
	 *           type: string
	 *     requestBody:
	 *       required: true
	 *       content:
	 *         application/json:
	 *           schema:
	 *             type: object
	 *             properties:
	 *               display_name:
	 *                 type: string
	 *               note:
	 *                 type: string
	 *               type:
	 *                 type: string
	 *             required:
	 *               - display_name
	 *               - note
	 *               - type
	 *     responses:
	 *       200:
	 *         description: Device edited successfully
	 */
	app.put('/api/device/:id', deviceController.update);

	/**
	 * @swagger
	 * /api/device/{id}:
	 *   get:
	 *     tags:
	 *       - Truck
	 *     name: Edit Device
	 *     summary: Edit Device in system
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     parameters:
	 *       - in: path
	 *         name: id
	 *         required: true
	 *         schema:
	 *           type: string
	 *     responses:
	 *       200:
	 *         description: Device edited successfully
	 */
	app.get('/api/device/:id', deviceController.get);

	/**
	 * @swagger
	 * /api/device/{id}:
	 *   delete:
	 *     tags:
	 *       - Truck
	 *     name: Edit Device
	 *     summary: Edit Device in system
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     parameters:
	 *       - in: path
	 *         name: id
	 *         required: true
	 *         schema:
	 *           type: string
	 *     responses:
	 *       200:
	 *         description: Device deleted successfully
	 */
	app.delete('/api/device/:id', deviceController.delete);

	/**
	 * @swagger
	 * /api/device/{id}/status:
	 *   put:
	 *     tags:
	 *       - Truck
	 *     name: Change Device status
	 *     summary: Change Device status
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     parameters:
	 *       - in: path
	 *         name: id
	 *         required: true
	 *         schema:
	 *           type: string
	 *     requestBody:
	 *       required: true
	 *       content:
	 *         application/json:
	 *           schema:
	 *             type: object
	 *             properties:
	 *               status:
	 *                 type: string
	 *             required:
	 *               - status
	 *     responses:
	 *       200:
	 *         description: Device edited successfully
	 */
	app.put('/api/device/:id/status', deviceController.changeStatus);

	app.put('/api/device/:id/image', multipartMiddleware, deviceController.uploadImage);

	app.get('/api/truck/lookup', deviceController.getTruckLookup);
};