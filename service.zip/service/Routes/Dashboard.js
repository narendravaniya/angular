'use strict';
var dashboardController = require('../Controllers/Dashboard');

module.exports = function (app) {
	/**
	 * @swagger
	 * /api/dashboard/statistics:
	 *   get:
	 *     tags:
	 *       - Dashboard
	 *     name: Get dashboard statistics
	 *     summary: Get dashboard statistics
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Dashboard statistics loaded successfully
	 */
	app.get('/api/dashboard/statistics', dashboardController.getStatistics);

	/**
	 * @swagger
	 * /api/dashboard/notification:
	 *   get:
	 *     tags:
	 *       - Dashboard
	 *     name: Get notification statistics
	 *     summary: Get notification statistics
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Notification loaded successfully
	 */
	app.get('/api/dashboard/notification', dashboardController.getFleetNotification);

	/**
	 * @swagger
	 * /api/dashboard/getTruckUsage:
	 *   get:
	 *     tags:
	 *       - Dashboard
	 *     name: Get truck usage statistics
	 *     summary: Get truck usage statistics
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Truck usage loaded successfully
	 */
	app.get('/api/dashboard/getTruckUsage', dashboardController.getTruckUsage);

	/**
	 * @swagger
	 * /api/dashboard/getTruckActivity:
	 *   get:
	 *     tags:
	 *       - Dashboard
	 *     name: Get truck usage activity
	 *     summary: Get truck usage activity
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Truck activity loaded successfully
	 */
	app.get('/api/dashboard/getTruckActivity', dashboardController.getTruckActivity);

	/**
	 * @swagger
	 * /api/dashboard/getTruckGraph:
	 *   get:
	 *     tags:
	 *       - Dashboard
	 *     name: Get truck graph
	 *     summary: Get truck graph
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Truck graph loaded successfully
	 */
	app.get('/api/dashboard/getTruckGraph', dashboardController.getTruckGraph);

	/**
	 * @swagger
	 * /api/dashboard/getDeviceAttributes:
	 *   post:
	 *     tags:
	 *       - Dashboard
	 *     name: Get truck attribute
	 *     summary: Get truck attribute
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     requestBody:
	 *       required: true
	 *       content:
	 *         application/json:
	 *           schema:
	 *             type: object
	 *             properties:
	 *               device_id:
	 *                 type: string
	 *     responses:
	 *       200:
	 *         description: Truck attribute loaded successfully
	 */
	app.post('/api/dashboard/getDeviceAttributes', dashboardController.getDeviceAttributes);

	/**
	 * @swagger
	 * /api/dashboard/getStompConfiguration:
	 *   get:
	 *     tags:
	 *       - Dashboard
	 *     name: Get stomp configuration
	 *     summary: Get stomp configuration
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Get stomp configuration loaded successfully
	 */
	app.get('/api/dashboard/getStompConfiguration', dashboardController.getStompConfiguration);
	
	/**
	 * @swagger
	 * /api/dashboard/getDeviceAttributeHistoricalData:
	 *   post:
	 *     tags:
	 *       - Dashboard
	 *     name: Get stomp configuration
	 *     summary: Get stomp configuration
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     requestBody:
	 *       required: true
	 *       content:
	 *         application/json:
	 *           schema:
	 *             type: object
	 *             properties:
	 *               templateAttributeGuid:
	 *                 type: string
	 *               uniqueId:
	 *                 type: string
	 *               startDate:
	 *                 type: string
	 *               endDate:
	 *                 type: string
	 *     responses:
	 *       200:
	 *         description: Get stomp configuration loaded successfully
	 */
	app.post('/api/dashboard/getDeviceAttributeHistoricalData', dashboardController.getDeviceAttributeHistoricalData);
};