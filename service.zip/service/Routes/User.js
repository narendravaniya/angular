'use strict';
var multipart = require('connect-multiparty');
var multipartMiddleware = multipart();
var userController = require('../Controllers/User');
var authController = require('../Controllers/Auth');

module.exports = function (app) {
	/**
	 * @swagger
	 * /api/user/basic-token:
	 *   get:
	 *     tags:
	 *       - Auth
	 *     name: Basic Token
	 *     summary: Get basic token
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Basic token in successfully
	 */
	app.get('/api/user/basic-token', authController.getBasicToken);

	/**
	 * @swagger
	 * /api/user/login:
	 *   post:
	 *     tags:
	 *       - Auth
	 *     name: Login
	 *     summary: Log into system
	 *     consumes:
	 *       - application/json
	 *     requestBody:
	 *       required: true
	 *       content:
	 *         application/json:
	 *           schema:
	 *             type: object
	 *             properties:
	 *               username:
	 *                 type: string
	 *               password:
	 *                 type: string
	 *             required:
	 *               - username
	 *               - password
	 *     responses:
	 *       200:
	 *         description: User register in successfully
	 */
	app.post('/api/user/login', authController.login);

	/**
	 * @swagger
	 * /api/user/info:
	 *   get:
	 *     tags:
	 *       - Auth
	 *     name: User Info
	 *     summary: Get user info
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: User info in successfully
	 */
	app.get('/api/user/info', authController.getUserInfo);

	/**
	 * @swagger
	 * /api/companyInfo/{userId}:
	 *   get:
	 *     tags:
	 *       - Auth
	 *     name: Company Info
	 *     summary: Get company info
	 *     parameters:
	 *       - in: path
	 *         name: userId
	 *         required: true
	 *         schema:
	 *           type: string
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Company info in successfully
	 */
	app.get('/api/companyInfo/:userId', userController.getCompanyInfo);

	/**
	 * @swagger
	 * /api/role:
	 *   get:
	 *     tags:
	 *       - Auth
	 *     name: Role
	 *     summary: Get Role
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: User role in successfully
	 */
	app.get('/api/role', userController.getUserRole);

	/**
	 * @swagger
	 * /api/timezone:
	 *   get:
	 *     tags:
	 *       - Auth
	 *     name: Timezone
	 *     summary: Get Timezone
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Timezone in successfully
	 */
	app.get('/api/timezone', userController.getTimezone);
	
	/**
	 * @swagger
	 * /api/country:
	 *   get:
	 *     tags:
	 *       - Auth
	 *     name: Country
	 *     summary: Get Country
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Country in successfully
	 */
	app.get('/api/country', authController.getCountry);
	
	/**
	 * @swagger
	 * /api/country/{countryGuid}/state:
	 *   get:
	 *     tags:
	 *       - Auth
	 *     name: Get state
	 *     summary: Get state info
	 *     parameters:
	 *       - in: path
	 *         name: countryGuid
	 *         required: true
	 *         schema:
	 *           type: string
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: State info in successfully
	 */
	app.get('/api/country/:countryGuid/state', authController.getState);

	/**
	 * @swagger
	 * /api/entity:
	 *   get:
	 *     tags:
	 *       - Auth
	 *     name: Entity
	 *     summary: Get Entity
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Entity in successfully
	 */
	app.get('/api/entity', authController.getEntity);

	/**
	 * @swagger
	 * /api/user:
	 *   get:
	 *     tags:
	 *       - Auth
	 *     name: User
	 *     summary: Get User
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: User in successfully
	 */
	app.get('/api/user', userController.getUser);

	app.post('/api/user', userController.addUser);
	app.put('/api/user/:userGuid', userController.updateUser);
	app.get('/api/user/:userGuid', userController.getUserDetails);
	app.put('/api/user/:userGuid/image', multipartMiddleware, userController.uploadUserImage);
	app.get('/api/users/lookup', userController.getUserLookup);
	app.post('/api/user/resetPassword', userController.resetPassword);
	app.put('/api/user/:userGuid/status', userController.changeUserStatus);
	app.delete('/api/user/:userGuid', userController.deleteUser);
	app.post('/api/user/change-password', userController.changePassword);
};