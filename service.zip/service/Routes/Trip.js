'use strict';
var tripController = require('../Controllers/Trips');

module.exports = function (app) {
	/**
	 * @swagger
	 * /api/trip:
	 *   post:
	 *     tags:
	 *       - Trip
	 *     name: Add Trip
	 *     summary: add Trip in system
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     requestBody:
	 *       required: true
	 *       content:
	 *         application/json:
	 *           schema:
	 *             type: object
	 *             properties:
	 *               device_id:
	 *                 type: string
	 *               from:
	 *                 type: string
	 *               to:
	 *                 type: string
	 *               start_time:
	 *                 type: string
	 *               end_time:
	 *                 type: string
	 *               estimate_time:
	 *                 type: string
	 *               duration:
	 *                 type: string
	 *               total_miles:
	 *                 type: string
	 *             required:
	 *               - device_id
	 *               - from
	 *               - to
	 *               - start_time
	 *               - end_time
	 *               - estimate_time
	 *               - duration
	 *               - total_miles
	 *     responses:
	 *       200:
	 *         description: Trip added successfully
	 */
	app.post('/api/trip', tripController.add);

	/**
	 * @swagger
	 * /api/trip/{id}:
	 *   put:
	 *     tags:
	 *       - Trip
	 *     name: Edit Trip
	 *     summary: Edit Driver in system
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     parameters:
	 *       - in: path
	 *         name: id
	 *         required: true
	 *         schema:
	 *           type: string
	 *     requestBody:
	 *       required: true
	 *       content:
	 *         application/json:
	 *           schema:
	 *             type: object
	 *             properties:
	 *               device_id:
	 *                 type: string
	 *               from:
	 *                 type: string
	 *               to:
	 *                 type: string
	 *               start_time:
	 *                 type: string
	 *               end_time:
	 *                 type: string
	 *               estimate_time:
	 *                 type: string
	 *               duration:
	 *                 type: string
	 *               total_miles:
	 *                 type: string
	 *             required:
	 *               - device_id
	 *               - from
	 *               - to
	 *               - start_time
	 *               - end_time
	 *               - estimate_time
	 *               - duration
	 *               - total_miles
	 *     responses:
	 *       200:
	 *         description: Trip edited successfully
	 */
	app.put('/api/trip/:id', tripController.edit);

	/**
	 * @swagger
	 * /api/trip:
	 *   get:
	 *     tags:
	 *       - Trip
	 *     name: Trip List
	 *     summary: Get Trip List
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Trip List get successfully
	 */
	app.get('/api/trips', tripController.get);

	/**
	 * @swagger
	 * /api/trip/{id}:
	 *   get:
	 *     tags:
	 *       - Trip
	 *     name: Trip Details
	 *     summary: Get Trip Details
	 *     parameters:
	 *       - in: path
	 *         name: id
	 *         required: true
	 *         schema:
	 *           type: string
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Trip Details get successfully
	 */
	app.get('/api/trip/:id', tripController.getDetails);

	/**
	 * @swagger
	 * /api/trip/{id}:
	 *   delete:
	 *     tags:
	 *       - Trip
	 *     name: Delete Trip
	 *     summary: Delete Trip
	 *     parameters:
	 *       - in: path
	 *         name: id
	 *         required: true
	 *         schema:
	 *           type: string
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Trip deleted successfully
	 */
	app.delete('/api/trip/:id', tripController.delete);

	/**
	 * @swagger
	 * /api/trip/{id}/status:
	 *   put:
	 *     tags:
	 *       - Trip
	 *     name: Edit Trip
	 *     summary: Edit Trip status in system
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     parameters:
	 *       - in: path
	 *         name: id
	 *         required: true
	 *         schema:
	 *           type: string
	 *     requestBody:
	 *       required: true
	 *       content:
	 *         application/json:
	 *           schema:
	 *             type: object
	 *             properties:
	 *               status:
	 *                 type: number
	 *             required:
	 *               - status
	 *     responses:
	 *       200:
	 *         description: Trip status updated successfully
	 */
	app.put('/api/trip/:id/status', tripController.updateStatus);
	
	/**
	 * @swagger
	 * /api/trip/startSimulator/{id}/{isSalesTemplate}:
	 *   get:
	 *     tags:
	 *       - Trip
	 *     name: Start Simulator
	 *     summary: Start Simulator for device
	 *     security:
	 *       - bearerAuth: []
	 *     parameters:
	 *       - in: path
	 *         name: id
	 *         required: true
	 *         schema:
	 *           type: string
	 *       - in: path
	 *         name: isSalesTemplate
	 *         required: true
	 *         schema:
	 *           type: string
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Simulator started successfully
	 */
	app.get('/api/trip/startSimulator/:id/:isSalesTemplate', tripController.startSimulator);
	
	/**
	 * @swagger
	 * /api/trip/getGeoCoordinates/{origin}/{destination}:
	 *   get:
	 *     tags:
	 *       - Trip
	 *     name: Start Simulator
	 *     summary: Start Simulator for device
	 *     security:
	 *       - bearerAuth: []
	 *     parameters:
	 *       - in: path
	 *         name: origin
	 *         required: true
	 *         schema:
	 *           type: string
	 *       - in: path
	 *         name: destination
	 *         required: true
	 *         schema:
	 *           type: string
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Simulator started successfully
	 */
	app.get('/api/trip/getGeoCoordinates/:origin/:destination', tripController.getGeoCoordinates);

	/**
	 * @swagger
	 * /api/trip/getDuration/{origin}/{destination}:
	 *   get:
	 *     tags:
	 *       - Trip
	 *     name: Get Duration
	 *     summary: Get Duration
	 *     security:
	 *       - bearerAuth: []
	 *     parameters:
	 *       - in: path
	 *         name: origin
	 *         required: true
	 *         schema:
	 *           type: string
	 *       - in: path
	 *         name: destination
	 *         required: true
	 *         schema:
	 *           type: string
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Simulator started successfully
	 */
	app.get('/api/trip/getDuration/:origin/:destination', tripController.getDuration);
};