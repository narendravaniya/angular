'use strict';
var multipart = require('connect-multiparty');
var multipartMiddleware = multipart();
var driverController = require('../Controllers/Driver');

module.exports = function (app) {
	/**
	 * @swagger
	 * /api/driver:
	 *   post:
	 *     tags:
	 *       - Driver
	 *     name: Add Driver
	 *     summary: add Driver in system
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     requestBody:
	 *       required: true
	 *       content:
	 *         application/json:
	 *           schema:
	 *             type: object
	 *             properties:
	 *               first_name:
	 *                 type: string
	 *               last_name:
	 *                 type: string
	 *               email:
	 *                 type: string
	 *               phone_number:
	 *                 type: string
	 *               device_id:
	 *                 type: string
	 *               country_guid:
	 *                 type: string
	 *               state_guid:
	 *                 type: string
	 *               city:
	 *                 type: string
	 *               zip_code:
	 *                 type: string
	 *               address:
	 *                 type: string
	 *             required:
	 *               - first_name
	 *               - last_name
	 *               - email
	 *               - phone_number
	 *               - address
	 *               - country_guid
	 *               - device_id
	 *               - state_guid
	 *               - city
	 *               - zip_code
	 *     responses:
	 *       200:
	 *         description: Driver added successfully
	 */
	app.post('/api/driver', driverController.add);

	/**
	 * @swagger
	 * /api/driver/{id}:
	 *   put:
	 *     tags:
	 *       - Driver
	 *     name: Edit Driver
	 *     summary: Edit Driver in system
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     parameters:
	 *       - in: path
	 *         name: id
	 *         required: true
	 *         schema:
	 *           type: string
	 *     requestBody:
	 *       required: true
	 *       content:
	 *         application/json:
	 *           schema:
	 *             type: object
	 *             properties:
	 *               first_name:
	 *                 type: string
	 *               last_name:
	 *                 type: string
	 *               email:
	 *                 type: string
	 *               phone_number:
	 *                 type: string
	 *               device_id:
	 *                 type: string
	 *               country_guid:
	 *                 type: string
	 *               state_guid:
	 *                 type: string
	 *               city:
	 *                 type: string
	 *               zip_code:
	 *                 type: string
	 *               address:
	 *                 type: string
	 *             required:
	 *               - first_name
	 *               - last_name
	 *               - email
	 *               - phone_number
	 *               - device_id
	 *               - address
	 *               - country_guid
	 *               - state_guid
	 *               - city
	 *               - zip_code
	 *     responses:
	 *       200:
	 *         description: Driver edited successfully
	 */
	app.put('/api/driver/:id', driverController.edit);

	/**
	 * @swagger
	 * /api/driver:
	 *   get:
	 *     tags:
	 *       - Driver
	 *     name: Driver List
	 *     summary: Get Driver List
	 *     security:
	 *       - bearerAuth: []
	 *     parameters:
	 *       - in: query
	 *         name: searchText
	 *         required: false
	 *         schema:
	 *           type: string
	 *       - in: query
	 *         name: sortBy
	 *         required: false
	 *         schema:
	 *           type: string
	 *       - in: query
	 *         name: pageSize
	 *         required: false
	 *         schema:
	 *           type: string
	 *       - in: query
	 *         name: pageNumber
	 *         required: false
	 *         schema:
	 *           type: string
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Driver List get successfully
	 */
	app.get('/api/driver', driverController.get);

	/**
	 * @swagger
	 * /api/driver/lookup:
	 *   get:
	 *     tags:
	 *       - Driver
	 *     name: Driver loockup
	 *     summary: Get Driver loockup
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Driver loockup get successfully
	 */
	app.get('/api/driver/lookup', driverController.getDriverLookup);

	/**
	 * @swagger
	 * /api/driver/{id}:
	 *   get:
	 *     tags:
	 *       - Driver
	 *     name: Driver Details
	 *     summary: Get Driver Details
	 *     parameters:
	 *       - in: path
	 *         name: id
	 *         required: true
	 *         schema:
	 *           type: string
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Driver Details get successfully
	 */
	app.get('/api/driver/:id', driverController.getDetails);

	/**
	 * @swagger
	 * /api/driver/{id}:
	 *   delete:
	 *     tags:
	 *       - Driver
	 *     name: Delete Driver
	 *     summary: Delete Driver
	 *     parameters:
	 *       - in: path
	 *         name: id
	 *         required: true
	 *         schema:
	 *           type: string
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     responses:
	 *       200:
	 *         description: Driver deleted successfully
	 */
	app.delete('/api/driver/:id', driverController.delete);

	/**
	 * @swagger
	 * /api/driver/{id}/status:
	 *   put:
	 *     tags:
	 *       - Driver
	 *     name: Change Driver status
	 *     summary: Change Driver status
	 *     security:
	 *       - bearerAuth: []
	 *     consumes:
	 *       - application/json
	 *     parameters:
	 *       - in: path
	 *         name: id
	 *         required: true
	 *         schema:
	 *           type: string
	 *     requestBody:
	 *       required: true
	 *       content:
	 *         application/json:
	 *           schema:
	 *             type: object
	 *             properties:
	 *               status:
	 *                 type: string
	 *             required:
	 *               - status
	 *     responses:
	 *       200:
	 *         description: Device edited successfully
	 */
	app.put('/api/driver/:id/status', driverController.changeStatus);

	app.put('/api/driver/:id/image', multipartMiddleware, driverController.uploadImage);
};