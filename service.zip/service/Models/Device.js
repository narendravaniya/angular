var Status = require('../Config/Status');
var moment = require('moment');

require('dotenv').config();
var IotConnect = require("IoTConnect");
var iotConnect = IotConnect.init('key', process.env.ENVIRONMENT);
var deviceSdk = iotConnect.Device;

//SCHEMA
var DeviceTemplateSchema = require("../Schema/DeviceTemplate");
var DeviceSchema = require('../Schema/Devices');
var DevicesStatusLogSchema = require('../Schema/DevicesStatusLog');
var DriverSchema = require('../Schema/Drivers');

class Drivers {
	getTemplateLookup() {
		return new Promise((resolve, reject) => {
			DeviceTemplateSchema.findAll({
				where: {
					[Sequelize.Op.or]: [{
						name: 'fleet'
					}, {
						name: 'Fleet'
					}]
				},
				logging: true
			}).then(deviceTemplate => {
				resolve({
					status: Status.CODES.SUCCESS.CODE,
					message: Status.CODES.SUCCESS.MESSAGE,
					data: deviceTemplate
				})
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	getDeviceLookup(hasDriver = false) {
		return new Promise((resolve, reject) => {
			var includeData = [];
			if (hasDriver) {
				includeData = [{
					model: DriverSchema,
					required: true
				}];
			}
			DeviceSchema.findAll({
				attributes: ["device_id", "displayName", "uniqueId", "type", "status"],
				include: includeData
			}).then(deviceTemplate => {
				resolve({
					status: Status.CODES.SUCCESS.CODE,
					message: Status.CODES.SUCCESS.MESSAGE,
					data: deviceTemplate
				})
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	getList(requestParams, userInfo) {
		return new Promise((resolve, reject) => {
			if (!requestParams.pageSize) {
				requestParams.pageSize = 10
			}

			if (!requestParams.pageNumber) {
				requestParams.pageNumber = 1
			}

			if (!requestParams.sortBy) {
				requestParams.sortBy = "device_id DESC"
			}

			if (!requestParams.searchText) {
				requestParams.searchText = ""
			}

			DeviceSchema.findAndCountAll({
				where: {
					[Sequelize.Op.or]: [{
						displayName: {
							[Sequelize.Op.like]: '%' + requestParams.searchText + '%'
						}
					}, {
						uniqueId: {
							[Sequelize.Op.like]: '%' + requestParams.searchText + '%'
						}
					}]
				},
				order: [requestParams.sortBy.split(" ")],
				limit: parseInt(requestParams.pageSize),
				offset: (parseInt(requestParams.pageNumber) - 1) * parseInt(requestParams.pageSize),
				include: [{
					model: DeviceTemplateSchema,
					where: {
						company_id: userInfo.companyId
					},
				}]
			}).then(device => {
				resolve({
					status: Status.CODES.SUCCESS.CODE,
					message: Status.CODES.SUCCESS.MESSAGE,
					data: device.rows,
					recordsTotal: device.count
				})
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	add(data, header, userInfo) {
		return new Promise((resolve, reject) => {
			var headers = {
				'authorization': header
			};
			deviceSdk.createSingleDevice(headers, data.display_name, data.unique_id, '', userInfo.entityGuid, data.device_template_id, data.note, [], null, null, null, null, null, null, function (error, httpResponse, body) {
				if (!error && httpResponse.statusCode === 200) {
					var deviceData = {
						device_id: body.data[0].newid,
						uniqueId: data.unique_id,
						displayName: data.display_name,
						device_template_id: data.device_template_id,
						note: data.note,
						status: data.status,
						isDeleted: 0,
						type: data.type
					};
					DeviceSchema.create(deviceData).then(deviceData => {
						resolve(body)
					}).catch(error => {
						reject({
							status: Status.CODES.SERVER_ERROR.CODE,
							message: Status.CODES.SERVER_ERROR.MESSAGE,
							error: error
						})
					});
				} else {
					reject({
						status: Status.CODES.SERVER_ERROR.CODE,
						message: Status.CODES.SERVER_ERROR.MESSAGE,
						error: error
					})
				}
			});
		})
	}

	edit(id, data, header, userInfo) {
		return new Promise((resolve, reject) => {
			var headers = {
				'authorization': header
			};
			deviceSdk.updateDevice(headers, id, data.display_name, data.note, "", userInfo.entityGuid, function (error, httpResponse, body) {
				if (!error) {
					var deviceData = {
						displayName: data.display_name,
						note: data.note,
						type: data.type,
						status: data.status
					};
					DeviceSchema.update(deviceData, {
						where: {
							device_id: id
						}
					}).then(deviceData => {
						resolve(body)
					}).catch(error => {
						reject({
							status: Status.CODES.SERVER_ERROR.CODE,
							message: Status.CODES.SERVER_ERROR.MESSAGE,
							error: error
						})
					});
				} else {
					reject({
						status: Status.CODES.SERVER_ERROR.CODE,
						message: Status.CODES.SERVER_ERROR.MESSAGE,
						error: error
					})
				}
			});
		})
	}

	get(id) {
		return new Promise((resolve, reject) => {
			var conditions = {};
			conditions['device_id'] = id;

			DeviceSchema.findOne({
				where: conditions,
				include: DeviceTemplateSchema,
			}).then(device => {
				resolve({
					status: Status.CODES.SUCCESS.CODE,
					message: Status.CODES.SUCCESS.MESSAGE,
					data: device
				})
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			});
		})
	}

	delete(id, header) {
		return new Promise((resolve, reject) => {
			var headers = {
				'authorization': header
			};
			deviceSdk.deleteDevice(headers, id, '', function (err, httpResponse, body) {
				if (!err) {
					resolve(body)
				} else {
					reject({
						status: Status.CODES.SERVER_ERROR.CODE,
						message: Status.CODES.SERVER_ERROR.MESSAGE,
						error: error
					})
				}
			});
		})
	}

	changeStatus(id, data) {
		return new Promise((resolve, reject) => {
			DeviceSchema.update(data, {
				where: {
					device_id: id
				}
			}).then(device => {
				resolve({
					status: Status.CODES.SUCCESS.CODE,
					message: Status.CODES.SUCCESS.MESSAGE,
					data: device
				})
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			});
		})
	}

	manageDeviceStatus(id, data) {
		return new Promise((resolve, reject) => {
			var date = moment().format("YYYY-MM-DD");
			var reqBody = {
				device_id: id,
				uniqueId: data.unique_id,
				displayName: data.display_name,
				status: data.status,
				date: date
			};
			DevicesStatusLogSchema.findOne({
				where: {
					device_id: id,
					date: date
				}
			}).then(deviceStatusResponse => {
				if (deviceStatusResponse) {
					DevicesStatusLogSchema.update(reqBody, {
						where: {
							device_status_id: deviceStatusResponse.device_status_id
						}
					}).then(devicesStatusLogResponse => {
						resolve({
							status: Status.CODES.SUCCESS.CODE,
							message: Status.CODES.SUCCESS.MESSAGE,
						})
					}).catch(error => {
						reject({
							status: Status.CODES.SERVER_ERROR.CODE,
							message: Status.CODES.SERVER_ERROR.MESSAGE,
							error: error
						})
					});
				} else {
					DevicesStatusLogSchema.create(reqBody).then(devicesStatusLogResponse => {
						resolve({
							status: Status.CODES.SUCCESS.CODE,
							message: Status.CODES.SUCCESS.MESSAGE,
						})
					}).catch(error => {
						reject({
							status: Status.CODES.SERVER_ERROR.CODE,
							message: Status.CODES.SERVER_ERROR.MESSAGE,
							error: error
						})
					});
				}
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			});
		})
	}
}

module.exports = Drivers;