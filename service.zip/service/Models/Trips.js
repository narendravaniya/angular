var async = require("async");
var request = require('request');
var Status = require('../Config/Status');

//SCHEMA
var TripsSchema = require('../Schema/Trips');
var DeviceSchema = require('../Schema/Devices');
var DriverSchema = require('../Schema/Drivers');

require('dotenv').config();

class Trips {
	add(data) {
		return new Promise((resolve, reject) => {
			TripsSchema.create(data).then(driver => {
				resolve({
					status: Status.CODES.SUCCESS.CODE,
					message: Status.CODES.SUCCESS.MESSAGE,
					data: driver
				})
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	edit(id, data) {
		return new Promise((resolve, reject) => {
			TripsSchema.update(data, {
				where: {
					trip_id: id
				}
			}).then(driver => {
				resolve({
					status: Status.CODES.SUCCESS.CODE,
					message: Status.CODES.SUCCESS.MESSAGE,
					data: driver
				})
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	getList(requestParams, userInfo) {
		return new Promise((resolve, reject) => {
			if (!requestParams.pageSize) {
				requestParams.pageSize = 10
			}

			if (!requestParams.pageNumber) {
				requestParams.pageNumber = 1
			}

			if (!requestParams.sortBy) {
				requestParams.sortBy = "trip_id DESC"
			}

			if (!requestParams.searchText) {
				requestParams.searchText = ""
			}
			TripsSchema.findAndCountAll({
				where: {
					[Sequelize.Op.or]: [{
						from: {
							[Sequelize.Op.like]: '%' + requestParams.searchText + '%'
						}
					}, {
						to: {
							[Sequelize.Op.like]: '%' + requestParams.searchText + '%'
						}
					}]
				},
				order: [requestParams.sortBy.split(" ")],
				limit: parseInt(requestParams.pageSize),
				offset: (parseInt(requestParams.pageNumber) - 1) * parseInt(requestParams.pageSize),
				include: [
					{
						model: DeviceSchema,
						attributes: ["device_id", "displayName", "uniqueId"],
						required: true,
						include: [{
							model: DriverSchema,
							attributes: ["first_name", "last_name"],
							required: true,
						}]
					}
				]
			}).then(Trips => {
				resolve({
					status: Status.CODES.SUCCESS.CODE,
					message: Status.CODES.SUCCESS.MESSAGE,
					data: Trips
				})
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	get(id) {
		return new Promise((resolve, reject) => {
			TripsSchema.findOne({
				where: {
					trip_id: id
				},
				include: [
					{
						model: DeviceSchema,
						attributes: ["device_id", "displayName", "uniqueId", "type"],
						required: true,
						include: [{
							model: DriverSchema,
							attributes: ["first_name", "last_name", "email", "phone_number", "address", "image", "city"],
							required: true,

						}]
					}
				],
			}).then(driver => {
				resolve({
					status: Status.CODES.SUCCESS.CODE,
					message: Status.CODES.SUCCESS.MESSAGE,
					data: driver
				})
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	delete(id) {
		return new Promise((resolve, reject) => {
			TripsSchema.destroy({
				where: {
					trip_id: id
				}
			}).then(driver => {
				resolve({
					status: Status.CODES.SUCCESS.CODE,
					message: Status.CODES.SUCCESS.MESSAGE,
					data: driver
				})
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	startSimulatorOld(id, header) {
		return new Promise((resolve, reject) => {
			var headers = {
				'Content-Type': 'application/json',
				'Authorization': header,
			}
			var cpId = 'fleet';
			var url = 'https://qaapi.iotconnect.io/api/device/simulator/start';
			if (process.env.ENVIRONMENT === 'poc') {
				url = 'http://40.71.252.167:219/api/simulator/start';
				cpId = 'fleetpoc';
			}

			var reqBody = {
				"cpid": cpId,
				"uniqueId": id,
				"duration": 30,
				"interval": 6,
				"attributeArray": {
					"": {
						"device": [],
						"selectedChildDevice": [],
						"attribute": [{
							"parentName": "",
							"dataType": 0,
							"localName": "temperature",
							"finalLocalName": "temperature",
							"dataValidation": "",
							"tag": "",
							"min": 85,
							"max": 90,
							"precision": 1,
							"value": "0",
							"isParent": "0"
						},
						{
							"parentName": "",
							"dataType": 0,
							"localName": "humidity",
							"finalLocalName": "humidity",
							"dataValidation": "",
							"tag": "",
							"min": 65,
							"max": 70,
							"precision": 1,
							"value": "0",
							"isParent": "0"
						},
						{
							"parentName": "",
							"dataType": 0,
							"localName": "precipitation",
							"finalLocalName": "precipitation",
							"dataValidation": "",
							"tag": "",
							"min": 0,
							"max": 1,
							"precision": 1,
							"value": "0",
							"isParent": "0"
						},
						{
							"parentName": "",
							"dataType": 0,
							"localName": "wind",
							"finalLocalName": "wind",
							"dataValidation": "",
							"tag": "",
							"min": 3,
							"max": 8,
							"precision": 1,
							"value": "0",
							"isParent": "0"
						},
						{
							"parentName": "",
							"dataType": 0,
							"localName": "fuellevel",
							"finalLocalName": "fuellevel",
							"dataValidation": "",
							"tag": "",
							"min": 60,
							"max": 65,
							"precision": 0,
							"value": "0",
							"isParent": "0"
						},
						{
							"parentName": "",
							"dataType": 0,
							"localName": "currentmpg",
							"finalLocalName": "currentmpg",
							"dataValidation": "",
							"tag": "",
							"min": 50,
							"max": 65,
							"precision": 0,
							"value": "0",
							"isParent": "0"
						},
						{
							"parentName": "",
							"dataType": 0,
							"localName": "airtemp",
							"finalLocalName": "airtemp",
							"dataValidation": "",
							"tag": "",
							"min": 30,
							"max": 40,
							"precision": 0,
							"value": "0",
							"isParent": "0"
						},
						{
							"parentName": "",
							"dataType": 0,
							"localName": "enginetemp",
							"finalLocalName": "enginetemp",
							"dataValidation": "",
							"tag": "",
							"min": 65,
							"max": 75,
							"precision": 0,
							"value": "0",
							"isParent": "0"
						},
						{
							"parentName": "",
							"dataType": 0,
							"localName": "currentspeed",
							"finalLocalName": "currentspeed",
							"dataValidation": "",
							"tag": "",
							"min": 45,
							"max": 60,
							"precision": 0,
							"value": "0",
							"isParent": "0"
						}],
						"templateTag": true
					}
				}
			};

			request.post({
				url: url,
				headers: headers,
				body: reqBody,
				json: true
			}, function (error, response, body) {
				if (!error) {
					resolve(body)
				} else {
					reject({
						status: Status.CODES.SERVER_ERROR.CODE,
						message: Status.CODES.SERVER_ERROR.MESSAGE,
						error: error
					})
				}
			});
		})
	}

	startSimulator(id, header) {
		return new Promise((resolve, reject) => {
			var headers = {
				'Content-Type': 'application/json',
				'Authorization': header,
			}
			var cpId = 'fleet';
			var url = 'https://qaapi.iotconnect.io/api/device/simulator/start';
			if (process.env.ENVIRONMENT === 'poc') {
				url = 'http://40.71.252.167:219/api/simulator/start';
				cpId = 'fleetpoc';
			}

			var reqBody = {
				"cpid": cpId,
				"uniqueId": id,
				"duration": 1,
				"interval": 30,
				"attributeArray": {
					"": {
						"device": [],
						"selectedChildDevice": [],
						"attribute": [{
							"parentName": "",
							"dataType": 0,
							"localName": "can_engine_rpm",
							"finalLocalName": "can_engine_rpm",
							"dataValidation": "",
							"tag": "",
							"min": 1,
							"max": 7,
							"precision": 0,
							"value": "0",
							"isParent": "0"
						},
						{
							"parentName": "",
							"dataType": 0,
							"localName": "can_engine_rpm_total",
							"finalLocalName": "can_engine_rpm_total",
							"dataValidation": "",
							"tag": "",
							"min": 85,
							"max": 90,
							"precision": 0,
							"value": "0",
							"isParent": "0"
						},
						{
							"parentName": "",
							"dataType": 0,
							"localName": "can_fuel_level",
							"finalLocalName": "can_fuel_level",
							"dataValidation": "",
							"tag": "",
							"min": 60,
							"max": 70,
							"precision": 0,
							"value": "0",
							"isParent": "0"
						},
						{
							"parentName": "",
							"dataType": 0,
							"localName": "can_hours_operation",
							"finalLocalName": "can_hours_operation",
							"dataValidation": "",
							"tag": "",
							"min": 10,
							"max": 30,
							"precision": 0,
							"value": "0",
							"isParent": "0"
						},
						{
							"parentName": "",
							"dataType": 0,
							"localName": "can_odometer",
							"finalLocalName": "can_odometer",
							"dataValidation": "",
							"tag": "",
							"min": 100,
							"max": 500,
							"precision": 0,
							"value": "0",
							"isParent": "0"
						},
						{
							"parentName": "",
							"dataType": 0,
							"localName": "can_vehicle_speed",
							"finalLocalName": "can_vehicle_speed",
							"dataValidation": "",
							"tag": "",
							"min": 50,
							"max": 120,
							"precision": 0,
							"value": "0",
							"isParent": "0"
						},
						{
							"parentName": "",
							"dataType": 0,
							"localName": "fleet_uptime",
							"finalLocalName": "fleet_uptime",
							"dataValidation": "",
							"tag": "",
							"min": 1,
							"max": 10,
							"precision": 0,
							"value": "0",
							"isParent": "0"
						},
						{
							"parentName": "",
							"dataType": 0,
							"localName": "gps_lat",
							"finalLocalName": "gps_lat",
							"dataValidation": "",
							"tag": "",
							"min": 85,
							"max": 90,
							"precision": 1,
							"value": "0",
							"isParent": "0"
						},
						{
							"parentName": "",
							"dataType": 0,
							"localName": "gps_lng",
							"finalLocalName": "gps_lng",
							"dataValidation": "",
							"tag": "",
							"min": 85,
							"max": 90,
							"precision": 1,
							"value": "0",
							"isParent": "0"
						},
						{
							"parentName": "",
							"dataType": 0,
							"localName": "gps_num_sats",
							"finalLocalName": "gps_num_sats",
							"dataValidation": "",
							"tag": "",
							"min": 1,
							"max": 10,
							"precision": 0,
							"value": "0",
							"isParent": "0"
						}],
						"templateTag": true
					}
				}
			};

			request.post({
				url: url,
				headers: headers,
				body: reqBody,
				json: true
			}, function (error, response, body) {
				if (!error) {
					resolve(body)
				} else {
					reject({
						status: Status.CODES.SERVER_ERROR.CODE,
						message: Status.CODES.SERVER_ERROR.MESSAGE,
						error: error
					})
				}
			});
		})
	}

	getGeoCoordinates(origin, destination) {
		return new Promise((resolve, reject) => {
			request.get({
				url: 'https://maps.googleapis.com/maps/api/directions/json?origin=' + origin + '&destination=' + destination + '$transit_mode=bus&departure_time=now&key=AIzaSyDf7yFrQU0RsJpULnEgj8wU6JlGNPeQ6k4',
				json: true
			}, function (error, response, body) {
				if (!error) {
					var responseObj = [];
					async.forEach(body['routes'][0]['legs'][0]['steps'], function (trip, callback) {
						responseObj.push(trip.start_location)
						callback()
					}, function () {
						resolve({
							status: Status.CODES.SUCCESS.CODE,
							message: Status.CODES.SUCCESS.MESSAGE,
							data: responseObj
						});
					});
				} else {
					reject({
						status: Status.CODES.SERVER_ERROR.CODE,
						message: Status.CODES.SERVER_ERROR.MESSAGE,
						error: error
					})
				}
			});
		})
	}

	getDuration(origin, destination) {
		return new Promise((resolve, reject) => {
			request.get({
				url: 'https://maps.googleapis.com/maps/api/directions/json?origin=' + origin + '&destination=' + destination + '$transit_mode=bus&departure_time=now&key=AIzaSyDf7yFrQU0RsJpULnEgj8wU6JlGNPeQ6k4',
				json: true
			}, function (error, response, body) {
				if (!error) {
					var response = body['routes'][0]['legs'][0]['steps'];
					var responseObj = [];
					var totalIndex = response.length;
					var lastIndex = totalIndex - 1;

					responseObj.push({
						'duration': body['routes'][0]['legs'][0]['duration'],
						'distance': body['routes'][0]['legs'][0]['distance']
					})
					resolve({
						status: Status.CODES.SUCCESS.CODE,
						message: Status.CODES.SUCCESS.MESSAGE,
						data: responseObj
					});
				} else {
					reject({
						status: Status.CODES.SERVER_ERROR.CODE,
						message: Status.CODES.SERVER_ERROR.MESSAGE,
						error: error
					})
				}
			});
		})
	}
}

module.exports = Trips;