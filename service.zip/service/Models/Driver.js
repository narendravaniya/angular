var Status = require('../Config/Status');

// require('dotenv').config();
// var IotConnect = require("IoTConnect");
// var iotConnect = IotConnect.init('key', process.env.ENVIRONMENT);
// var fileSDK = iotConnect.File;

//SCHEMA
var DriverSchema = require('../Schema/Drivers');
var DeviceSchema = require('../Schema/Devices');

class Drivers {
	add(data, userInfo) {
		return new Promise((resolve, reject) => {
			data.company_id = userInfo.companyId
			DriverSchema.create(data).then(driver => {
				resolve({
					status: Status.CODES.SUCCESS.CODE,
					message: Status.CODES.SUCCESS.MESSAGE,
					data: driver
				})
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	edit(id, data) {
		return new Promise((resolve, reject) => {
			DriverSchema.update(data, {
				where: {
					driver_id: id
				}
			}).then(driver => {
				resolve({
					status: Status.CODES.SUCCESS.CODE,
					message: Status.CODES.SUCCESS.MESSAGE,
					data: driver
				})
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	getList(requestParams, userInfo) {
		return new Promise((resolve, reject) => {
			if (!requestParams.pageSize) {
				requestParams.pageSize = 10
			}

			if (!requestParams.pageNumber) {
				requestParams.pageNumber = 1
			}

			if (!requestParams.sortBy) {
				requestParams.sortBy = "driver_id DESC"
			}

			if (!requestParams.searchText) {
				requestParams.searchText = ""
			}

			DriverSchema.findAndCountAll({
				where: {
					[Sequelize.Op.or]: [{
						first_name: {
							[Sequelize.Op.like]: '%' + requestParams.searchText + '%'
						}
					}, {
						last_name: {
							[Sequelize.Op.like]: '%' + requestParams.searchText + '%'
						}
					}, {
						email: {
							[Sequelize.Op.like]: '%' + requestParams.searchText + '%'
						}
					}, {
						phone_number: {
							[Sequelize.Op.like]: '%' + requestParams.searchText + '%'
						}
					}],
					company_id: userInfo.companyId
				},
				order: [requestParams.sortBy.split(" ")],
				limit: parseInt(requestParams.pageSize),
				offset: (parseInt(requestParams.pageNumber) - 1) * parseInt(requestParams.pageSize),
				include: [
					{
						model: DeviceSchema,
						attributes: ["device_id", "displayName", "uniqueId"]
					}
				],
			}).then(driver => {
				resolve({
					status: Status.CODES.SUCCESS.CODE,
					message: Status.CODES.SUCCESS.MESSAGE,
					recordsTotal: driver.count,
					data: driver.rows
				})
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	get(id) {
		return new Promise((resolve, reject) => {
			DriverSchema.findOne({
				where: {
					driver_id: id
				}
			}).then(driver => {
				resolve({
					status: Status.CODES.SUCCESS.CODE,
					message: Status.CODES.SUCCESS.MESSAGE,
					data: driver
				})
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	delete(id) {
		return new Promise((resolve, reject) => {
			DriverSchema.destroy({
				where: {
					driver_id: id
				}
			}).then(driver => {
				resolve({
					status: Status.CODES.SUCCESS.CODE,
					message: Status.CODES.SUCCESS.MESSAGE,
					data: driver
				})
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	getDriverLookup() {
		return new Promise((resolve, reject) => {
			DriverSchema.findAll({
				attributes: ["driver_id", "first_name", "last_name", "email"]
			}).then(deviceTemplate => {
				resolve({
					status: Status.CODES.SUCCESS.CODE,
					message: Status.CODES.SUCCESS.MESSAGE,
					data: deviceTemplate
				})
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	changeStatus(id, data) {
		return new Promise((resolve, reject) => {
			DriverSchema.update(data, {
				where: {
					driver_id: id
				}
			}).then(device => {
				resolve({
					status: Status.CODES.SUCCESS.CODE,
					message: Status.CODES.SUCCESS.MESSAGE
				})
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			});
		})
	}
}

module.exports = Drivers;