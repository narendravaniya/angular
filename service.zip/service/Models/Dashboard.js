var Status = require('../Config/Status');
var NodeGeocoder = require('node-geocoder');
var async = require("async");
var bluebird = require("bluebird");
var Parallel = bluebird.join
var moment = require('moment');

//SCHEMA
var DriverSchema = require("../Schema/Drivers");
var DeviceSchema = require("../Schema/Devices");
var TripSchema = require("../Schema/Trips");
var NotificationSchema = require("../Schema/Notifications");
var DeviceTemplateSchema = require("../Schema/DeviceTemplate");
var DevicesStatusLogSchema = require("../Schema/DevicesStatusLog");

var options = {
	provider: 'google',
	apiKey: 'AIzaSyDf7yFrQU0RsJpULnEgj8wU6JlGNPeQ6k4',
	formatter: null
};
var geocoder = NodeGeocoder(options);

require('dotenv').config();
var IotConnect = require("IoTConnect");
var iotConnect = IotConnect.init('key', process.env.ENVIRONMENT);
var telemetrySDK = iotConnect.Telemetry;

class Drivers {
	getStatistics(userInfo) {
		return new Promise((resolve, reject) => {
			Parallel(
				this.getActiveDevices(userInfo.companyId),
				this.getCompletedTrips(userInfo.companyId),
				this.getDriverUtilization(userInfo.companyId),
				this.getFleetNotification(),
				(activeDevices, completedTrips, driverUtilization, fleetNotification) => {
					resolve({
						status: Status.CODES.SUCCESS.CODE,
						message: Status.CODES.SUCCESS.MESSAGE,
						activeDevices: activeDevices,
						completedTrips: completedTrips,
						driverUtilization: driverUtilization,
						fleetNotification: fleetNotification.count
					})
				}
			).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	getActiveDevices(companyId) {
		return new Promise((resolve, reject) => {
			DeviceSchema.count({
				where: {
					status: 2
				},
				include: [{
					model: DeviceTemplateSchema,
					where: {
						company_id: companyId
					},
				}]
			}).then(activeDevices => {
				resolve(activeDevices)
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	getCompletedTrips(companyId) {
		return new Promise((resolve, reject) => {
			TripSchema.count({
				where: {
					status: 3
				},
				include: [{
					model: DeviceSchema,
					include: [{
						model: DeviceTemplateSchema,
						where: {
							company_id: companyId
						},
					}]
				}]
			}).then(completedTrips => {
				resolve(completedTrips)
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	getDriverUtilization(companyId) {
		return new Promise((resolve, reject) => {
			TripSchema.count({
				where: {
					status: 2
				},
				include: [{
					model: DeviceSchema,
					include: [{
						model: DeviceTemplateSchema,
						where: {
							company_id: companyId
						},
					}]
				}]
			}).then(activeTrips => {
				DriverSchema.count({
					where: {
						company_id: companyId
					}
				}).then(drivers => {
					resolve((activeTrips / drivers) * 100)
				}).catch(error => {
					reject({
						status: Status.CODES.SERVER_ERROR.CODE,
						message: Status.CODES.SERVER_ERROR.MESSAGE,
						error: error
					})
				})
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	getFleetNotification() {
		return new Promise((resolve, reject) => {
			NotificationSchema.findAndCountAll({
				limit: 5,
				order: [['date', 'DESC']]
			}).then(totalNotifications => {
				resolve(totalNotifications)
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	getTruckUsage() {
		return new Promise((resolve, reject) => {
			TripSchema.count({
				attributes: ['Device.type'],
				include: DeviceSchema,
				group: ['Device.type']
			}).then(tripData => {
				var totalCount = 0;
				async.forEach(tripData, function (trip, callback) {
					totalCount = totalCount + trip.count;
					callback()
				}, function () {
					resolve({
						status: Status.CODES.SUCCESS.CODE,
						message: Status.CODES.SUCCESS.MESSAGE,
						count: totalCount,
						data: tripData
					});
				});
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	getTruckActivity(header) {
		return new Promise((resolve, reject) => {
			DeviceSchema.findAll({
				attributes: ["device_id", "displayName", "uniqueId", "type", "status"],
				include: [{
					model: TripSchema,
					attributes: ["currentLat", "currentLng"],
					limit: 1,
					order: [['start_time', 'DESC']]
				}, {
					model: DriverSchema,
					attributes: ['driver_id', 'first_name', 'last_name', 'email', 'phone_number']
				}]
			}).then(deviceResponse => {
				var responseData = [];
				async.forEachSeries(deviceResponse, function (deviceResponseData, callback) {
					if (deviceResponseData.Trips.length > 0) {
						geocoder.reverse({ lat: deviceResponseData.Trips[0]['currentLat'], lon: deviceResponseData.Trips[0]['currentLng'] }).then(function (res) {
							responseData.push({
								device_id: deviceResponseData.device_id,
								displayName: deviceResponseData.displayName,
								uniqueId: deviceResponseData.uniqueId,
								status: deviceResponseData.status,
								type: deviceResponseData.type,
								latitude: deviceResponseData.Trips[0]['currentLat'],
								longitude: deviceResponseData.Trips[0]['currentLng'],
								location: res[0].formattedAddress,
								driver: deviceResponseData.Driver,
							})
							callback()
						}).catch(function (err) {
							responseData.push({
								device_id: deviceResponseData.device_id,
								status: deviceResponseData.status,
								type: deviceResponseData.type,
								latitude: deviceResponseData.Trips[0]['currentLat'],
								longitude: deviceResponseData.Trips[0]['currentLng'],
								location: "",
							})
							callback()
						});
					} else {
						responseData.push({
							device_id: deviceResponseData.device_id,
							displayName: deviceResponseData.displayName,
							uniqueId: deviceResponseData.uniqueId,
							status: deviceResponseData.status,
							type: deviceResponseData.type,
							latitude: '33.085698',
							longitude: '-96.837228',
							location: '7950 Legacy Drive, St. 250, Plano, TX 75024',
							driver: deviceResponseData.Driver,
						})
						callback()
					}
				}, function () {
					resolve(responseData)
				});
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	getTruckGraph() {
		return new Promise((resolve, reject) => {
			DevicesStatusLogSchema.findAll({
				attributes: ["status", "date"],
				order: [['date', 'ASC']]
			}).then(devicesStatusLogResponse => {
				var dateArray = [];
				var responseObj = [];
				var graphResponseObj = [];
				async.forEachSeries(devicesStatusLogResponse, function (devicesStatusLog, callback) {
					if (dateArray.indexOf(devicesStatusLog.date) === -1) {
						dateArray.push(devicesStatusLog.date)
						var index = dateArray.indexOf(devicesStatusLog.date);
						responseObj.push({
							date: devicesStatusLog.date,
							idle: 0 + (devicesStatusLog.status === 1 ? 1 : 0),
							active: 0 + (devicesStatusLog.status === 2 ? 1 : 0),
							maintenance: 0 + (devicesStatusLog.status === 3 ? 1 : 0),
						})
						graphResponseObj.push([devicesStatusLog.date, responseObj[index].active, responseObj[index].idle, responseObj[index].maintenance])
					} else {
						var index = dateArray.indexOf(devicesStatusLog.date);
						if (devicesStatusLog.status === 1)
							responseObj[index]['idle']++
						if (devicesStatusLog.status === 2)
							responseObj[index]['active']++
						if (devicesStatusLog.status === 3)
							responseObj[index]['maintenance']++

						graphResponseObj[index] = [responseObj[index].date, responseObj[index].active, responseObj[index].idle, responseObj[index].maintenance]
					}
					callback()
				}, function () {
					resolve(graphResponseObj)
				});
			}).catch(error => {
				reject({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE,
					error: error
				})
			})
		})
	}

	getDeviceAttributes(header, device_id) {
		return new Promise((resolve, reject) => {
			var headers = {
				'authorization': header
			};
			telemetrySDK.getDeviceSensors(headers, device_id, function (err, httpResponse, response) {
				if (!err) {
					resolve(response)
				} else {
					reject(null)
				}
			})
		})
	}

	getStompConfiguration(header) {
		return new Promise((resolve, reject) => {
			var headers = {
				'authorization': header
			};
			telemetrySDK.getStompConfiguration(headers, '', function (err, httpResponse, response) {
				if (!err) {
					resolve(response)
				} else {
					reject(null)
				}
			})
		})
	}

	getDeviceAttributeHistoricalData(header, data) {
		return new Promise((resolve, reject) => {
			var headers = {
				'authorization': header
			};
			telemetrySDK.getAttributeHistoricalData(headers, data.templateAttributeGuid, data.uniqueId, data.startDate, data.endDate, function (err, httpResponse, response) {
				if (!err) {
					// resolve(response);
					var fleetUptimeData = response.data.feed.filter(attributes => parseInt(attributes.fleet_uptime) > 0)
					var dateArray = [];
					var graphResponseObj = [];
					async.forEachSeries(fleetUptimeData, function (fleetData, callback) {
						fleetData.dTime = moment(fleetData.dTime).format("YYYY-MM-DD");
						if (dateArray.indexOf(fleetData.dTime) === -1) {
							dateArray.push(fleetData.dTime)
							var fleetFilterData = fleetUptimeData.filter(fleetUptime => moment(fleetUptime.dTime).format("YYYY-MM-DD") === fleetData.dTime)
							var duration = parseFloat(moment.duration(moment(fleetFilterData[fleetFilterData.length - 1].dTime).diff(fleetFilterData[0].dTime)).asHours().toFixed(1));
							graphResponseObj.push([fleetData.dTime, duration])
						}
						callback()
					}, function () {
						resolve(graphResponseObj)
					});
				} else {
					reject(null)
				}
			})
		})
	}
}

module.exports = Drivers;