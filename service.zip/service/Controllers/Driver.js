'use strict';
var DriversModel = require('../Models/Driver');
var driversModel = new DriversModel();

var Status = require('../Config/Status');
var GeneralConfig = require('../Config/GeneralConfig');
require('dotenv').config();

var IotConnect = require("IoTConnect");
var iotConnect = IotConnect.init('key', process.env.ENVIRONMENT);
var fileSDK = iotConnect.File;

var DriverSchema = require('../Schema/Drivers');

exports.add = function (req, res) {
	var userInfo = GeneralConfig.getUserInfo(req);
	driversModel.add(req.body, userInfo).then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.getDriverLookup = function (req, res) {
	driversModel.getDriverLookup().then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.edit = function (req, res) {
	driversModel.edit(req.params.id, req.body).then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.get = function (req, res) {
	var userInfo = GeneralConfig.getUserInfo(req);
	driversModel.getList(req.query, userInfo).then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.getDetails = function (req, res) {
	driversModel.get(req.params.id).then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.delete = function (req, res) {
	driversModel.delete(req.params.id).then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.changeStatus = function (req, res) {
	driversModel.changeStatus(req.params.id, req.body).then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.uploadImage = function (req, res) {
	var id = req.params.id;
	var file = req.files.image;
	var fileType = 'custom';
	var tag = 'Fleet';
	var headers = {
		'authorization': req.headers.authorization
	};
	getFile(headers, fileType, id, function (getFileResponse) {
		if (getFileResponse && getFileResponse.data && getFileResponse.data.fileData && getFileResponse.data.fileData.length > 0) {
			var fileGuid = getFileResponse.data.fileData[getFileResponse.data.fileData.length - 1].guid;
			updateFile(headers, fileType, fileGuid, file, tag, function (updateFileResponse) {
				var reqBody = {
					image: updateFileResponse.data[0].file
				};
				DriverSchema.update(reqBody, {
					where: {
						driver_id: id
					}
				}).then(deviceData => {
					return res.json(updateFileResponse);
				}).catch(error => {
					console.log("Update Image in database error", error)
				})
			})
		} else {
			addFile(headers, fileType, id, file, tag, function (updateFileResponse) {
				var reqBody = {
					image: updateFileResponse.data[0].file
				};
				DriverSchema.update(reqBody, {
					where: {
						driver_id: id
					}
				}).then(deviceData => {
					return res.json(updateFileResponse);
				}).catch(error => {
					console.log("Update Image in database error", error)
				})
			})
		}
	});
};

function getFile(headers, fileType, fileGuid, callback) {
	try {
		fileSDK.getFileList(headers, fileType, fileGuid, function (err, httpResponse, body) {
			if (httpResponse.statusCode === 200) {
				return callback(body)
			} else {
				return callback(body)
			}
		});
	} catch (e) {
		return callback(e)
	}
};

function addFile(headers, fileType, fileTypeGuid, file, tag, callback) {
	try {
		fileSDK.uploadFile(headers, fileType, fileTypeGuid, file, tag, function (err, httpResponse, body) {
			if (httpResponse.statusCode === 200) {
				body = JSON.parse(body);
				return callback(body)
			} else {
				return callback(body)
			}
		});
	} catch (e) {
		return callback(e)
	}
};

function updateFile(headers, fileType, fileGuid, file, tag, callback) {
	try {
		fileSDK.updateFile(headers, fileType, fileGuid, file, tag, function (err, httpResponse, body) {
			if (httpResponse.statusCode === 200) {
				body = JSON.parse(body);
				return callback(body)
			} else {
				return callback(body)
			}
		});
	} catch (e) {
		return callback(e)
	}
};