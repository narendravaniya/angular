'use strict';
var DeviceSchema = require("./../Schema/Devices");

require('dotenv').config();
var IotConnect = require("IoTConnect");
var iotConnect = IotConnect.init('key', process.env.ENVIRONMENT);
var fileSDK = iotConnect.File;
var deviceSdk = iotConnect.Device;

var DeviceModel = require('../Models/Device');
var deviceModel = new DeviceModel();

var Status = require('../Config/Status');
var GeneralConfig = require('../Config/GeneralConfig');

exports.getTemplateLookup = function (req, res) {
	deviceModel.getTemplateLookup().then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.getDeviceLookup = function (req, res) {
	var hasDriver = false;
	if (req.query.hasDriver === true || req.query.hasDriver === 'true' || req.query.hasDriver === 'True' || req.query.hasDriver === 'TRUE') {
		hasDriver = true;
	}

	deviceModel.getDeviceLookup(hasDriver).then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.getList = function (req, res) {
	var userInfo = GeneralConfig.getUserInfo(req);
	deviceModel.getList(req.query, userInfo).then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.add = function (req, res) {
	var userInfo = GeneralConfig.getUserInfo(req);
	deviceModel.add(req.body, req.headers.authorization, userInfo).then(response => {
		deviceModel.manageDeviceStatus(response.data[0].newid, req.body);
		res.send(response);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.update = function (req, res) {
	var userInfo = GeneralConfig.getUserInfo(req);
	deviceModel.edit(req.params.id, req.body, req.headers.authorization, userInfo).then(data => {
		deviceModel.manageDeviceStatus(req.params.id, req.body);
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.get = function (req, res) {
	deviceModel.get(req.params.id).then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.delete = function (req, res) {
	deviceModel.delete(req.params.id, req.headers.authorization).then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.changeStatus = function (req, res) {
	deviceModel.changeStatus(req.params.id, req.body).then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.uploadImage = function (req, res) {
	var id = req.params.id;
	var file = req.files.image;
	var fileType = 'custom';
	var tag = 'Fleet';
	var headers = {
		'authorization': req.headers.authorization
	};
	getFile(headers, fileType, id, function (getFileResponse) {
		if (getFileResponse && getFileResponse.data && getFileResponse.data.fileData && getFileResponse.data.fileData.length > 0) {
			var fileGuid = getFileResponse.data.fileData[getFileResponse.data.fileData.length - 1].guid;
			updateFile(headers, fileType, fileGuid, file, tag, function (updateFileResponse) {
				var reqBody = {
					image: updateFileResponse.data[0].file
				};
				DeviceSchema.update(reqBody, {
					where: {
						device_id: id
					}
				}).then(deviceData => {
					return res.json(updateFileResponse);
				}).catch(error => {
					console.log("Update Image in database error", error)
				})
			})
		} else {
			addFile(headers, fileType, id, file, tag, function (updateFileResponse) {
				var reqBody = {
					image: updateFileResponse.data[0].file
				};
				DeviceSchema.update(reqBody, {
					where: {
						device_id: id
					}
				}).then(deviceData => {
					return res.json(updateFileResponse);
				}).catch(error => {
					console.log("Update Image in database error", error)
				})
			})
		}
	});
};

function getFile(headers, fileType, fileGuid, callback) {
	try {
		fileSDK.getFileList(headers, fileType, fileGuid, function (err, httpResponse, body) {
			if (httpResponse.statusCode === 200) {
				return callback(body)
			} else {
				return callback(body)
			}
		});
	} catch (e) {
		return callback(e)
	}
};

function addFile(headers, fileType, fileTypeGuid, file, tag, callback) {
	try {
		fileSDK.uploadFile(headers, fileType, fileTypeGuid, file, tag, function (err, httpResponse, body) {
			if (httpResponse.statusCode === 200) {
				body = JSON.parse(body);
				return callback(body)
			} else {
				return callback(body)
			}
		});
	} catch (e) {
		return callback(e)
	}
};

function updateFile(headers, fileType, fileGuid, file, tag, callback) {
	try {
		fileSDK.updateFile(headers, fileType, fileGuid, file, tag, function (err, httpResponse, body) {
			if (httpResponse.statusCode === 200) {
				body = JSON.parse(body);
				return callback(body)
			} else {
				return callback(body)
			}
		});
	} catch (e) {
		return callback(e)
	}
};

exports.getTruckLookup = function (req, res) {
	var userInfo = GeneralConfig.getUserInfo(req);
	let bearerToken = req.headers.authorization;
	var headers = {
		'authorization': bearerToken
	};
	try {
		//deviceSdk.getDeviceLookup(headers, '08D73078-CA92-46DE-9F91-6FEBFCC1DD12', null, null, null, function (err, httpResponse, body) {
		deviceSdk.getAllottedDeviceListByUserGuid(headers, userInfo.id,-1, -1, null, null, function (err, httpResponse, body){
			if (err) {
				var err = [{
					param: 'error',
					message: err.message
				}];
				res.send({
					status: Status.CODES.SERVER_ERROR.CODE,
					message: Status.CODES.SERVER_ERROR.MESSAGE
				});
			} else {
				if (httpResponse.statusCode === 200) {
					var data = {
						sensors: body.data
					}
					return res.json(body);
				} else if (httpResponse.statusCode === 204) {
					return res.status(body.status).json(body);
				} else {
					res.send({
						status: Status.CODES.SERVER_ERROR.CODE,
						message: Status.CODES.SERVER_ERROR.MESSAGE
					});
				}
			}
		});
	} catch (e) {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	}
}