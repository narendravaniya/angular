'use strict';
var nodeMailJet = require('node-mailjet');
var generalConfig = require('../Config/GeneralConfig');
var Status = require('./../Config/Status');
var CompanyUserSchema = require('./../Schema/CompanyUsers');
var RoleSchema = require('./../Schema/Roles');
var CompanySchema = require('./../Schema/Company');
var UserSchema = require('./../Schema/Users');
const Op = Sequelize.Op;
require('dotenv').config();

var IotConnect = require("IoTConnect");
var iotConnect = IotConnect.init('key', process.env.ENVIRONMENT);
var userSdk = iotConnect.User;
var fileSDK = iotConnect.File;
var masterSDK = iotConnect.Master;

exports.getTimezone = function (req, res) {
	masterSDK.getTimezone(function (err, httpResponse, body) {
		if (!err) {
			if (body.status === 200) {
				return res.json({
					'status': 200,
					'data': body.data,
					'message': Status.MESSAGES.SUCCESS
				});
			} else {
				return res.json({
					'status': 500,
					'message': body.error[0].message,
					'error': body
				});
			}
		} else {
			return res.json({
				'status': 500,
				'message': Status.MESSAGES.ERROR,
				'error': err
			});
		}
	});
}

exports.getUserRole = function (req, res) {
	var userInfo = generalConfig.getUserInfo(req);
	var companyGuid = userInfo.companyId;

	RoleSchema.findAll({
		where: {
			company_id: companyGuid
		}
	}).then(roleData => {
		res.json({
			error: false,
			data: roleData,
			msg: null
		});
	}).catch(function (err) {
		res.json({
			error: true,
			data: null,
			msg: "Something went wrong! Please try again"
		});
	});
}

exports.getCompanyInfo = function (req, res, next) {
	let include = [{
		model: RoleSchema
	}];
	CompanyUserSchema.findOne({
		where: {
			user_id: req.params.userId
		},
		include
	}).then(function (companyUser) {
		res.json({
			error: false,
			data: {
				company: companyUser
			},
			msg: null
		});
	}).catch(function (err) {
		res.json({
			error: true,
			data: null,
			msg: "Something went wrong! Please try again"
		});
	});
}

exports.addUser = function (req, res) {
	var userInfo = generalConfig.getUserInfo(req);
	var companyGuid = userInfo.companyId;
	var entityGuid = userInfo.entityGuid;
	var reqBody = req.body;
	var headers = {
		'authorization': req.headers.authorization
	};

	var contactNo = reqBody.phone_code + '-' + reqBody.phone_number;
	userSdk.addUser(headers, reqBody.timezone, reqBody.user_type, reqBody.first_name, reqBody.last_name, contactNo, 1, reqBody.email, '', entityGuid, '', function (err, httpResponse, body) {
		if (!err) {
			if (body.status === 200) {
				UserSchema.findAll({
					where: {
						user_id: body.data[0].newId
					}
				}).then(user => {
					reqBody['user_id'] = body.data[0].newId;
					reqBody['company_id'] = companyGuid;
					if (user.length === 0) {
						UserSchema.create(reqBody).then(userData => {
							console.log("User has been added successfully.")
						}).catch(error => {
							console.log("Add User error", error)
						});
						CompanyUserSchema.create(reqBody).then(userData => {
							console.log("CompanyUser has been added successfully.")

							var message = '<!DOCTYPE html><title>Welcome To IotConnect</title><link href="https://fonts.googleapis.com/css?family=Roboto:400,500"rel=stylesheet><body style="font-family:\'Roboto\',sans-serif;font-weight:400;padding:50px;background:#fafafa"><div style="box-shadow:0 4px 18px rgba(0,0,0,.1);padding:30px"><p style=margin-bottom:0;font-size:26px>Hello ' + reqBody.first_name + ' ' + reqBody.last_name + ',<p style=color:#00a8ff;margin-bottom:0;font-size:26px>Congratulations..!<p>You have successfully Signed Up with Smart Office. Please click below to set password for your account.</p><a href="' + process.env.HTTP_PATH + process.env.BASE_URL + ':4200/resetpassword/' + body.data[0].invitationGuid + '" target=_blank><button style="margin-bottom:4px!important;padding:8px 40px;border-radius:3px;border:1px solid #00a8ff;background:#00a8ff;color:#fff;font-size:1rem;text-align:center;cursor:pointer;font-weight:600">Set Password</button></a><p style=margin-bottom:0>Thank You,<p style=margin-top:5px>Team Smart Office.</div>';
							sendMail([reqBody.email], message);

							return res.json({
								'status': 200,
								'data': userData,
								'message': Status.MESSAGES.SUCCESS
							});
						}).catch(error => {
							console.log("Add CompanyUser error", error)
							return res.json({
								'status': 500,
								'data': error,
								'message': Status.MESSAGES.ERROR
							});
						});
					} else {
						UserSchema.update(reqBody, {
							where: {
								user_id: body.data[0].newId
							}
						}).then(userData => {
							console.log("User has been updated successfully.")

							var message = '<!DOCTYPE html><title>Welcome To IotConnect</title><link href="https://fonts.googleapis.com/css?family=Roboto:400,500"rel=stylesheet><body style="font-family:\'Roboto\',sans-serif;font-weight:400;padding:50px;background:#fafafa"><div style="box-shadow:0 4px 18px rgba(0,0,0,.1);padding:30px"><p style=margin-bottom:0;font-size:26px>Hello ' + reqBody.first_name + ' ' + reqBody.last_name + ',<p style=color:#00a8ff;margin-bottom:0;font-size:26px>Congratulations..!<p>You have successfully Signed Up with Smart Office. Please click below to set password for your account.</p><a href="' + process.env.HTTP_PATH + process.env.BASE_URL + ':4200/resetpassword/' + body.data[0].invitationGuid + '" target=_blank><button style="margin-bottom:4px!important;padding:8px 40px;border-radius:3px;border:1px solid #00a8ff;background:#00a8ff;color:#fff;font-size:1rem;text-align:center;cursor:pointer;font-weight:600">Set Password</button></a><p style=margin-bottom:0>Thank You,<p style=margin-top:5px>Team Smart Office.</div>';
							sendMail([reqBody.email], message);

							return res.json({
								'status': 200,
								'data': userData,
								'message': Status.MESSAGES.SUCCESS
							});
						}).catch(error => {
							console.log("Update error", error)
							return res.json({
								'status': 500,
								'data': error,
								'message': Status.MESSAGES.ERROR
							});
						})
					}
				});
			} else {
				return res.json({
					'status': 500,
					'message': body.error[0].message,
					'error': body
				});
			}
		} else {
			return res.json({
				'status': 500,
				'message': Status.MESSAGES.ERROR,
				'error': err
			});
		}
	});
};

exports.updateUser = function (req, res) {
	var userInfo = generalConfig.getUserInfo(req);
	var entityGuid = userInfo.entityGuid;
	var companyGuid = userInfo.companyId;
	var reqBody = req.body;
	var headers = {
		'authorization': req.headers.authorization
	};
	reqBody['companyGuid'] = companyGuid;

	var contactNo = reqBody.phone_code + '-' + reqBody.phone_number;
	reqBody['phone_number'] = contactNo;
	userSdk.updateUser(headers, req.params.userGuid, reqBody.timezone, reqBody.user_type, reqBody.first_name, reqBody.last_name, contactNo, 1, reqBody.email, '', entityGuid, function (err, httpResponse, body) {
		if (!err) {
			if (!reqBody.profile_picture) {
				delete reqBody.profile_picture;
			}
			CompanyUserSchema.update(reqBody, {
				where: {
					user_id: req.params.userGuid
				}
			}).then(userData => {
				if (body.status === 200) {
					UserSchema.update(reqBody, {
						where: {
							user_id: req.params.userGuid
						}
					}).then(userData => {
						return res.json({
							'status': 200,
							'data': body,
							'message': Status.MESSAGES.SUCCESS
						});
					}).catch(error => {
						console.log("Update error", error)
						return res.json({
							'status': 500,
							'data': error,
							'message': Status.MESSAGES.ERROR
						});
					})
				} else {
					return res.json({
						'status': 500,
						'message': Status.MESSAGES.ERROR,
					});
				}
			}).catch(error => {
				console.log("Update Image in database error", error)
			})
		} else {
			return res.json({
				'status': 500,
				'message': Status.MESSAGES.ERROR,
				'error': err
			});
		}
	});
};

function sendMail(recipients, message) {
	var connectionWithMailJet = nodeMailJet.connect(process.env.MAIL_JET_API_KEY, process.env.MAIL_JET_API_SECRET);
	var sendMailJet = connectionWithMailJet.post('send');
	var emailRecipients = [];

	if (recipients && recipients.length) {
		recipients.forEach(function (email) {
			if (email) {
				emailRecipients.push({ 'Email': email });
			}
		});
	}
	var fromEmail = "Smart Office <smartoffice@softwebsolutions.com>";
	var fromName = "IoTConnect";
	var subject = "Welcome to IoTConnect. Your profile has been created.";

	var emailData = {
		'FromEmail': fromEmail,
		'FromName': fromName,
		'Subject': subject,
		'TEXT-part': message,
		'Recipients': emailRecipients,
	}

	sendMailJet.request(emailData).then(function (res) {
		console.log('Send Mail Success')
	}).catch(function (err) {
		console.log('Send Mail Error : ', err)
	});
}

exports.getUser = function (req, res) {
	var userInfo = generalConfig.getUserInfo(req);
	var companyGuid = userInfo.companyId;
	var conditions = {};
	conditions['company_id'] = companyGuid;
	var sortBy = req.query.sortBy ? [req.query.sortBy.split(" ")] : ["user_id", "asc"];
	var pageSize = req.query.pageSize ? parseInt(req.query.pageSize) : 10;
	var pageNumber = req.query.pageNumber ? parseInt(req.query.pageNumber) - 1 : 0;
	var searchText = req.query.searchText ? req.query.searchText : '';

	UserSchema.findAndCountAll({
		where: {
			[Op.or]: [
				{
					first_name: {
						[Op.like]: '%' + searchText + '%'
					},
				}, {
					last_name: {
						[Op.like]: '%' + searchText + '%'
					}
				}, {
					email: {
						[Op.like]: '%' + searchText + '%'
					}
				}, {
					phone_number: {
						[Op.like]: '%' + searchText + '%'
					}
				}
			]
		},
		limit: pageSize,
		offset: pageNumber,
		order: sortBy,
		include: [
			{
				model: CompanyUserSchema,
				where: conditions,
				include: [RoleSchema, CompanySchema]
			}
		],
		distinct: true
	}).then(userData => {
		return res.json({
			'status': 200,
			'success': true,
			'data': userData.rows,
			'recordsTotal': userData.count,
			'recordsFiltered': userData.count,
			'message': Status.MESSAGES.SUCCESS
		});
	});
};

exports.resetPassword = function (req, res) {
	var headers = {
		'authorization': req.headers.authorization
	};
	var reqBody = req.body;
	userSdk.resetPassword(headers, reqBody.username, reqBody.invitationGuid, reqBody.password, function (err, httpResponse, body) {
		if (!err) {
			if (body.status === 200) {
				return res.json({
					'status': 200,
					'data': body,
					'message': Status.MESSAGES.SUCCESS
				});
			} else {
				return res.json({
					'status': 500,
					'message': body.error[0].message,
					'error': body
				});
			}
		} else {
			return res.json({
				'status': 500,
				'message': Status.MESSAGES.ERROR,
				'error': err
			});
		}
	});
};

exports.changeUserStatus = function (req, res) {
	UserSchema.update(req.body, {
		where: {
			user_id: req.params.userGuid
		}
	}).then(userData => {
		return res.json({
			'status': 200,
			'data': userData,
			'message': Status.MESSAGES.SUCCESS
		});
	}).catch(error => {
		console.log("Add error", error)
	});
};

exports.deleteUser = function (req, res) {
	var headers = {
		'authorization': req.headers.authorization
	};
	userSdk.deleteUser(headers, req.params.userGuid, '', function (err, httpResponse, body) {
		if (!err) {
			if (body.status === 200) {
				CompanyUserSchema.destroy({
					where: {
						user_id: req.params.userGuid
					}
				}).then(userData => {
					UserSchema.destroy({
						where: {
							user_id: req.params.userGuid
						}
					}).then(userData => {
						return res.json({
							'status': 200,
							'data': userData,
							'message': Status.MESSAGES.SUCCESS
						});
					}).catch(error => {
						console.log("Add error", error)
					});
				}).catch(error => {
					console.log("Add error", error)
				});
			} else {
				return res.json({
					'status': 500,
					'message': Status.MESSAGES.ERROR,
				});
			}
		} else {
			return res.json({
				'status': 500,
				'message': Status.MESSAGES.ERROR,
				'error': err
			});
		}
	});
};

exports.getUserDetails = function (req, res) {
	var userInfo = generalConfig.getUserInfo(req);
	var companyGuid = userInfo.companyId;
	var innerConditions = {};
	innerConditions['company_id'] = companyGuid;

	var conditions = {};
	conditions['user_id'] = req.params.userGuid;

	UserSchema.findOne({
		where: conditions,
		include: [{
			model: CompanyUserSchema,
			where: innerConditions,
			include: [RoleSchema, CompanySchema]
		}]
	}).then(userData => {
		return res.json({
			'status': 200,
			'success': true,
			'data': userData,
			'message': Status.MESSAGES.SUCCESS
		});
	});
};

exports.getUserLookup = function (req, res) {
	UserSchema.findAll({
		attributes: ['user_id', 'first_name', 'last_name', 'email', ['email', 'value'], ['email', 'display'], 'phone_number', 'profile_picture', 'timezone', 'zip', 'address', 'country_guid', 'status']
	}).then(userData => {
		return res.json({
			'status': 200,
			'success': true,
			'data': userData,
			'message': Status.MESSAGES.SUCCESS
		});
	});
}

exports.uploadUserImage = function (req, res) {
	var userGuid = req.params.userGuid;
	var file = req.files.profile_picture;
	var fileType = 'custom';
	var tag = 'Smart Office';
	var headers = {
		'authorization': req.headers.authorization
	};
	getFile(headers, fileType, userGuid, function (getFileResponse) {
		if (getFileResponse && getFileResponse.data && getFileResponse.data.fileData && getFileResponse.data.fileData.length > 0) {
			var fileGuid = getFileResponse.data.fileData[getFileResponse.data.fileData.length - 1].guid;
			updateFile(headers, fileType, fileGuid, file, tag, function (updateFileResponse) {
				var reqBody = {
					profile_picture: updateFileResponse.data[0].file
				};
				UserSchema.update(reqBody, {
					where: {
						user_id: userGuid
					}
				}).then(userData => {
					return res.json(updateFileResponse);
				}).catch(error => {
					console.log("Update Image in database error", error)
				})
			})
		} else {
			addFile(headers, fileType, userGuid, file, tag, function (updateFileResponse) {
				var reqBody = {
					profile_picture: updateFileResponse.data[0].file
				};
				UserSchema.update(reqBody, {
					where: {
						user_id: userGuid
					}
				}).then(userData => {
					return res.json(updateFileResponse);
				}).catch(error => {
					console.log("Update Image in database error", error)
				})
			})
		}
	});
};

function getFile(headers, fileType, fileGuid, callback) {
	try {
		fileSDK.getFileList(headers, fileType, fileGuid, function (err, httpResponse, body) {
			if (httpResponse.statusCode === 200) {
				return callback(body)
			} else {
				return callback(body)
			}
		});
	} catch (e) {
		return callback(e)
	}
}

function addFile(headers, fileType, fileTypeGuid, file, tag, callback) {
	try {
		fileSDK.uploadFile(headers, fileType, fileTypeGuid, file, tag, function (err, httpResponse, body) {
			if (httpResponse.statusCode === 200) {
				body = JSON.parse(body);
				return callback(body)
			} else {
				return callback(body)
			}
		});
	} catch (e) {
		return callback(e)
	}
}

function updateFile(headers, fileType, fileGuid, file, tag, callback) {
	try {
		fileSDK.updateFile(headers, fileType, fileGuid, file, tag, function (err, httpResponse, body) {
			if (httpResponse.statusCode === 200) {
				body = JSON.parse(body);
				return callback(body)
			} else {
				return callback(body)
			}
		});
	} catch (e) {
		return callback(e)
	}
}

exports.changePassword = function (req, res) {
	var reqBody = req.body;
	var headers = {
		'authorization': req.headers.authorization
	};

	userSdk.userChangePassword(headers, reqBody.email, reqBody.old_password, reqBody.new_password, '', function (err, httpResponse, body) {
		if (!err) {
			if (body.status === 200) {
				return res.json({
					'status': 200,
					'data': body,
					'message': Status.MESSAGES.SUCCESS
				});
			} else {
				return res.json({
					'status': 500,
					'message': body.error[0].message,
					'error': body
				});
			}
		} else {
			return res.json({
				'status': 500,
				'message': Status.MESSAGES.ERROR,
				'error': err
			});
		}
	});
};