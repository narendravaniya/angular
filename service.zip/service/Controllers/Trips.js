'use strict';
var TripsModel= require('../Models/Trips');
var tripsModel= new TripsModel();

var Status = require('../Config/Status');
var GeneralConfig = require('../Config/GeneralConfig');

exports.add = function (req, res) {
	tripsModel.add(req.body).then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.edit = function (req, res) {
	tripsModel.edit(req.params.id, req.body).then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.updateStatus = function (req, res) {
	tripsModel.edit(req.params.id, req.body).then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.get = function (req, res) {
	var userInfo = GeneralConfig.getUserInfo(req);
	tripsModel.getList(req.query, userInfo).then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.getDetails = function (req, res) {
	tripsModel.get(req.params.id).then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.delete = function (req, res) {
	tripsModel.delete(req.params.id).then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.startSimulator = function (req, res) {
	
	if(req.params.isSalesTemplate === true || req.params.isSalesTemplate === 'true'){
		tripsModel.startSimulator(req.params.id, req.headers.authorization).then(data => {
			res.send(data);
		}).catch(error => {
			res.send({
				status: Status.CODES.SERVER_ERROR.CODE,
				message: Status.CODES.SERVER_ERROR.MESSAGE
			});
		})
	}else{
		tripsModel.startSimulatorOld(req.params.id, req.headers.authorization).then(data => {
			res.send(data);
		}).catch(error => {
			res.send({
				status: Status.CODES.SERVER_ERROR.CODE,
				message: Status.CODES.SERVER_ERROR.MESSAGE
			});
		})
	}
	
};

exports.getGeoCoordinates = function (req, res) {
	tripsModel.getGeoCoordinates(req.params.origin, req.params.destination).then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};

exports.getDuration = function (req, res) {
	tripsModel.getDuration(req.params.origin, req.params.destination).then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE
		});
	})
};