'use strict';
var GeneralConfig = require('../Config/GeneralConfig');
var Status = require('../Config/Status');

var DashboardModel = require('../Models/Dashboard');
var dashboardModel = new DashboardModel();

exports.getStatistics = function (req, res, next) {
	var userInfo = GeneralConfig.getUserInfo(req);
	dashboardModel.getStatistics(userInfo).then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE,
			error
		});
	})
}

exports.getFleetNotification = function (req, res, next) {
	dashboardModel.getFleetNotification().then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE,
			error
		});
	})
}

exports.getTruckUsage = function (req, res, next) {
	dashboardModel.getTruckUsage().then(data => {
		res.send(data);
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE,
			error
		});
	})
}

exports.getTruckActivity = function (req, res, next) {
	dashboardModel.getTruckActivity(req.headers.authorization).then(data => {
		res.send({
			status: Status.CODES.SUCCESS.CODE,
			message: Status.CODES.SUCCESS.MESSAGE,
			data
		});
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE,
			error
		});
	})
}

exports.getDeviceAttributes = function (req, res, next) {
	dashboardModel.getDeviceAttributes(req.headers.authorization, req.body.device_id).then(data => {
		res.send({
			status: Status.CODES.SUCCESS.CODE,
			message: Status.CODES.SUCCESS.MESSAGE,
			data: data.data
		});
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE,
			error
		});
	})
}

exports.getTruckGraph = function (req, res, next) {
	dashboardModel.getTruckGraph().then(data => {
		res.send({
			status: Status.CODES.SUCCESS.CODE,
			message: Status.CODES.SUCCESS.MESSAGE,
			data
		});
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE,
			error
		});
	})
}

exports.getStompConfiguration = function (req, res, next) {
	dashboardModel.getStompConfiguration(req.headers.authorization).then(data => {
		res.send({
			status: Status.CODES.SUCCESS.CODE,
			message: Status.CODES.SUCCESS.MESSAGE,
			data
		});
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE,
			error
		});
	})
}

exports.getDeviceAttributeHistoricalData = function (req, res, next) {
	dashboardModel.getDeviceAttributeHistoricalData(req.headers.authorization, req.body).then(data => {
		res.send({
			status: Status.CODES.SUCCESS.CODE,
			message: Status.CODES.SUCCESS.MESSAGE,
			data
		});
	}).catch(error => {
		res.send({
			status: Status.CODES.SERVER_ERROR.CODE,
			message: Status.CODES.SERVER_ERROR.MESSAGE,
			error
		});
	})
}