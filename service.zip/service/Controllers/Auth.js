'use strict';
var generalConfig = require('../Config/GeneralConfig');
var Status = require('./../Config/Status');
var userSchema = require('./../Schema/Users');
var Authenticate = require('../Config/Authenticate');
authenticate = new Authenticate();

require('dotenv').config();
var IotConnect = require("IoTConnect");
var iotConnect = IotConnect.init('key', process.env.ENVIRONMENT);
var authSdk = iotConnect.Auth;
var masterSdk = iotConnect.Master;
var userSdk = iotConnect.User;

exports.getBasicToken = function (req, res) {
	try {
		authSdk.getToken(function (err, response, body) {
			if (err) {
				return res.status(err.status).json(err);
			} else {
				var result = JSON.parse(body);
				return res.status(result.status).json(result);
			}
		});
	} catch (err) {
		console.log("TCL: exports.getBasicToken -> err", err)
	}
}

exports.login = function (req, res, next) {
	var headers = {
		'Content-Type': 'application/json',
		'Authorization': req.headers.authorization,
		'solution-key': process.env.IOT_CONNECT_SOLUTION_KEY
	}
	authSdk.signIn(headers, req.body.username, req.body.password, '', '', function (err, response, body) {
		body.access_token = authenticate.encode(body.access_token);
		return res.status(body.status).json(body);
	});
};

exports.getUserInfo = function (req, res, next) {
	var headers = {
		'authorization': req.headers.authorization
	};
	var userInfo = generalConfig.getUserInfo(req);
	if (userInfo) {
		var user_id = userInfo.id;
		userSdk.getUserByGuid(headers, userInfo.id, null, function (err, httpResponse, body) {
			userSchema.findOne({
				where: {
					user_id: user_id
				}
			}).then(function (user) {
				if (user) {
					user.dataValues['parentEntityGuid'] = body.data[0].parentEntityGuid;
					res.json({
						success: true,
						data: user,
						message: Status.MESSAGES.SUCCESS
					});
				}
			}).catch(function (err) {
				res.json({
					error: true,
					data: err,
					message: Status.MESSAGES.ERROR
				});
			});
		});
	}
};

exports.getCountry = function (req, res) {
	masterSdk.getCountry(function optionalCallback(err, httpResponse, result) {
		if (err) {
			return res.status(err.status).json(err);
		} else {
			return res.json(result);
		}
	});
}

exports.getState = function (req, res) {
	masterSdk.getState(req.params.countryGuid, function optionalCallback(err, httpResponse, result) {
		if (err) {
			return res.status(err.status).json(err);
		} else {
			return res.json(result);
		}
	});
};

exports.getEntity = function (req, res) {
	var headers = {
		'Content-Type': 'application/json',
		'Authorization': req.headers.authorization,
	}
	userSdk.getEntityLookupList(headers, function optionalCallback(err, httpResponse, result) {
		if (err) {
			return res.status(err.status).json(err);
		} else {
			return res.json(result);
		}
	});
};