<?php

namespace models;


abstract class RequirementEnum
{
    const NO_PREFERENCE = 0;
    const NON_SMOKING   = 1;
    const SMOKING       = 2;
}
