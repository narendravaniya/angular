var mysql = require('mysql');
var connection = mysql.createConnection({
				 host     : 'lynx.corpnet.co.in',
				 port	  : '3305',
                 user     : 'staging',
                 password : 'MySQLDevIT@#123',
                 database : 'nodejs_demo'
               });

connection.connect(function(err) {
	if(err){
		console.log('Error connecting to Db');
		return;
	}
		global.db = connection;
		console.log('Connection established!');
});

module.exports = global.db;