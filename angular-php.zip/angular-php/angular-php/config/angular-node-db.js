var mysql = require('mysql');
var connection = mysql.createConnection({
				 host     : '192.168.4.25',
				 port	  : '3305',
                 user     : 'staging',
                 password : 'MySQLDevIT@#123',
                 database : 'anguler-node'
               });

connection.connect(function(err) {
	if(err){
		console.log('Error connecting to Db');
		return;
	}
		global.angulardb = connection;
		console.log('Connection established!');
});

module.exports = global.angulardb;