var roles = {
    
        getAllroles:function(callback){
            return db.query("Select * from role_master",callback);
        },
    
        getrolesById:function(id,callback){
            return db.query("select * from role_master where id=?",[id],callback);
        },
    
        addroles:function(insert_data,callback){       
            return db.query("Insert into role_master set ?",insert_data,callback);        
        },
    
        deleteroles:function(id,callback){
            return db.query("delete from role_master where id=?",[id],callback);
        },
        
        updateroles:function(update_data, id, callback){                
            return db.query('UPDATE role_master set ? where id = ?',[update_data,id],callback);
        },
    };
    module.exports=roles;