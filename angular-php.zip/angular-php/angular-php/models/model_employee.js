var Employee = {
    
        addEmployee:function(insert_data,callback){       
            return angulardb.query("insert into employees set ?",insert_data,callback);        
        },

        getAllEmployee:function(callback){
            return angulardb.query("Select * from employees",callback);
        },

        deleteEmployee:function(id,callback){
            
            return angulardb.query("delete from employees where _id='"+id+"'",callback);
        },
        selectone:function(id,callback){
            
            return angulardb.query("select * from employees where _id='"+id+"'",callback);
        },
        update:function(id,name,position,department,salary,callback){
            
            return angulardb.query("update employees set _id='"+id+"',name='"+name+"',position='"+position+"',department='"+department+"',salary='"+salary+"' where _id='"+id+"'",callback);
        },
        
        
        
    };
    module.exports=Employee;