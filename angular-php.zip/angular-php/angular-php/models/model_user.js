var User = {

    validateUser:function(email,password,callback){
       return db.query("select * from user where email = ? and password = ? and status= 'Active'",[email,password], callback); 
    },

    registerUser:function(userregister_data,callback){        
        return db.query('insert into user set ?', userregister_data, callback);
    },

    updateUserByKey:function(randomkey,userUpdate_data,callback){        
        var update_sql = 'update user SET ? where randomkey = ?';
        return db.query(update_sql,[userUpdate_data,randomkey],callback);
    },

    fetchUser:function(id=0, email='', callback){	
        if(id > 0){
            var whereClause = ['id', id];
        }
        else if(email != ''){
            var whereClause = ['email', email];
        }
        return db.query("select * from user where ?? = ?",whereClause, callback); 
     },
     
    updateUserById:function(userUpdate_data, id, callback){
        var update_sql = 'UPDATE user set ? where id = ?';
        return db.query(update_sql,[userUpdate_data,id],callback);
    },

    check_unique_email:function(user_email,callback){
        return db.query('select email from user where email = ?',[user_email],callback);
    },

    getAllusers:function(callback){
        return db.query("Select * from user order by name",callback);
    },

    latestusers:function(callback){
        return db.query("SELECT name,profile_pic,DATE_FORMAT(`created_date`, '%W %D %M %Y') as created_month FROM user order by created_date DESC LIMIT 4",callback);
    },

    fetchuserbymonth:function(callback){
        return db.query("select count(id) as userCount, DATE_FORMAT(`created_date`, '%b %y') as created_month from user  WHERE `created_date` > DATE_SUB(now(), INTERVAL 12 MONTH) GROUP BY DATE_FORMAT(`created_date`, '%M') order by created_date",callback);
    }

    
};

module.exports=User;  