var Customer = {

    getAllCustomers:function(callback){
        return db.query("Select * from customer limit 4",callback);
    },

    getCustomerById:function(id,callback){
        return db.query("select * from customer where id=?",[id],callback);
    },

    addCustomer:function(insert_data,callback){       
        return db.query("Insert into customer set ?",insert_data,callback);        
    },

    deleteCustomer:function(id,callback){
        return db.query("delete from customer where id=?",[id],callback);
    },
    
    updateCustomer:function(update_data, id, callback){                
        return db.query('UPDATE customer set ? where id = ?',[update_data,id],callback);
    },
};
module.exports=Customer;