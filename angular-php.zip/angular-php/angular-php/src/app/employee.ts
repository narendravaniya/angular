export class Employee {
    // constructor(
    //     public name: string,
    //     public position: string,
    //     public department: string,
    //     public salary: string
    // ){}
    name: string;
    position: string;
    department: string;
    salary: string;
}
