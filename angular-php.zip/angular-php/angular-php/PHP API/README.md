# angular2_crud_php_mysql_api

## Import mydb.sql into your database
## api includes the following files
## db.php
## select.php
## selectone.php
## insert.php
## delete.php
## update.php