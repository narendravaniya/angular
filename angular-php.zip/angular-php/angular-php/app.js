
/**
 * Module dependencies.
 */
var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');

var flash = require('express-flash');

/* Session */
var session = require('express-session');
var expressValidator = require('express-validator');
var methodOverride = require('method-override');
var connection  = require('express-myconnection'); 
var mysql = require('mysql');

var app = express();
//view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// all environments
app.use(logger('dev'));
//app.use(favicon());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

/* appDir variable used as Global */
global.appDir = path.dirname(require.main.filename);

/* Session */
app.use(session({
	secret: '2C44-4D44-WppQ38S',
	resave: true,
	saveUninitialized: false,
  }))
/* Session End */
  
app.use(flash());
app.use(expressValidator());
app.use(methodOverride(function(req, res){
	if (req.body && typeof req.body == 'object' && '_method' in req.body){ 
	      var method = req.body._method;
	      delete req.body._method;
	      return method;
	    } 
	  }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));


app.use(function (req, res, next) {
	
		// Website you wish to allow to connect
		res.header('Access-Control-Allow-Origin', '*');
	
		// Request methods you wish to allow
		res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
	
		// Request headers you wish to allow
		res.header('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
	
		// Set to true if you need the website to include cookies in the requests sent
		// to the API (e.g. in case you use sessions)
		res.header('Access-Control-Allow-Credentials', true);
	
		// Pass to next layer of middleware
		next();
	});

/* configuring database */
var db = require('./config/db');
var angulardb = require('./config/angular-node-db');

// Include Routing
var routes = require('./routes/routing')(app);
 
//module.exports = app;
app.listen(4500, function () {
	  console.log('Example app listening on port 4500!')
})