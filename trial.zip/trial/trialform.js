import React from 'react';

class Trialfrm extends React.Component {
  render() {
    const { mainobj,clickevent,addnext,save,test,hobby,toggleChange,isChecked } = this.props;
     return (
        <div>
          {test.map((items, index) =>
           <div>
          <label>todate:</label>
          <select name="todate" onChange={(e)=>clickevent(e)}>
            <option>1</option>
            <option>2</option>
            <option>3</option>
          </select>
          <label>fromdate:</label>
          <select name="fromdate" onChange={(e)=>clickevent(e)}>
            <option>1</option>
            <option>2</option>
            <option>3</option>
          </select>
          <label>visittype:</label>
          <select name="visittype" onChange={(e)=>clickevent(e)}>
            <option>1</option>
            <option>2</option>
            <option>3</option>
          </select>
          <label>visitname:</label>
          <input type="text" name="visit_name" onChange={(e)=>clickevent(e)}/>
          {hobby.map((hobbyname, i) =>
          <label>
        <input type="checkbox"
         name="hobby" id={i}
        onChange={(e)=>toggleChange(e,i)}
        />
        {hobbyname}
       </label>
           )}
          <input type="button" name="test" value="add" onClick={(e)=>addnext(index)} />
          </div>
          )}
           <input type="button" name="test" value="save" onClick={(e)=>save()} />
        </div>
     )
  }
}
export default Trialfrm;