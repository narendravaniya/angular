import React from 'react';
import Trialfrm from './trialform';
class Manage extends React.Component {
  
  constructor(props) {
    let data = {"todate":"","fromdate":"","visittype":"","visit_name":"","hobby":[]} 
     super(props);
     this.state = {
        mainobjs:Object.assign({}, data),
        mainarry:[],
        hobby:["cricket","football","chess","swaming"],
        //isChecked: false
      }
      this.demo();
     this.abc = this.abc.bind(this);
     this.save = this.save.bind(this);
     this.addnext = this.addnext.bind(this);
     this.toggleChange = this.toggleChange.bind(this);
     
  }
  demo(){
    this.state.mainarry.push(this.state.mainobjs);
  }
  save(e){
   
    console.log("this namess",this.state.mainarry);
  }
  abc(e){
    var mainobjs =  this.state.mainobjs;
    //this.setState({mainobjs:mainobjs});
    const field = e.target.name;
    mainobjs[field]=e.target.value;
    
    this.setState({mainobjs:mainobjs});
  }
  addnext(id){
    var datas =  this.state.mainobjs;
    var abc = Object.assign({"id":id}, datas);
    console.log("this statesss",abc);
    this.state.mainarry.push(abc);
   var mainobjs = this.state.mainobjs;
   mainobjs["hobby"] = [];
   //this.state.mainobjs.push(this.state.mainobjs);
   this.setState({mainobjs:mainobjs});
   this.setState({mainarry:this.state.mainarry});
   
  }
  toggleChange(e,id){
    var hobby=this.state.hobby;
    hobby.map((hobbyname, i) =>{
      if(i == id){

        var mainobjs =  this.state.mainobjs;
        //this.setState({mainobjs:mainobjs});
        const field = e.target.name;
        mainobjs[field].push(id);
        //hobbyname= e.target.checked;
        //this.setState({isChecked:true});
        this.setState({mainobjs:mainobjs});
      console.log("hobbyname",id);
      
      }
    })
    //this.setState({hobby:hobby});
  }
  render() {
     return (
        <div>
          <Trialfrm mainobj={this.state.mainobjs} test={this.state.mainarry} clickevent ={this.abc} addnext={this.addnext} save ={this.save} hobby={this.state.hobby}  toggleChange={this.toggleChange} isChecked={this.state.isChecked}  />
        </div>
     );
  }
}
export default Manage;