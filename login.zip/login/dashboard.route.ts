import { ModuleWithProviders } from "@angular/core";
import { Route, RouterModule } from "@angular/router";
import { DashboardComponent } from "./dashboard.component";
import { AdminComponent } from "../admin.component";
import { AuthGuard } from "../../shared/guards/auth.guard";


const routes: Route[] = [
  {
    path: '',
    component: AdminComponent,
    data: {
      breadcrumbs: 'Home'
    },
    canActivate: [AuthGuard],
    children: [
      {
        path: 'dashboard',
        component: DashboardComponent,
        data: {
          breadcrumbs: 'Dashboard',
          title:"CORE - Dashboard",
        },
        
        //,children: [
        //   {
        //     path: '',
        //     component: DashboardComponent
        //   },
        // ]
      }
    ]
  }
];


export const dashboardRoute: ModuleWithProviders = RouterModule.forRoot(routes);