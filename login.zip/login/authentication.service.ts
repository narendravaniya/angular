import { LoginService } from './data/login.service';
import { Injectable } from '@angular/core';
import { JwtHelper } from 'angular2-jwt';
import { LocalStorageService } from './localstorage.service';
import { AppConst } from '../constants/app.const';
import { CenterLoginService } from './data/centerlogin.service';
import { ParentLoginService } from './data/parentlogin.service';


@Injectable()
export class AuthenticationService {
  centerkey = AppConst.centerkey;
  children_id = AppConst.children_id_key;
  authKey = AppConst.authKey;
  leadKey = AppConst.lead_id_key;
  jwtHelper: JwtHelper = new JwtHelper();
  constructor(private centerloginService: CenterLoginService, private parentloginService: ParentLoginService, private localStorageService: LocalStorageService,

  ) {
  }

  private getToken() {
    return this.localStorageService.get(this.authKey);
  }

  getcentertoken() {
    return this.localStorageService.get(this.centerkey);
  }


  centerlogin(data) {
    return this.centerloginService.create(data)
      .map(obj => {
        if (obj && obj.data && obj.data.data && obj.data.data.token)
          this.localStorageService.set(this.authKey, obj.data.data.token);
        this.localStorageService.set(this.centerkey, obj.data.data.token_center);
        this.localStorageService.remove(this.leadKey);
        //console.log(obj);
        return obj;
      });
  }


  parentlogin(data) {
    return this.parentloginService.create(data)
      .map(obj => {
        if (obj && obj.data && obj.data.data && obj.data.data.token_parent)
          this.localStorageService.set(this.authKey, obj.data.data.token_parent);
          this.localStorageService.remove(this.leadKey);
        //console.log(obj);
        return obj;
      });
  }

  logout() {

    // return this.localStorageService.remove(this.authKey);
    this.localStorageService.remove(this.authKey);
    this.localStorageService.remove("allchildrendata")
    this.localStorageService.remove("childrendata");
    this.localStorageService.remove("_centerkey");
    this.localStorageService.remove(this.children_id);
    this.localStorageService.remove("Is.User");
    this.localStorageService.remove("Is.UserToken");
    this.localStorageService.remove("Is.PaymentsSelectedSchool");
  }

  getUser() {
    var token = this.getToken();
    if (token) {
      return this.jwtHelper.decodeToken(token);
    }
    return {};
  }

  getcenterdata() {
    var token = this.getcentertoken();
    if (token) {
      return this.jwtHelper.decodeToken(token);
    }
    return {};
  }

  isLoggedIn() {
    var token = this.getToken();
    if (token && !this.jwtHelper.isTokenExpired(token)) {
      return true;
    }
    else {
      return false;
    }
  }
}
