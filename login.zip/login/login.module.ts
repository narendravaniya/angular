import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

/* Registration Common */
import { LoginComponent } from './login.component';

/* Registration Route */
import { loginRoute } from "./login.route";
import { LoginService } from '../shared/services/data/login.service';
import { CenterLoginService } from '../shared/services/data/centerlogin.service';
import { ParentLoginService } from '../shared/services/data/parentlogin.service';

@NgModule({
  imports: [
    CommonModule,
    loginRoute,
    FormsModule
  ],
  declarations: [
    LoginComponent
  ],
  providers: [CenterLoginService,ParentLoginService],
  exports: []
})

export class LoginModule { }
