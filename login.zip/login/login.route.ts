import { ModuleWithProviders } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { LoginComponent } from "./login.component";

const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent,
    data: {
          breadcrumbs: 'CORE - Login',
          title:'CORE - Login'
        }
  },
  {
    path: 'parent/login',
    component: LoginComponent,
    data: {
         breadcrumbs: 'CORE - Parent Login',
         title:'CORE - Parent Login'
        }
  }
];

export const loginRoute: ModuleWithProviders = RouterModule.forRoot(routes);