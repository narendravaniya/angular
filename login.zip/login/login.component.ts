import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Params, Router, NavigationEnd } from '@angular/router';
import { Login } from '../shared/models/login/login';
import { AuthenticationService } from '../shared/services/authentication.service';
import { LoaderService } from '../shared/services/loader.service';
import { CenterService } from '../shared/services/data/center.service';
import { GridOption } from '../core/models/gridOption.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [AuthenticationService]
})

export class LoginComponent implements OnInit {
  authHeader: any = 'NO';
  router;
  token: any;
  centerdata: any;
  gridOption: GridOption = {
    id: "",
    pagesize: -1,
    order: "name"
  }
  routeurl: string;
  parenturl: string;
  hosturl: string;
  currentURL: string;
  title = 'Login';
  @Input() formData;
  message: any;
  login: any;
  status: any;
  loginscreen: string = '';
  event: string = '';
  constructor(private authenticationService: AuthenticationService, private loaderService: LoaderService, private centerService: CenterService, router: Router) {

    router.events
      .filter((event) => event instanceof NavigationEnd)
      .subscribe(event => {
        if (event['url'] == '/parent/login') {
          this.loginscreen = 'parent';
        } else {
          this.loginscreen = 'admin';
        }
      });
    this.router = router;
  }
  ngOnInit() {
    if ((this.router.url == "/parent/login")) {
      this.getCenter();
    }
    if (this.router.url == "/login") {
      document.body.classList.add('login');
      document.body.classList.remove('parent');
    }

    else if (this.router.url == "/parent/login") {
      document.body.classList.add('parent');
      document.body.classList.remove('login');
    }


  }

  model = new Login();
  checkLogin() {
    this.loaderService.display(true);
    this.routeurl = this.router.url;
    this.parenturl = '/parent/login';
    if (this.routeurl == this.parenturl) {
      this.model.school_name = "DevTest2";
      this.authenticationService
        .parentlogin(this.model)
        .subscribe(login => {
          this.loaderService.display(false);
          this.login = login.data.data
          this.token = this.login.Token

          this.message = this.login.Message
          //this.status = login.status
          if (this.token) {
            this.router.navigate(['/parent/dashboard']);
          }


        })
    } else {
      delete this.model.school_name;
      this.authenticationService
        .centerlogin(this.model)
        .subscribe(login => {
          this.loaderService.display(false);
          this.login = login.data.data
          this.token = this.login.token_center

          this.message = this.login.Error
          //this.status = login.status
          if (this.token) {
            this.router.navigate(['/dashboard']);
          }

        })
    }

  }


  getCenter() {
    this.centerService.searchAll(this.gridOption, this.authHeader)
      .subscribe(center => {
        this.centerdata = center.data.data;

      });
  }



}
