// import { BadInput } from './../common/bad-input';
// import { NotFoundError } from './../common/not-found-error';
// import { AppError } from './../common/app-error';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';
import { environment } from '../../../environments/environment';
import 'rxjs/add/operator/timeout'
import { AppConst } from '../../shared/constants/app.const';

@Injectable()
export class DataService {
  authKey = AppConst.authKey;
  constructor(private urlModule: string, private http: Http) {
  }

  url = environment.baseUrl + this.urlModule;
  headers = new Headers({ 'Content-Type': 'application/json', 'Accept': 'application/json', 'x-api-key': '9hkQWDnnXE28bw7lo9Tau6ge5crMVwbJ8vaEYGJM', 'Authorization': "Bearer " + JSON.parse(localStorage.getItem(this.authKey)), center_id: localStorage.getItem('global_center_id') });

  //headers = new Headers({ 'Content-Type': 'application/json', 'Accept': 'application/json', 'x-api-key': '9hkQWDnnXE28bw7lo9Tau6ge5crMVwbJ8vaEYGJM', 'Authorization': "Bearer " + JSON.parse(localStorage.getItem(this.authKey)),center_id:localStorage.getItem('global_center_id')});
  //headers = new Headers({ 'Content-Type': 'application/json', 'Accept': 'application/json','x-api-key': '9hkQWDnnXE28bw7lo9Tau6ge5crMVwbJ8vaEYGJM','chk_role_permission':'NO'});

  options = new RequestOptions({ headers: this.headers });

  ModuleAction: any = ['search'];
  MasterModule: any = ['state', 'relation', 'gender', 'classroom', 'status', 'group', 'bill_cycle', 'program'];
  AuthModule: any = ['customer', 'sponsor', 'billing'];
  AuthReadModule: any = ['lead', 'dashboard', 'dashboard_calendar'];

  //MethodAction:any=['GET','POST','PATCH','DELETE']


  // to set check role permission in headers
  authset(authentication) {
    // if (this.MasterModule.indexOf(this.urlModule) !== -1) {
    //   this.headers.set('chk_role_permission', 'NO');
    // } else {
    //   this.headers.set('chk_role_permission', 'YES');
    //   if (this.AuthModule.indexOf(this.urlModule) !== -1) {          
    //       if (authentication == 'NO' || authentication == '' || !authentication) {
    //         this.headers.set('chk_role_permission', 'NO');
    //       } else {

    //       }
    //   }
    // }

    if(authentication=='YES')
    {
      this.headers.set('chk_role_permission', 'YES');
    }
    else {
      this.headers.set('chk_role_permission', 'NO');
    }
  }

  getAll(authentication = '') {
    this.authset(authentication);
    return this.http.get(this.url, this.options)
      .map(response => response.json())
      .catch(this.handleError);
  }

  getOne(id, authentication = '') {
    this.authset(authentication);
    return this.http.get(this.url + "/" + id, this.options)

      .map(response => response.json())
      .catch(this.handleError);
  }


  getsearchObject(searchObj, authentication = '') {
    this.authset(authentication);
    return this.http.get(this.url + "?" + searchObj, this.options)

      .map(response => response.json())
      .catch(this.handleError);
  }

  searchAll(searchObj, authentication = '') {
    this.authset(authentication);
    return this.http.post(this.url + "/search", JSON.stringify(searchObj), this.options)

      .map(response => response.json())
      .catch(this.handleError);
  }

  create(resource, authentication = '') {
    this.authset(authentication);
    return this.http.post(this.url, JSON.stringify(resource), this.options)

      .map(response => response.json())
      .catch(this.handleError);
  }

  update(resource, authentication = '') {
    this.authset(authentication);
    return this.http.patch(this.url + '/' + resource.id, JSON.stringify(resource), this.options)

      .map(response => response.json())
      .catch(this.handleError);
  }

  delete(id, authentication = '') {
    this.authset(authentication);
    return this.http.delete(this.url + '/' + id, this.options)

      .map(response => response.json())
      .catch(this.handleError);
  }

  private handleError(error: Response) {
    return Observable.throw(new Error(error.toString()));
    //     if (error.status === 400)
    //       return Observable.throw(new BadInput(error.json()));

    //     if (error.status === 404)
    //       return Observable.throw(new NotFoundError());

    //     return Observable.throw(new AppError(error));
  }
}
