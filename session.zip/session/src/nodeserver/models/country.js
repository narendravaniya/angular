/*
module.exports = function(sequelize, Sequelize) {
    var BookSchema = sequelize.define('Book', {
        title: Sequelize.STRING,
        author: Sequelize.STRING,
        category: Sequelize.STRING
    },{
        timestamps: false
    });
    return BookSchema;
}
*/

  module.exports = function (sequelize, DataTypes) {
        var Country = sequelize.define('Country', {
            id: {
                type: DataTypes.INTEGER,
                autoIncrement: true,
                primaryKey: true
            },
            name: {
                type: DataTypes.STRING(50),
                unique:
                    {
                        args: true
                    },
                allowNull: false
            },
            is_active: {
                type: DataTypes.BOOLEAN,
                allowNull: false,
                defaultValue: true
            },
        }, {
                underscored: true,
                timestamps: true,
                paranoid: true,
                freezeTableName: true,
                tableName: 'countries'
            });
       
        return Country;
    }