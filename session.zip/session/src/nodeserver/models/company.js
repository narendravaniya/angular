/*
module.exports = function(sequelize, Sequelize) {
    var BookSchema = sequelize.define('Book', {
        title: Sequelize.STRING,
        author: Sequelize.STRING,
        category: Sequelize.STRING
    },{
        timestamps: false
    });
    return BookSchema;
}
*/

  module.exports = function (sequelize, DataTypes) {
        var User = sequelize.define('User', {
            id: {
                type: DataTypes.INTEGER,
                autoIncrement: true,
                primaryKey: true
            },
            firstname: {
                type: DataTypes.STRING(50),
               
            },
			lastname: {
                type: DataTypes.STRING(50),
               
            },
            email: {
                type: DataTypes.STRING(255),
                allowNull: true
            },
            phone: {
                type: DataTypes.INTEGER,
                allowNull: true
            },
            gender: {
                type: DataTypes.STRING(255),
                allowNull: true
            },
            status: {
                type: DataTypes.BOOLEAN,
                allowNull: false,
                defaultValue: true
            }
        },
            {
                underscored: true,
                timestamps: true,
                paranoid: false, /* soft delete true or hard delete false */
                freezeTableName: true,
                tableName: 'user',
                indexes: [
                    {
                        fields: ['name']
                    },
                ]
            });
            
        User.associate = function (models) {
            User.belongsTo(models.Country, {
                as: 'country',
                onDelete: "CASCADE",
                foreignKey: {
                    name: 'country_id',
                    allowNull: true
                }
            });
            
           
          
          
        };

        return User;
    }