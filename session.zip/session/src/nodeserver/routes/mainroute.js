var express = require('express');
var models = require('../models');
var router = express.Router();

/* Get all records..  */
router.get('/getuserlist', function(req, res){
options ={
include: [{
    model: models.Country,
	as:'country'
	//,
    //where: {id: 2}
   }]
}
      
    models.User.findAll(options).then(users => {
        res.json({"data" : users, message: "Success", status : 200});
    }).error(err => {
		var error = {
			data : null,
			status : 404,
			message : "Error. Payload Getting Blank."
		}
		res.json({"data" : error});
});
});

/* Get one record */
router.get('/:id', function(req, res){

    
    models.User.findById(req.params.id).then(oneuser => {
        res.json({"data" : oneuser, message: "Success", status : 200});
    }).error(err => {
		var error = {
			data : null,
			status : 404,
			message : "Error. Payload Getting Blank."
		}
		res.json({"data" : error});
	
    /* another ways to do it 
    models.User.findById({ where: {Userid: req.params.id} }).success(book => {
        console.log(book);
        res.json(book);
    }).error(err => {
        res.send('error has occured');
    });
 */   
});
});

/* Insert records..  */
router.post('/add', function(req, res){
    models.User.create({ 
       firstname: req.body.firstname,
        lastname: req.body.lastname, 
        email: req.body.email,
        phone: req.body.phone,
		gender: req.body.gender,
		status: req.body.status,
		country_id: req.body.country_id
    }).then(frmdata => {
	res.json({"data" : frmdata, message: "Success", status : 200});	
					
    }).error(err => {
		var error = {
			data : null,
			status : 404,
			message : "Error. Payload Getting Blank."
		}
		res.json({"data" : error});
    });
});

/* Update records..  */
router.put('/:id', function(req, res){
    models.User.update({
        firstname: req.body.firstname,
        lastname: req.body.lastname, 
        email: req.body.email,
        phone: req.body.phone,
		gender: req.body.gender,
		status: req.body.status,
		country_id: req.body.country_id
    },{ 
        where: { id: req.params.id } 
    }).then(result => {
        res.json({"data" : result, message: "Success", status : 200});	
    }).error(err => {
		var error = {
			data : null,
			status : 404,
			message : "Error. Payload Getting Blank."
		}
		res.json({"data" : error});
    });
});

/* Delete records..  */
router.delete('/:id', function(req, res){
    models.User.destroy({ 
        where: { Userid: req.params.id } 
    }).then(result => {
        res.status(200).json(result);
    });
});

module.exports = router;