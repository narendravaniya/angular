var express = require('express');
var models = require('../models');
var router = express.Router();

/* Get all records..  */
router.get('/getcountrieslist', function(req, res){
	/*
options ={
include: [{
    model: models.Country,
	as:'country'
	//,
    //where: {id: 2}
   }]
}
 */     
    
    models.Country.findAll().then(country => {
		res.json({"data" : country, message: "Success", status : 200});
        //res.json(country);
    }).error(err => {
		var error = {
			data : null,
			status : 404,
			message : "Error. Payload Getting Blank."
		}
		res.json({"data" : error});
    });
});

/* Get one record */
router.get('/:id', function(req, res){

    console.log('getting one book');
    models.User.findById(req.params.id).then(book => {
        console.log(book);
        res.json(book);
    });
	
    /* another ways to do it 
    models.User.findById({ where: {Userid: req.params.id} }).success(book => {
        console.log(book);
        res.json(book);
    }).error(err => {
        res.send('error has occured');
    });
 */   
});

/* Insert records..  */
router.post('/add', function(req, res){
    models.User.create({ 
       firstname: req.body.firstname,
        lastname: req.body.lastname, 
        email: req.body.email,
        phone: req.body.phone,
		gender: req.body.gender,
		status: req.body.status,
		country_id: req.body.country_id
    }).then(book => {
        console.log(book.get({
          plain: true
        }));
        res.send(book);
    });
});

/* Update records..  */
router.put('/:id', function(req, res){
    models.User.update({
        name: req.body.name,
        address_line_1: req.body.address_line_1, 
        address_line_2: req.body.address_line_2,
        address_line_3: req.body.address_line_3,
		zip: req.body.zip,
		status: req.body.status,
		country_id: req.body.country_id,
    },{ 
        where: { Userid: req.params.id } 
    }).then(result => {
        res.status(200).json(result);
    });
});

/* Delete records..  */
router.delete('/:id', function(req, res){
    models.User.destroy({ 
        where: { Userid: req.params.id } 
    }).then(result => {
        res.status(200).json(result);
    });
});

module.exports = router;