import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RegiRoute } from 'src/app/registration/registration.route';
import { RegistrationComponent } from 'src/app/registration/registration.component';
import { RegistrationService } from '../shared/services/registration.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    RegiRoute
  ],
  declarations: [
    RegistrationComponent
  ],
  providers: [RegistrationService],
  exports: []
})

export class RegistrationModule { }
