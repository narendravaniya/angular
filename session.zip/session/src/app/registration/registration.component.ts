import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { RegistrationModel } from 'src/app/shared/models/registration.model';
import { RegistrationService } from 'src/app/shared/services/registration.service';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  regi = new RegistrationModel();
  listdata: any;
  countrydata: any;
  userdata: any;
  title: string;
  ids: number;
  constructor(private http: Http,private regiservice:RegistrationService) { }

  ngOnInit() {
   //this.regi.gender = 1;
   this.getCoutries();
   this.getAlluserdata();
   this.title = 'Add';
  }
  /* Add  */
  addDatafrm() {
    
    if(this.ids){
      this.regiservice.updatefrmData(this.regi,this.ids).subscribe(data => {
      
      });
    } else{
      this.regiservice.postfrmData(this.regi).subscribe(data => {
      
      });
    }
    
  }
 /* Start Get Info  */
 getCoutries() {
  this.regiservice.getcountriesData().subscribe(data => {
    this.countrydata = data.data;
  });
}
/* End Get Info  */

getAlluserdata() {
  this.regiservice.getuserData().subscribe(data => {
    this.userdata = data.data;
  });
}

editdata(id){
  this.ids = id;
  this.title = 'Update';
  this.regiservice.geteditData(id).subscribe(data => {
    this.regi = data.data;
  });
}
  
}
