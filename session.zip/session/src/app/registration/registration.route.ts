import { ModuleWithProviders } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { RegistrationComponent } from "./registration.component";



const routes: Routes = [
  {
    path: 'registration',
    component: RegistrationComponent
  }
];

export const RegiRoute: ModuleWithProviders = RouterModule.forRoot(routes);