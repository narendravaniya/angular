export class RegistrationModel
{
    id:Number;
    firstname:any;
    lastname:any;
    email:any;
    phone:number;
    //gender:any;
    gender:boolean;
    country_id:any='';
   // password:any;
    //cpassword:any;
    
}