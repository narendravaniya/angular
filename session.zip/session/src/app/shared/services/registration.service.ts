import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {  
  url = environment.baseUrl;
  constructor(private http: Http) { }
  /* get method */

  postfrmData(frmdata) {
    
    return this.http.post(this.url + "/users/" + "add",frmdata)
    
      .map(response => response.json())
      
  }

  getcountriesData(){
    return this.http.get(this.url + "/countries/" + "getcountrieslist")
    
      .map(response => response.json())

  }

  getuserData(){
    return this.http.get(this.url + "/users/" + "getuserlist")
    
      .map(response => response.json())

  }

  geteditData(id){
    return this.http.get(this.url + "/users/" + id)
    
      .map(response => response.json())

  }

  updatefrmData(upadtefrmdata,id) {
    
    return this.http.put(this.url + "/users/" + id,upadtefrmdata)
    
      .map(response => response.json())
      
  }
 
}
