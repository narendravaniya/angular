// Import Related Module 
var express = require('express');
var mysql = require('mysql');
var bodyParser = require('body-parser');

var app = express();

// Configure Setting with module
app.set('port',3000);
// app.use(express.static(__dirname + '/app'));
app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true })); // for parsing       application/x-www-form-urlencoded

app.use(function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With, content-type, x-access-token, x-origin, Authorization');
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Expose-Headers', 'totalRecords');
    next();
}); 

// Mysql Database Connection 
var con = mysql.createConnection({
	host: "localhost",
	user: "root",
	password: "",
	database : "demo"
});


/*   ADD registration data     */

//addregistration API Called Post API
app.post('/RegiCreate',function(req,res){
	var obj = req.body;
	
	if(Object.keys(obj).length > 0){
		var fullname = obj.fullname;
		var email = obj.email;
		var cell_phone = obj.cell_phone;
		var gender = obj.gender;
		var password = obj.password;
		var state_id = obj.state_id;
		var sqlQuery = "INSERT INTO `registration` (`fullname`, `email`, `cell_phone`, `gender`, `password`,`state_id`) VALUES ('"+ fullname +"', '"+ email +"', '" + cell_phone + "','"+gender +"', '"+password +"','"+state_id +"')";
				con.query(sqlQuery,function(err,result){
					if(err){
						console.log("err",err);
						var error = {
							data : err,
							status : 404,
							message : "mysql database getting error"
						}
						res.json({"data" : error});
					}else{
						if(result.affectedRows > 0 ){
							res.json({"data" : result, message: "Success", status : 200});	
						}else{
							res.json({"data" : result, message : "Data not Inserted.", status : 404});
						}
					}
				})
	}else{
		var error = {
			data : null,
			status : 404,
			message : "Error. Payload Getting Blank."
		}
		res.json({"data" : error});
	}
	
});







//Adim Access All Call Details
app.get('/getStateDetail',function(req,res){
	var sqlQuery = "SELECT * from state ORDER BY ID DESC";
	con.query(sqlQuery,function(err,result){
		console.log(result);
		if(err){
			var error = {
				data : err,
				status : 404,
				message : "mysql database getting error"
			}
			res.json({"data" : error});
		}else{
			res.json({"data" : result, message: "Success", status : 200});	
		}
	});
});




//Adim Access All Call Details
app.get('/getAlllist',function(req,res){
	var sqlQuery = "SELECT regi.id,regi.fullname,regi.email,regi.cell_phone,regi.gender,regi.password,regi.state_id,st.state_name from registration as regi LEFT JOIN state as st ON regi.state_id = st.id";
	con.query(sqlQuery,function(err,result){
		console.log(result);
		if(err){
			var error = {
				data : err,
				status : 404,
				message : "mysql database getting error"
			}
			res.json({"data" : error});
		}else{
			res.json({"data" : result, message: "Success", status : 200});	
		}
	});
});

// Create Server Listen
app.listen(app.get('port'),function(){

	console.log("Express Server Listen in port :", app.get('port'));
})