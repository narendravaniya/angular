/*
module.exports = function(sequelize, Sequelize) {
    var BookSchema = sequelize.define('Book', {
        title: Sequelize.STRING,
        author: Sequelize.STRING,
        category: Sequelize.STRING
    },{
        timestamps: false
    });
    return BookSchema;
}
*/

  module.exports = function (sequelize, DataTypes) {
        var Company = sequelize.define('Company', {
            companyid: {
                type: DataTypes.INTEGER,
                autoIncrement: true,
                primaryKey: true
            },
            name: {
                type: DataTypes.STRING(50),
                unique:
                    {
                        name: "unique_name",
                        args: true
                    },
                allowNull: false
            },
            address_line_1: {
                type: DataTypes.STRING(255),
                allowNull: true
            },
            address_line_2: {
                type: DataTypes.STRING(255),
                allowNull: true
            },
            address_line_3: {
                type: DataTypes.STRING(255),
                allowNull: true
            },
            zip: {
                type: DataTypes.STRING(10),
                allowNull: true
            },
            status: {
                type: DataTypes.BOOLEAN,
                allowNull: false,
                defaultValue: true
            },
        },
            {
                underscored: true,
                timestamps: true,
                paranoid: false, /* soft delete true or hard delete false */
                freezeTableName: true,
                tableName: 'ap_company',
                indexes: [
                    {
                        fields: ['name']
                    },
                ]
            });
            
        Company.associate = function (models) {
            Company.belongsTo(models.Country, {
                as: 'country',
                onDelete: "CASCADE",
                foreignKey: {
                    name: 'country_id',
                    allowNull: true
                }
            });
            
           
          
          
        };

        return Company;
    }