var express = require('express');
var models = require('../models');
var router = express.Router();

/* Get all records..  */
router.get('/getlist', function(req, res){
options ={
include: [{
    model: models.Country,
	as:'country'
	//,
    //where: {id: 2}
   }]
}
      
    console.log('getting all books');
    models.Company.findAll(options).then(books => {
        res.json(books);
    });
});

/* Get one record */
router.get('/:id', function(req, res){

    console.log('getting one book');
    models.Company.findById(req.params.id).then(book => {
        console.log(book);
        res.json(book);
    });
	
    /* another ways to do it 
    models.Company.findById({ where: {companyid: req.params.id} }).success(book => {
        console.log(book);
        res.json(book);
    }).error(err => {
        res.send('error has occured');
    });
 */   
});

/* Insert records..  */
router.post('/add', function(req, res){
    models.Company.create({ 
        name: req.body.name,
        address_line_1: req.body.address_line_1, 
        address_line_2: req.body.address_line_2,
        address_line_3: req.body.address_line_3,
		zip: req.body.zip,
		status: req.body.status,
		country_id: req.body.country_id,
    }).then(book => {
        console.log(book.get({
          plain: true
        }));
        res.send(book);
    });
});

/* Update records..  */
router.put('/:id', function(req, res){
    models.Company.update({
        name: req.body.name,
        address_line_1: req.body.address_line_1, 
        address_line_2: req.body.address_line_2,
        address_line_3: req.body.address_line_3,
		zip: req.body.zip,
		status: req.body.status,
		country_id: req.body.country_id,
    },{ 
        where: { companyid: req.params.id } 
    }).then(result => {
        res.status(200).json(result);
    });
});

/* Delete records..  */
router.delete('/:id', function(req, res){
    models.Company.destroy({ 
        where: { companyid: req.params.id } 
    }).then(result => {
        res.status(200).json(result);
    });
});

module.exports = router;