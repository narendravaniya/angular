import { NgModule } from '@angular/core'
import { RouterModule, Routes } from '@angular/router'

import { SelectivePreloadingStrategy } from './selective-preloading-strategy'
import { PageNotFoundComponent } from './page-not-found.component'
import { TripDetailComponent, TripAddComponent,TripListComponent ,DashboardComponent, DeviceAddComponent, DeviceListComponent, LoginComponent,  ProfileComponent, ResetpasswordComponent, UserAddComponent, UserListComponent, SettingsComponent, AdminDashboardComponent, } from './components/index'
import { AuthService } from './services/index'


const appRoutes: Routes = [
	{
		path: 'login',
		component: LoginComponent
	}, {
		path: '',
		component: DashboardComponent,
		canActivate: [AuthService]
	},{
		path: 'truck/add',
		component: DeviceAddComponent,
		canActivate: [AuthService]
	}, {
		path: 'truck',
		component: DeviceListComponent,
		canActivate: [AuthService]
	}, {
		path: 'truck/:deviceGuid',
		component: DeviceAddComponent,
		canActivate: [AuthService]
	}, {
		path: 'driver/add',
		component: UserAddComponent,
		canActivate: [AuthService]
	}, {
		path: 'driver/:userGuid',
		component: UserAddComponent,
		canActivate: [AuthService]
	}, {
		path: 'driver',
		component: UserListComponent,
		canActivate: [AuthService]
	}, {
		path: 'trips',
		component: TripListComponent,
		canActivate: [AuthService]
	},  {
		path: 'trip/add',
		component: TripAddComponent,
		canActivate: [AuthService]
	}, {
		path: 'trip/:tripGuid',
		component: TripAddComponent,
		canActivate: [AuthService]
	},{
		path: 'trip-detail/:tripGuid',
		component: TripDetailComponent,
		canActivate: [AuthService]
	},{
		path: 'profile',
		component: ProfileComponent,
		canActivate: [AuthService]
	}
	,{
		path: '**',
		component: PageNotFoundComponent
	}
];

@NgModule({
	imports: [
		RouterModule.forRoot(
			appRoutes, {
				preloadingStrategy: SelectivePreloadingStrategy
			}
		)
	],
	exports: [
		RouterModule
	],
	providers: [
		SelectivePreloadingStrategy
	]
})

export class AppRoutingModule { }