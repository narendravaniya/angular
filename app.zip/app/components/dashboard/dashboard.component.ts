import * as moment from 'moment-timezone'
import { Component, OnInit, ViewChild } from '@angular/core'
import { NgxSpinnerService } from 'ngx-spinner'
import { DashboardService, ConfigService } from 'app/services'
import { AgmMap } from '@agm/core'
import { StompRService } from '@stomp/ng2-stompjs'
import { Message } from '@stomp/stompjs'
import { Subscription } from 'rxjs'
import { Observable } from 'rxjs/Observable'

@Component({
	selector: 'app-dashboard',
	templateUrl: './dashboard.component.html',
	styleUrls: ['./dashboard.component.css'],
	providers: [StompRService]
})

export class DashboardComponent implements OnInit {
	@ViewChild(AgmMap, { static: false }) public agmMap: AgmMap;
	isAdmin = true;
	statisticsList: any = [];
	notificationList: any = [];
	truckUsage: any = [];
	fleetActivity = { 'Trucks': '0', 'LightTruck': '0', 'CargoVans': '0', 'Trailers': '0' };
	gMapLat = 35.5525839;
	gMapLng = -103.1652215;
	zoom = 5;
	truckActivity = [];
	truckGraphList = [];
	mapStyle = [
		{
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#f5f5f5"
				}
			]
		},
		{
			"elementType": "labels.icon",
			"stylers": [
				{
					"visibility": "off"
				}
			]
		},
		{
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#616161"
				}
			]
		},
		{
			"elementType": "labels.text.stroke",
			"stylers": [
				{
					"color": "#f5f5f5"
				}
			]
		},
		{
			"featureType": "administrative.land_parcel",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#bdbdbd"
				}
			]
		},
		{
			"featureType": "poi",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#eeeeee"
				}
			]
		},
		{
			"featureType": "poi",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#757575"
				}
			]
		},
		{
			"featureType": "poi.park",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#e5e5e5"
				}
			]
		},
		{
			"featureType": "poi.park",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#9e9e9e"
				}
			]
		},
		{
			"featureType": "road",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#ffffff"
				}
			]
		},
		{
			"featureType": "road.arterial",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#757575"
				}
			]
		},
		{
			"featureType": "road.highway",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#dadada"
				}
			]
		},
		{
			"featureType": "road.highway",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#616161"
				}
			]
		},
		{
			"featureType": "road.local",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#9e9e9e"
				}
			]
		},
		{
			"featureType": "transit.line",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#e5e5e5"
				}
			]
		},
		{
			"featureType": "transit.station",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#eeeeee"
				}
			]
		},
		{
			"featureType": "water",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#c9c9c9"
				}
			]
		},
		{
			"featureType": "water",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#9e9e9e"
				}
			]
		}
	]

	lineChart = {
		chartType: 'ColumnChart',
		dataTable: [
			['Date', 'Active', 'Idle', 'Under Maintenance']
		],
		options: {
			'title': 'FLEETS',
			legend: { position: 'bottom', alignment: 'start' },
			height: '400',
			series: [{ color: '#05b76b', visibleInLegend: true }, { color: '#e8db36', visibleInLegend: true }, { color: '#ff5e6d', visibleInLegend: true }]
		},
	};

	truckLookup = [];
	selectedTruck = '';
	sensorDetails = {
	}
	stompConfiguration = {
		url: '',
		headers: {
			login: '',
			passcode: '',
			host: ''
		},
		heartbeat_in: 0,
		heartbeat_out: 2000,
		reconnect_delay: 5000,
		debug: true
	}
	subscription: Subscription;
	isConnected = false;
	messages: Observable<Message>;
	subscribed;
	cpId = '';

	constructor(
		private spinner: NgxSpinnerService,
		private dashboardService: DashboardService,
		private stompService: StompRService,
		public configService:ConfigService
	) { }

	ngOnInit() {
		this.getDashboardStatistics();
		this.getNotificationList();
		this.getTruckUsage();
		this.getTruckActivity();
		this.getTruckGraph();
		if (!this.isAdmin) {
			this.getTruckLookup();
		}
	}

	getTruckLookup() {
		this.spinner.show();
		this.dashboardService.getTruckLookup().subscribe(response => {
			this.spinner.hide();
			this.truckLookup = response['data'];
			this.selectedTruck = this.truckLookup[0];
			this.getSensors();
			this.getStompConfig();
		});
	}

	startSimulator() {
		this.spinner.show();
		this.dashboardService.startSimulator(this.selectedTruck['uniqueId']).subscribe(response => {
			if (response['status'] === 200) {
				this.spinner.hide();
			}
		});
	}

	getSensors() {
		let data = {
			"device_id": this.selectedTruck['guid']
		}
		this.dashboardService.getSensors(data).subscribe(response => {
			if (response['status'] === 200) {
				response['data'].forEach(element => {
					this.sensorDetails[element['attributeName']] = element['attributeValue'];
				});
				this.spinner.hide();
			} else {
				this.spinner.hide();
			}
		});
	}

	getDashboardStatistics() {
		this.spinner.show();
		this.dashboardService.getDashboardStatistics().subscribe(response => {
			this.spinner.hide();
			this.statisticsList = response;
		});
	}

	getNotificationList() {
		this.spinner.show();
		this.dashboardService.getNotificationList().subscribe(response => {
			this.spinner.hide();
			this.notificationList = response['rows'];
		});
	}

	getTruckUsage() {
		this.spinner.show();
		this.dashboardService.getTruckUsage().subscribe(response => {
			this.spinner.hide();
			this.truckUsage = response['data'];
			let totalTripCount = response['count'];
			if (this.truckUsage) {
				this.truckUsage.forEach(element => {
					if (element.type === 4) {
						this.fleetActivity['Trailers'] = Math.round((element.count * 100) / totalTripCount) + '%';
					} else if (element.type === 3) {
						this.fleetActivity['CargoVans'] = Math.round((element.count * 100) / totalTripCount) + '%';
					} else if (element.type === 2) {
						this.fleetActivity['LightTruck'] = Math.round((element.count * 100) / totalTripCount) + '%';
					} else if (element.type === 1) {
						this.fleetActivity['Trucks'] = Math.round((element.count * 100) / totalTripCount) + '%';
					}
				});
			}

		});
	}

	getTruckActivity() {
		this.spinner.show();
		this.dashboardService.getTruckActivity().subscribe(response => {
			this.spinner.hide();
			this.truckActivity = response['data'];
		});
	}

	zoomChanged(event) {
		this.agmMap.triggerResize(true);
	}

	getTruckGraph() {
		this.spinner.show();
		this.dashboardService.getTruckGraph().subscribe(response => {
			this.spinner.hide();
			this.truckGraphList = response['data'];
			this.truckGraphList.unshift(['Date', 'Active', 'Idle', 'Under Maintenance']);
			this.lineChart.dataTable = this.truckGraphList;
			this.lineChart = {
				chartType: 'ColumnChart',
				dataTable: this.truckGraphList,
				options: {
					'title': 'FLEETS',
					legend: { position: 'bottom', alignment: 'start' },
					height: '400',
					series: [{ color: '#05b76b', visibleInLegend: true }, { color: '#e8db36', visibleInLegend: true }, { color: '#ff5e6d', visibleInLegend: true }]
				},
			};
		});
	}

	getStompConfig() {
		this.dashboardService.getStompCon().subscribe(response => {
			this.stompConfiguration.url = response['data']['data']['url'];
			this.stompConfiguration.headers.login = response['data']['data']['user'];
			this.stompConfiguration.headers.passcode = response['data']['data']['password'];
			this.stompConfiguration.headers.host = response['data']['data']['vhost'];
			this.cpId = response['data']['data']['cpId'];
			this.initStomp();
		});
	}

	initStomp() {
		let config = this.stompConfiguration;
		this.stompService.config = config;
		this.stompService.initAndConnect();
		this.stompSubscribe();
	}

	public stompSubscribe() {
		if (this.subscribed) {
			return;
		}
		this.messages = this.stompService.subscribe('/topic/' + this.cpId + '-' + this.selectedTruck['uniqueId']);
		this.subscription = this.messages.subscribe(this.on_next);
		this.subscribed = true;
	}

	public on_next = (message: Message) => {
		let obj: any = JSON.parse(message.body);
		let now = moment().format("MM-DD-YYYY h:mm:ss A");
		obj.data.data.time = now;
		if (obj.data.data && obj.data.data.status && (obj.data.data.status === "on" || obj.data.data.status === "off")) { } else {
			this.sensorDetails = obj.data.data.reporting;
		}
	}

	public stompUnsubscribe() {
		this.stompService.disconnect();
	}
}