import { Component, OnInit } from '@angular/core'
import { Router } from '@angular/router'

import { UserService } from './../../services/index'

@Component({
	selector: 'app-left-menu',
	templateUrl: './left-menu.component.html',
	styleUrls: ['./left-menu.component.css']
})

export class LeftMenuComponent implements OnInit {
	menuList: any = [];
	user_type: any;
	selectedMenu: any;
	currentUrl: any;

	constructor(private userService: UserService, private router: Router) { }

	ngOnInit() {
		let tempUrl = (this.router.url).split('/');
		this.currentUrl = "/" + tempUrl[1];
		this.menuList = [
			{
				name: 'Dashboard',
				link: '/',
				li_color: 'purple',
				icon: 'icon1',
				applylink: true
			}, {
				name: "Fleets",
				link: "/truck",
				li_color: 'gold',
				icon: 'icon4',
				applylink: true
			}, {
				name: 'Drivers',
				link: '/driver',
				li_color: 'blue',
				icon: 'icon7',
				applylink: true
			}, {
				name: 'Trips',
				link: '/trips',
				li_color: 'red',
				icon: 'icon8',
				applylink: true
			}
		];
	}

	manageNavigateUrl(url) {
		this.router.navigate([url]);
	}

	showSubMenu(menu) {
		menu.showSunMenu = !menu.showSunMenu;
	}

	onClickMenu(i) {
		this.currentUrl = false;
		this.selectedMenu = i;
	}
}