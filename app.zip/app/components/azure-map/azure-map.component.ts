import * as atlas from 'azure-maps-control'
import { Component, Input, OnInit } from '@angular/core'
import { NgxSpinnerService } from 'ngx-spinner'

@Component({
	selector: 'app-azure-map',
	templateUrl: './azure-map.component.html',
	styleUrls: ['./azure-map.component.css']
})

export class AzureMapComponent implements OnInit {
	key: string = '88TxXyOQlnLoGdjYfXK1ID2tKEo-2RHfSqwvp9DPjFg';
	map: any;
	@Input() currentLat: any;
	@Input() currentLng: any;
	pin: any;
	center;
	dataSource = new atlas.source.DataSource();

	constructor(private spinner: NgxSpinnerService) { }

	ngOnInit() {
		var refThis = this;
		refThis.spinner.show();
		if (!this.currentLng) {
			this.currentLng = -97.630702;
		}
		if (!this.currentLat) {
			this.currentLat = 33.143175;
		}
		refThis.GetMap();
	}

	ngOnChanges() {
		var refThis = this;
		if (refThis.map) {
			refThis.dataSource.clear();
			let pin = new atlas.Shape(new atlas.data.Feature(new atlas.data.Point([refThis.currentLng, refThis.currentLat]), {
				rotation: 360
			}));
			pin.setCoordinates([refThis.currentLng, refThis.currentLat]);
			refThis.dataSource.add(pin);
			refThis.map.setCamera({
				center: [parseFloat(refThis.currentLng), parseFloat(refThis.currentLat)],
				zoom: 8,
				pitch: 50
			});
		}
	}

	GetMap() {
		var self = this;
		//Initialize a map instance.
		self.map = new atlas.Map('mapContainer', {
			center: [self.currentLng, self.currentLat],
			zoom: 8,
			view: 'Auto',
			authOptions: {
			//	authType: 'subscriptionKey',
				subscriptionKey: self.key,
			}
		});

		self.map.events.add('ready', function () {
			//Load a custom image icon into the map resources.
			self.map.imageSprite.add('arrow-icon', '../../assets/images/truck-img.png').then(res => {
				//Create a data source and add it to the map.
				self.map.sources.add(self.dataSource);

				//Create a layer to render a symbol which we will animate.
				self.map.layers.add(new atlas.layer.SymbolLayer(self.dataSource, null, {
					iconOptions: {
						//Pass in the id of the custom icon that was loaded into the map resources.
						image: 'arrow-icon',
						//Anchor the icon to the center of the image.
						anchor: 'center',
						//Rotate the icon based on the rotation property on the point data.
						rotation: ['get', 'rotation'],
						//Have the rotation align with the map.
						rotationAlignment: 'map',
						//For smoother animation, ignore the placement of the icon. This skips the label collision calculations and allows the icon to overlap map labels. 
						ignorePlacement: true,
						//For smoother animation, allow symbol to overlap all other symbols on the map.
						allowOverlap: true
					},
					textOptions: {
						//For smoother animation, ignore the placement of the text. This skips the label collision calculations and allows the text to overlap map labels.
						ignorePlacement: true,
						//For smoother animation, allow text to overlap all other symbols on the map.
						allowOverlap: true
					},
					//Only render Point or MultiPoints in this layer.    
					filter: ['any', ['==', ['geometry-type'], 'Point'], ['==', ['geometry-type'], 'MultiPoint']]
				}));

				//Create a pin and wrap with the shape class and add to data source.
				let pin = new atlas.Shape(new atlas.data.Feature(new atlas.data.Point([self.currentLng, self.currentLat]), {
					rotation: 360
				}));
				pin.setCoordinates([self.currentLng, self.currentLat]);
				self.dataSource.add(pin);
				self.map.setCamera({
					center: [parseFloat(self.currentLng), parseFloat(self.currentLat)],
					zoom: 8,
					pitch: 50
				});
				self.spinner.hide();
			});
		});
	}
}