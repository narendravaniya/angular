import { Component, ElementRef, OnInit, ViewChild } from '@angular/core'
import { Router } from '@angular/router'
import { FormControl, FormGroup, Validators } from '@angular/forms'
import { NgxSpinnerService } from 'ngx-spinner'

import {  Notification, NotificationService, UserService } from './../../services/index'

@Component({
	selector: 'app-profile',
	templateUrl: './profile.component.html',
	styleUrls: ['./profile.component.css']
})

export class ProfileComponent implements OnInit {
	@ViewChild('profile_picture_Ref', { static: false }) profile_picture_Ref: ElementRef;
	fileUrl: any;
	fileName = '';
	fileToUpload: any = null;
	userObject = {};
	userForm: FormGroup;
	checkSubmitStatus = false;
	buildingList = [];
	selectedBuilding = '';
	floorList = [];
	timezoneList = [];
	userGuid = '';

	constructor(
		private spinner: NgxSpinnerService,
		private userService: UserService,
		private router: Router,
		private _notificationService: NotificationService,
	) {
		this.createFormGroup();
	}

	ngOnInit() {
		this.getTimezone();
		
		this.getUserDetails();
	}

	getUserDetails() {
		this.userService.getUserInfo().subscribe(response => {
			this.userGuid = response['data']['user_id'];
			this.userService.getUserDetails(this.userGuid).subscribe(response => {
				this.userObject = response['data'];
				this.fileUrl = this.userObject['profile_picture'];
				this.userForm.patchValue({
					first_name: this.userObject['first_name'],
					last_name: this.userObject['last_name'],
					email: this.userObject['email'],
					phone_code: this.userObject['phone_number'].split('-')[0],
					phone_number: this.userObject['phone_number'].split('-')[1],
					timezone: this.userObject['timezone'],
					user_type: this.userObject['CompanyUser']['Role']['role_id'],
					building_id: (this.userObject['CompanyUser']['Building'] && this.userObject['CompanyUser']['Building']['building_id']) ? this.userObject['CompanyUser']['Building']['building_id'] : '',
					floor_id: (this.userObject['CompanyUser']['Floor'] && this.userObject['CompanyUser']['Floor']['floor_id']) ? this.userObject['CompanyUser']['Floor']['floor_id'] : '',
				});
				
			});
		});
	}

	



	getTimezone() {
		this.userService.getTimezone().subscribe(response => {
			this.timezoneList = response['data'];
		});
	}

	createFormGroup() {
		this.userForm = new FormGroup({
			first_name: new FormControl('', [Validators.required]),
			last_name: new FormControl('', [Validators.required]),
			email: new FormControl('', [Validators.required]),
			phone_code: new FormControl('', [Validators.required]),
			phone_number: new FormControl('', [Validators.required]),
			building_id: new FormControl('', [Validators.required]),
			floor_id: new FormControl('', [Validators.required]),
			user_type: new FormControl('', [Validators.required]),
			timezone: new FormControl('', [Validators.required]),
			profile_picture: new FormControl(''),
		});
	}

	updateProfile() {
		this.checkSubmitStatus = true;
		if (this.userForm.status === "VALID") {
			this.spinner.show();
			this.userService.updateUser(this.userGuid, this.userForm.value).subscribe(response => {
				if (response.status === 200) {
					if (this.fileName.length > 0) {
						this.userService.uploadPicture(this.userGuid, this.fileToUpload).subscribe(response => {
							this.spinner.hide();
							this.router.navigate(['/profile']);
							this._notificationService.add(new Notification('success', "Profile has been added successfully."));
						});
					} else {
						this.spinner.hide();
						this.router.navigate(['/profile']);
						this._notificationService.add(new Notification('success', "Profile has been added successfully."));
					}
				} else {
					this.spinner.hide();
					this._notificationService.add(new Notification('error', response.message));
				}
			});
		}
	}

	removeFile(type) {
		if (type === 'image') {
			this.fileUrl = '';
			this.profile_picture_Ref.nativeElement.value = '';
		}
	}

	handleImageInput(event) {
		let files = event.target.files;
		if (files.length) {
			let fileType = files.item(0).name.split('.');
			let imagesTypes = ['jpeg', 'JPEG', 'jpg', 'JPG', 'png', 'PNG'];
			if (imagesTypes.indexOf(fileType[fileType.length - 1]) !== -1) {
				this.fileName = files.item(0).name;
				this.fileToUpload = files.item(0);
			} else {
				this.fileToUpload = null;
				this.fileName = '';
			}
		}

		if (event.target.files && event.target.files[0]) {
			var reader = new FileReader();
			reader.readAsDataURL(event.target.files[0]);
			reader.onload = (innerEvent: any) => {
				this.fileUrl = innerEvent.target.result;
			}
		}
	}
}