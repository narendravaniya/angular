import { Component, ElementRef, OnInit, ViewChild } from '@angular/core'
import { ActivatedRoute, Router } from '@angular/router'
import { FormControl, FormGroup, Validators } from '@angular/forms'
import { NgxSpinnerService } from 'ngx-spinner'

import { Notification, NotificationService, UserService } from './../../../services/index'

@Component({
	selector: 'app-user-add',
	templateUrl: './user-add.component.html',
	styleUrls: ['./user-add.component.css']
})

export class UserAddComponent implements OnInit {
	@ViewChild('floor_image_Ref', { static: false }) floor_image_Ref: ElementRef;
	fileUrl: any;
	fileName = '';
	fileToUpload: any = null;
	status;
	moduleName = "Add Driver";
	userObject = {};
	userGuid = '';
	isEdit = false;
	userForm: FormGroup;
	checkSubmitStatus = false;
	buildingList = [];
	selectedBuilding = '';
	floorList = [];
	userTypeList = [];
	timezoneList = [];
	countryList = [];
	stateList: any = [];
	deviceList = [];

	constructor(
		private userService: UserService,
		private router: Router,
		private _notificationService: NotificationService,
		private activatedRoute: ActivatedRoute,
		private spinner: NgxSpinnerService
	) {
		this.createFormGroup();
		this.activatedRoute.params.subscribe(params => {
			if (params.userGuid) {
				this.getUserDetails(params.userGuid);
				this.userGuid = params.userGuid;
				this.moduleName = "Edit Driver";
				this.isEdit = true;
			} else {
				this.userObject = { first_name: '', last_name: '', email: '', phone_code: '', phone_number: '', country_guid: '', state_guid: '', city: '', zip_code: '', address: '', device_id: '', truck_type: '' }
			}
		});
	}

	ngOnInit() {
		this.getCountry();
		this.getDevice();
	}

	createFormGroup() {
		this.userForm = new FormGroup({
			first_name: new FormControl('', [Validators.required]),
			last_name: new FormControl('', [Validators.required]),
			email: new FormControl('', [Validators.required]),
			phone_code: new FormControl('', [Validators.required]),
			phone_number: new FormControl('', [Validators.required]),
			device_id: new FormControl('', [Validators.required]),
			country_guid: new FormControl('', [Validators.required]),
			state_guid: new FormControl('', [Validators.required]),
			city: new FormControl('', [Validators.required]),
			zip_code: new FormControl('', [Validators.required]),
			address: new FormControl('', [Validators.required]),
			image: new FormControl('')
		});
	}

	getDevice() {
		this.userService.getDevice().subscribe(response => {
			this.deviceList = response['data'];
			if (this.isEdit) {
				this.userForm.patchValue({ 'device_id': this.userObject['device_id'] })
			}
		});
	}

	getCountry() {
		this.userService.getCountry().subscribe(response => {
			this.countryList = response['data'];
			if (this.isEdit) {
				this.userForm.patchValue({ 'country_guid': this.userObject['country_guid'] })
				this.onChangeCountry();
			}
		});
	}

	onChangeCountry() {
		this.userService.getState(this.userForm.value['country_guid']).subscribe(response => {
			this.stateList = response['data'];
			if (this.isEdit) {
				this.userForm.patchValue({ 'state_guid': this.userObject['state_guid'] })
			}
		});
	}

	addUser() {
		this.checkSubmitStatus = true;
		if (this.userForm.status === "VALID") {
			if (this.isEdit) {
				this.spinner.show();
				this.userForm.value['phone_number'] = this.userForm.value['phone_code'] + "-" + this.userForm.value['phone_number'];
				this.userService.updateDriver(this.userGuid, this.userForm.value).subscribe(response => {
					if (response.status === 200) {
						if (this.fileName.length > 0) {
							this.userService.uploadImage(this.userGuid, this.fileToUpload).subscribe(response => {
								this.spinner.hide();
								this.router.navigate(['/driver']);
								this._notificationService.add(new Notification('success', "Driver has been updated successfully."));
							});
						} else {
							this.spinner.hide();
							this.router.navigate(['/driver']);
							this._notificationService.add(new Notification('success', "Driver has been updated successfully."));
						}
					} else {
						this.spinner.hide();
						this._notificationService.add(new Notification('error', response.message));
					}
				});
			} else {
				this.spinner.show();
				this.userForm.value['phone_number'] = this.userForm.value['phone_code'] + "-" + this.userForm.value['phone_number'];
				this.userService.addDriver(this.userForm.value).subscribe(response => {
					if (response['status'] === 200) {
						if (this.fileName.length > 0) {
							this.userService.uploadImage(response['data']['driver_id'], this.fileToUpload).subscribe(response => {
								this.spinner.hide();
								this.router.navigate(['/driver']);
								this._notificationService.add(new Notification('success', "Driver has been added successfully."));
							});
						} else {
							this.spinner.hide();
							this.router.navigate(['/driver']);
							this._notificationService.add(new Notification('success', "Driver has been added successfully."));
						}
					} else {
						this.spinner.hide();
						this._notificationService.add(new Notification('error', response['message']));
					}
				});
			}
		}
	}

	removeFile(type) {
		if (type === 'image') {
			this.fileUrl = '';
			this.floor_image_Ref.nativeElement.value = '';
		}
	}

	handleImageInput(event) {
		let files = event.target.files;
		if (files.length) {
			let fileType = files.item(0).name.split('.');
			let imagesTypes = ['jpeg', 'JPEG', 'jpg', 'JPG', 'png', 'PNG'];
			if (imagesTypes.indexOf(fileType[fileType.length - 1]) !== -1) {
				this.fileName = files.item(0).name;
				this.fileToUpload = files.item(0);
			} else {
				this.fileToUpload = null;
				this.fileName = '';
			}
		}

		if (event.target.files && event.target.files[0]) {
			var reader = new FileReader();
			reader.readAsDataURL(event.target.files[0]);
			reader.onload = (innerEvent: any) => {
				this.fileUrl = innerEvent.target.result;
			}
		}
	}

	getUserDetails(userGuid) {
		this.spinner.show();
		this.userService.getDriverDetails(userGuid).subscribe(response => {
			this.spinner.hide();
			if (response.status === 200) {
				if (response.data['phone_number']) {
					let contactData = response.data['phone_number'].split("-");
					response.data['code'] = contactData[0];
					response.data['phone_number'] = contactData[1];
				}
				this.userObject = response.data;
				this.fileUrl = this.userObject['image'];
			}
		});
	}
}