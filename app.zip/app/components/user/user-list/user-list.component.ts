import { Component, OnInit } from '@angular/core'
import { Router } from '@angular/router'
import { NgxSpinnerService } from 'ngx-spinner'

import { Notification, NotificationService, UserService } from './../../../services/index'

@Component({
	selector: 'app-user-list',
	templateUrl: './user-list.component.html',
	styleUrls: ['./user-list.component.css']
})

export class UserListComponent implements OnInit {
	changeStatusUserGuid;
	changeStatusUserStatus;
	changeStatusUserName;
	isSearch = false;
	order = true;
	totalUserCount = 0;
	reverse = false;
	orderBy = 'name';
	userSearchParameters = {
		pageNumber: 1,
		pageSize: 10,
		searchText: '',
		sortBy: 'driver_id asc'
	};
	userList = [];

	constructor(
		private spinner: NgxSpinnerService,
		private userService: UserService,
		private router: Router,
		private _notificationService: NotificationService,
	) { }

	ngOnInit() {
		this.getUserList();
	}

	manageAddUser() {
		this.router.navigate(['/driver/add']);
	}

	setOrder(value: string) {
		if (this.orderBy !== value) {
			this.reverse = true;
		}
		this.orderBy = value;
		if (this.reverse === true) {
			this.reverse = !this.reverse;
			this.userSearchParameters.sortBy = value + ' asc';
		} else {
			this.reverse = !this.reverse;
			this.userSearchParameters.sortBy = value + ' desc';
		}
		this.getUserList();
	}

	onPageSizeChangeCallback(pageSize) {
		this.userSearchParameters.pageSize = pageSize;
		this.userSearchParameters.pageNumber = 1;
		this.isSearch = true;
		this.getUserList();
	}

	ChangePaginationAsPageChange(pagechangeresponse) {
		this.userSearchParameters.pageNumber = pagechangeresponse;
		this.isSearch = true;
		this.getUserList();
	}

	searchTextCallback(filterText) {
		this.userSearchParameters.searchText = filterText;
		this.userSearchParameters.pageNumber = 1;
		this.getUserList();
		this.isSearch = true;
	}

	openChangeStatusDialog(guid, name, status) {
		this.changeStatusUserGuid = guid;
		this.changeStatusUserName = name;
		this.changeStatusUserStatus = status;
	}

	openDeleteDialog(guid, name) {
		this.changeStatusUserGuid = guid;
		this.changeStatusUserName = name;
	}

	getUserList() {
		this.spinner.show();
		this.userService.getDrivers(this.userSearchParameters).subscribe(response => {
			this.spinner.hide();
			this.totalUserCount = response.recordsTotal;
			this.userList = response.data;
			this.isSearch = false;
		});
	}

	changeUserStatus() {
		let data;
		if (this.changeStatusUserStatus === 0) {
			data = {
				'status': 1
			}
		} else if (this.changeStatusUserStatus === 1) {
			data = {
				'status': 0
			}
		}

		this.spinner.show();
		this.userService.changeDriverStatus(this.changeStatusUserGuid, data).subscribe(response => {
			this.spinner.hide();
			if (response.status === 200) {
				this._notificationService.add(new Notification('success', response.message));
				this.getUserList();
			} else {
				this.spinner.hide();
				this._notificationService.add(new Notification('error', response.message));
			}
		}, error => {
			this.spinner.hide();
			this._notificationService.add(new Notification('error', error));
		});
	}

	deleteDriver() {
		this.spinner.show();
		this.userService.deleteDriver(this.changeStatusUserGuid).subscribe(response => {
			this.spinner.hide();
			this._notificationService.add(new Notification('success', response.message));
			if (this.userSearchParameters.pageNumber !== 1 && this.userList.length === 1) {
				this.userSearchParameters.pageNumber = this.userSearchParameters.pageNumber - 1;
			}
			this.getUserList();
		}, error => {
			this.spinner.hide();
			this._notificationService.add(new Notification('error', error));
		});
	}
}