import { Component, OnInit } from '@angular/core'
import { FormControl, FormGroup, Validators } from '@angular/forms'
import { ActivatedRoute, Router } from '@angular/router'
import { NgxSpinnerService } from 'ngx-spinner'

import { Notification, NotificationService, UserService } from './../../services/index'

@Component({
	selector: 'app-resetpassword',
	templateUrl: './resetpassword.component.html',
	styleUrls: ['./resetpassword.component.css']
})

export class ResetpasswordComponent implements OnInit {
	resetPasswordForm: FormGroup;
	checkSubmitStatus = false;
	invitationGuid = '';

	constructor(
		private spinner: NgxSpinnerService,
		public router: Router,
		private UserService: UserService,
		private _notificationService: NotificationService,
		private activatedRoute: ActivatedRoute
	) {
		this.activatedRoute.params.subscribe(params => {
			if (params.invitationGuid) {
				this.invitationGuid = params.invitationGuid;
			}
		});
	}

	ngOnInit() {
		this.createFormGroup();
	}

	createFormGroup() {
		this.resetPasswordForm = new FormGroup({
			username: new FormControl('', [Validators.required]),
			password: new FormControl('', [Validators.required]),
			confirm_password: new FormControl('', [Validators.required]),
			invitationGuid: new FormControl('', [Validators.required]),
		});
		this.resetPasswordForm.patchValue({
			"invitationGuid": this.invitationGuid
		})
	}

	resetPassword() {
		this.checkSubmitStatus = true;
		if (this.resetPasswordForm.status === "VALID") {
			this.spinner.show();
			this.UserService.getBasicToken().subscribe(response => {
				this.UserService.resetPassword(this.resetPasswordForm.value, response.data).subscribe(response => {
					this.spinner.hide();
					if (response.status === 200) {
						this._notificationService.add(new Notification('success', 'Logged in successfully'));
						this.router.navigate(['/']);
					}
					else {
						this._notificationService.add(new Notification('error', response.message));
						this.router.navigate(['/login']);
					}
				});
			});
		}
	}
}