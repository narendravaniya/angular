import { Component, OnInit } from '@angular/core'
import { TitleCasePipe } from '@angular/common'
import { Router } from '@angular/router'
import { CookieService } from 'ngx-cookie-service'

import { UserService, ConfigService } from './../../services/index'

@Component({
	selector: 'app-header',
	templateUrl: './header.component.html',
	styleUrls: ['./header.css'],
	providers: [TitleCasePipe]
})

export class HeaderComponent implements OnInit {
	cookieName = 'FM';
	userName;

	constructor(
		private userService: UserService,
		private cookieService: CookieService,
		public router: Router,
		private configService:ConfigService
	) { }

	ngOnInit() {
		this.userService.getUserInfo().subscribe(data => {
			this.userName = data['data']['first_name'] + ' ' + data['data']['last_name'];
		})
	}

	logout() {
		this.cookieService.delete(this.cookieName + 'access_token', '/');
		this.cookieService.delete(this.cookieName + 'refresh_token', '/');
		this.cookieService.delete(this.cookieName + 'basic_token', '/');
		localStorage.clear();
		this.configService.isShowLeftMenu = '';
		this.router.navigate(['/login']);
	}
}