import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core'

@Component({
	selector: 'app-delete-dialog',
	templateUrl: './delete-dialog.component.html',
	styleUrls: ['./delete-dialog.component.scss']
})

export class DeleteDialogComponent implements OnInit {

	@Input() name: any;
	@Input() moduleName: any;
	@Input() dialogId: any;
	@Output() onSave = new EventEmitter<string>();

	constructor() { }

	ngOnInit() { }

	deleteItem() {
		this.onSave.emit();
	}
}
