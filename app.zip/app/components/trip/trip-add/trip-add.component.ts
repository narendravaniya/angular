import * as moment from 'moment-timezone'
import { Component, OnInit } from '@angular/core'
import { ActivatedRoute, Router } from '@angular/router'
import { FormControl, FormGroup, Validators } from '@angular/forms'
import { NgxSpinnerService } from 'ngx-spinner'

import { Notification, NotificationService, TripService, UserService } from './../../../services/index'

@Component({
	selector: 'app-trip-add',
	templateUrl: './trip-add.component.html',
	styleUrls: ['./trip-add.component.css']
})

export class TripAddComponent implements OnInit {
	status;
	moduleName = "Add Trip";
	tripGuid = '';
	isEdit = false;
	tripForm: FormGroup;
	checkSubmitStatus = false;
	truckList = [];
	tripDetail = {};
	toLat = '';
	toLng = '';
	fromLat = '';
	fromLng = '';
	endErrorStatus = false;
	endErrorMessage = '';
	endDateErrorMessage = '';
	constructor(
		private userService: UserService,
		private tripService: TripService,
		private router: Router,
		private _notificationService: NotificationService,
		private activatedRoute: ActivatedRoute,
		private spinner: NgxSpinnerService
	) {
		this.createFormGroup();
		this.activatedRoute.params.subscribe(params => {
			if (params.tripGuid) {
				this.getTripDetails(params.tripGuid);
				this.tripGuid = params.tripGuid;
				this.moduleName = "Edit Trip";
				this.isEdit = true;
			}
		});
	}

	ngOnInit() {
		if (!this.isEdit) {
			this.getTrucks();
			this.setTimePickerDeafult();
		}
	}

	createFormGroup() {
		this.tripForm = new FormGroup({
			from: new FormControl('', [Validators.required]),
			to: new FormControl('', [Validators.required]),
			device_id: new FormControl('', [Validators.required]),
			start_date: new FormControl('', [Validators.required]),
			start_time: new FormControl('', [Validators.required]),
			end_date: new FormControl('', [Validators.required]),
			end_time: new FormControl('', [Validators.required]),
			//total_miles: new FormControl('', [Validators.required]),
		});
		if (!this.isEdit) {
			this.tripForm.patchValue({
				start_date: this.convertTimeToDate(moment(moment().tz('UTC').format()).format("X")),
				end_date: this.convertTimeToDate(moment(moment().tz('UTC').format()).format("X")),
			})
		}
	}

	getTripDetails(tripGuid) {
		this.spinner.show();
		this.tripService.getDetails(tripGuid).subscribe(response => {
			if (response.status === 200) {
				this.tripDetail = response.data;
				this.tripForm.patchValue({
					from: response.data.from,
					to: response.data.to,
					start_date: this.convertTimeToDate(response.data.start_time),
					start_time: this.convertTimeToDate(response.data.start_time),
					end_date: this.convertTimeToDate(response.data.end_time),
					end_time: this.convertTimeToDate(response.data.end_time),

					total_miles: response.data.total_miles,
				});
				this.getTrucks();
				this.spinner.hide();
				this.toLat = this.tripDetail['toLat'];
				this.toLng = this.tripDetail['toLng'];
				this.fromLat = this.tripDetail['fromLat'];
				this.fromLng = this.tripDetail['fromLng'];
			}
		});
	}

	convertTimeToDate(startTimestamp) {
		return moment.unix(startTimestamp).tz(moment.tz.guess());
	}

	getTrucks() {
		this.userService.getDevice(true).subscribe(response => {
			this.truckList = response['data'];
			if (this.isEdit) {
				this.tripForm.patchValue({ 'device_id': this.tripDetail['device_id'] })
			}
		});
	}

	showLocationOnMap(place) {
		var refThis = this;
		let location = '';
		if (place === 'from') {
			location = refThis.tripForm.controls['from'].value;
		}
		else {
			location = refThis.tripForm.controls['to'].value;
		}
		if (location !== '') {
			//refThis.spinner.show();
			refThis.tripService.getLocation(location).subscribe(response => {
				if (response.length === 0) {
					if (place !== 'from') {
						refThis.tripForm.patchValue({ 'to': '' });
						refThis.toLat = '';
						refThis.toLng = '';
						this._notificationService.add(new Notification('error', "Please add proper location"));
					}
					else {
						refThis.tripForm.patchValue({ 'from': '' });
						refThis.fromLat = '';
						refThis.fromLng = '';
						this._notificationService.add(new Notification('error', "Please add proper location"))

					}
				}
				else {
					if (place !== 'from') {
						refThis.toLat = response[0].geometry.location.lat;
						refThis.toLng = response[0].geometry.location.lng;
					}
					else {
						refThis.fromLat = response[0].geometry.location.lat;
						refThis.fromLng = response[0].geometry.location.lng;

					}
				}
				refThis.spinner.hide();
			});
		}
		else {
			if (place !== 'from') {
				refThis.tripForm.patchValue({ 'to': '' });
				refThis.toLat = '';
				refThis.toLng = '';
			}
			else {
				refThis.tripForm.patchValue({ 'from': '' });
				refThis.fromLat = '';
				refThis.fromLng = '';
			}
		}
	}

	add() {
		this.checkSubmitStatus = true;
		var data = this.tripForm.value;
		var start_date = moment(data.start_date.toString()).format('YYYY-MM-DD');
		var end_date = moment(data.end_date.toString()).format('YYYY-MM-DD');

		var start_time = moment(data.start_time.toString()).format('HH:mm');
		var end_time = moment(data.end_time.toString()).format('HH:mm');

		data.start_time = moment(start_date + ' ' + start_time).tz('UTC').format();
		data.start_time = moment(data.start_time).format("X");
		data.end_time = moment(end_date + ' ' + end_time).tz('UTC').format();
		data.end_time = moment(data.end_time).format("X");

		data.toLat = this.toLat;
		data.toLng = this.toLng;
		data.fromLat = this.fromLat;
		data.fromLng = this.fromLng;
		data.currentLat = this.fromLat;
		data.currentLng = this.fromLng;

		var currentTimeInTimestamp = moment(moment().tz('UTC').format()).format("X");

		if (parseInt(currentTimeInTimestamp) >= parseInt(data.start_time)) {
			this.endErrorStatus = true;
			this.endErrorMessage = 'Please select start time greater than current time';
			this.endDateErrorMessage = 'Please select start date greater than current date';

		} else if (parseInt(data.end_time) <= parseInt(data.start_time)) {
			this.endErrorStatus = true;
			this.endErrorMessage = 'Please select start time less than end time';
			this.endDateErrorMessage = 'Please select start date less than end date';
		}
		else {
			this.endErrorStatus = false;
			this.endDateErrorMessage = '';
			this.endErrorMessage = '';
		}
		
		if (this.tripForm.status === "VALID" && !this.endErrorStatus) {
			this.spinner.show();
			this.tripService.getDuration(data.from, data.to).subscribe(response => {
				if (response.status === 200) {
					data.eta = parseInt(data.start_time) + response.data[0]['duration'].value;
					data.eta = data.eta.toString();
					data.total_miles = parseInt(response.data[0]['distance'].value) / 1609.344;
					data.total_miles = parseInt(data.total_miles);
				}else{
					data.total_miles = 600;
					data.eta = data.start_time;
				}

				if (this.isEdit) {
					this.tripService.updateTrip(this.tripGuid, data).subscribe(response => {
						if (response.status === 200) {
							this.spinner.hide();
							this.router.navigate(['/trips']);
							this._notificationService.add(new Notification('success', "Trip has been updated successfully."));
						} else {
							this.spinner.hide();
							this._notificationService.add(new Notification('error', response.message));
						}
					});
				} else {
					this.spinner.show();
					this.tripService.addTrip(data).subscribe(response => {
						if (response['status'] === 200) {
							this.spinner.hide();
							this.router.navigate(['/trips']);
							this._notificationService.add(new Notification('success', "Trip has been added successfully."));
						} else {
							this.spinner.hide();
							this._notificationService.add(new Notification('error', response['message']));
						}
					});
				}
			});
		}
	}

	afterPickerOpen() {
		$(function () {
			$("input.owl-dt-timer-input").attr("disabled", 'true');
		});
	}

	setTimePickerDeafult() {
		let start_time: Date = new Date();
		let end_time: Date = new Date();
		let minute = start_time.getMinutes();
		if (minute !== 0 && minute !== 15 && minute !== 45) {
			if (minute > 45) {
				start_time.setHours(start_time.getHours() + 1);
				start_time.setMinutes(0);
				this.tripForm.patchValue({ start_time: start_time });

				end_time.setHours(start_time.getHours() + 1);
				end_time.setMinutes(15);
				this.tripForm.patchValue({ end_time: end_time });
			} else if (minute > 30) {
				start_time.setMinutes(45);
				this.tripForm.patchValue({ start_time: start_time });

				end_time.setHours(start_time.getHours() + 1);
				end_time.setMinutes(0);
				this.tripForm.patchValue({ end_time: end_time });
			} else if (minute > 15) {
				start_time.setMinutes(30);
				this.tripForm.patchValue({ start_time: start_time });

				end_time.setMinutes(45);
				this.tripForm.patchValue({ end_time: end_time });
			} else {
				start_time.setMinutes(15);
				this.tripForm.patchValue({ start_time: start_time });

				end_time.setMinutes(30);
				this.tripForm.patchValue({ end_time: end_time });
			}
		} else if (minute > 45) {
			this.tripForm.patchValue({ start_time: start_time });

			end_time.setHours(start_time.getHours() + 1);
			end_time.setMinutes(15);
			this.tripForm.patchValue({ end_time: end_time });
		} else if (minute > 30) {
			this.tripForm.patchValue({ start_time: start_time });

			end_time.setMinutes(45);
			this.tripForm.patchValue({ end_time: end_time });
		} else if (minute > 15) {
			this.tripForm.patchValue({ start_time: start_time });

			end_time.setMinutes(30);
			this.tripForm.patchValue({ end_time: end_time });
		} else {
			this.tripForm.patchValue({ start_time: start_time });

			end_time.setMinutes(15);
			this.tripForm.patchValue({ end_time: end_time });
		}
	}

	onDateChange() { }
}