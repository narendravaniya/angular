import * as _ from 'lodash'
import * as moment from 'moment-timezone'
import { Component, OnInit, ViewChild } from '@angular/core'
import { ActivatedRoute } from '@angular/router'
import { NgxSpinnerService } from 'ngx-spinner'
import { AgmMap } from '@agm/core'
import { StompRService } from '@stomp/ng2-stompjs'
import { Message } from '@stomp/stompjs'
import { Subscription } from 'rxjs'
import { Observable } from 'rxjs/Observable'
import { DatePipe } from '@angular/common'
import { location } from './location'

import { DashboardService, DeviceService, Notification, NotificationService, TripService } from './../../../services/index'

@Component({
	selector: 'app-trip-detail',
	templateUrl: './trip-detail.component.html',
	styleUrls: ['./trip-detail.component.css'],
	providers: [StompRService]
})

export class TripDetailComponent implements OnInit {
	@ViewChild(AgmMap, {
		static: false
	}) public agmMap: AgmMap;
	status;
	moduleName = "Trip Detail";
	tripGuid = '';
	isEdit = false;
	tripDetail = {};
	toLat = '';
	toLng = '';
	fromLat = '';
	fromLng = '';
	tripStatus = '0%';
	completedMiles = 0;
	pipe = new DatePipe('en-US');

	stompConfiguration = {
		url: '',
		headers: {
			login: '',
			passcode: '',
			host: ''
		},
		heartbeat_in: 0,
		heartbeat_out: 2000,
		reconnect_delay: 5000,
		debug: true
	}
	subscription: Subscription;
	softboxDetail = [{}];
	isConnected = false;
	messages: Observable<Message>;
	subscribed;
	teleLastReceivedData: Array<string> = [];
	totalteleCount = 0;
	origin: any;
	destination: any;

	sensorData: any;
	tripStatusDetail: any = [];
	cpId: any;
	currentmpgStyle = '0%';
	airtempStyle = '0%';
	enginetempStyle = '0%';
	fuellevelStyle = '0%';
	sensorDetails = {
		'airtemp': 0,
		'currentmpg': 0,
		'currentspeed': 0,
		'enginetemp': 0,
		'fuellevel': 0,
		'humidity': 0,
		'latitude': 0,
		'longitude': 0,
		'precipitation': 0,
		'temperature': 0,
		'wind': 0
	}
	constructor(
		private tripService: TripService,
		private activatedRoute: ActivatedRoute,
		private spinner: NgxSpinnerService,
		private stompService: StompRService,
		private dashboardService: DashboardService,
		private _notificationService: NotificationService,
		private deviceService: DeviceService,
	) {
		this.activatedRoute.params.subscribe(params => {
			if (params.tripGuid) {
				this.getTripDetails(params.tripGuid);
				this.tripGuid = params.tripGuid;
				this.moduleName = "Trip Detail";
				this.isEdit = true;
			} else { }
		});
	}

	locationSteps: any;
	gMapLat = 0;
	gMapLng = 0;
	zoom = 5;

	mapStyle = [
		{
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#f5f5f5"
				}
			]
		},
		{
			"elementType": "labels.icon",
			"stylers": [
				{
					"visibility": "off"
				}
			]
		},
		{
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#616161"
				}
			]
		},
		{
			"elementType": "labels.text.stroke",
			"stylers": [
				{
					"color": "#f5f5f5"
				}
			]
		},
		{
			"featureType": "administrative.land_parcel",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#bdbdbd"
				}
			]
		},
		{
			"featureType": "poi",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#eeeeee"
				}
			]
		},
		{
			"featureType": "poi",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#757575"
				}
			]
		},
		{
			"featureType": "poi.park",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#e5e5e5"
				}
			]
		},
		{
			"featureType": "poi.park",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#9e9e9e"
				}
			]
		},
		{
			"featureType": "road",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#ffffff"
				}
			]
		},
		{
			"featureType": "road.arterial",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#757575"
				}
			]
		},
		{
			"featureType": "road.highway",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#dadada"
				}
			]
		},
		{
			"featureType": "road.highway",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#616161"
				}
			]
		},
		{
			"featureType": "road.local",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#9e9e9e"
				}
			]
		},
		{
			"featureType": "transit.line",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#e5e5e5"
				}
			]
		},
		{
			"featureType": "transit.station",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#eeeeee"
				}
			]
		},
		{
			"featureType": "water",
			"elementType": "geometry",
			"stylers": [
				{
					"color": "#c9c9c9"
				}
			]
		},
		{
			"featureType": "water",
			"elementType": "labels.text.fill",
			"stylers": [
				{
					"color": "#9e9e9e"
				}
			]
		}
	]

	ngOnInit() { }

	zoomChanged(event) {
		this.agmMap.triggerResize(true);
	}

	getGeoCoordinates(id) {
		id = id.replace(/[, ]+/g, "").trim().toLowerCase();
		this.locationSteps = location[id]['data'];
	}

	getTripDetails(tripGuid) {
		this.spinner.show();
		this.tripService.getDetails(tripGuid).subscribe(response => {
			if (response['status'] === 200) {
				this.tripDetail = response.data;
				this.getGeoCoordinates(this.tripDetail['from'])
				this.origin = {
					lat: parseFloat(this.tripDetail['fromLat']),
					lng: parseFloat(this.tripDetail['fromLng'])
				};
				this.destination = {
					lat: parseFloat(this.tripDetail['toLat']),
					lng: parseFloat(this.tripDetail['toLng'])
				};

				if (this.tripDetail['status'] === 2) {
					this.gMapLat = parseFloat(this.tripDetail['currentLat']);
					this.gMapLng = parseFloat(this.tripDetail['currentLng']);

					let journey = this.locationSteps;
					let totalLen = journey.length;
					let i = journey.findIndex(o => o.lat === parseFloat(this.tripDetail['currentLat']));
					if (i > 0) {
						let tripState = ((i + 1) * 100) / totalLen;
						this.tripStatus = tripState + '%';
						let cm = (this.tripDetail['total_miles'] * tripState) / 100;
						this.completedMiles = Math.ceil(cm);
					}
					this.startTrip();
					this.startSimulator();
				} else if (this.tripDetail['status'] === 3) {
					this.gMapLat = parseFloat(this.tripDetail['currentLat']);
					this.gMapLng = parseFloat(this.tripDetail['currentLng']);
				} else {
					this.gMapLat = parseFloat(this.tripDetail['currentLat']);
					this.gMapLng = parseFloat(this.tripDetail['currentLng']);
				}
			}
			this.getStompConfig();
			this.getSensors();
		});
	}

	statusChange(status) {
		let id = this.tripGuid;
		let data = { 'status': status };
		this.spinner.show();
		this.dashboardService.tripStatus(id, data).subscribe(response => {
			if (response['status'] === 200) {
				this.tripDetail['status'] = status;
				this.changeDeviceStatus(status);
				if (status == 2) {
					this.startSimulator();
					this.startTrip();
					this._notificationService.add(new Notification('success', "Trip is in transit"));
				} else if (status == 3) {
					this._notificationService.add(new Notification('success', "Trip is completed"));
				} else if (status == 4) {
					this._notificationService.add(new Notification('success', "Trip is cancelled"));
				}
				this.spinner.hide();
			} else {
				this.spinner.hide();
			}
		});
	}

	changeDeviceStatus(status) {
		let deviceStatus = 0;
		if (status === 2) {
			deviceStatus = 2;
		} else if (status === 3) {
			deviceStatus = 1;
		}

		if (deviceStatus) {
			this.deviceService.updateDevice(this.tripDetail['Device']['device_id'], { status: deviceStatus }).subscribe(response => {
			});
		}

	}

	startSimulator() {
		this.spinner.show();
		this.dashboardService.startSimulator(this.tripDetail['Device']['uniqueId'],false).subscribe(response => {
			if (response['status'] === 200) {
				this.spinner.hide();
			}
		});
	}

	startTrip() {
		let index = 0;
		let journey = this.locationSteps;
		let totalLen = journey.length;
		let i = journey.findIndex(o => o.lat === parseFloat(this.tripDetail['currentLat']));
		if (i > 0) {
			index = i;
		}

		setInterval(() => {
			if ((index + 1) <= journey.length && this.tripDetail['status'] === 2) {
				this.gMapLat = journey[index]['lat'];
				this.gMapLng = journey[index]['lng'];
				let tripState = ((index + 1) * 100) / totalLen;
				this.tripStatus = tripState + '%';
				let cm = (this.tripDetail['total_miles'] * tripState) / 100;
				this.completedMiles = Math.ceil(cm);
				this.updateTrip(this.gMapLat, this.gMapLng, this.completedMiles);
			} else if (this.tripDetail['status'] === 2) {
				this.statusChange(3);
				this.tripStatus = '100%';
				this.completedMiles = this.tripDetail['total_miles'];
			}
			index++;
		}, 1000);
		this.spinner.hide();
	}

	updateTrip(lat, lng, completedMiles) {
		var data = {
			'currentLat': lat,
			'currentLng': lng,
			'completed_miles': completedMiles
		}
		this.tripService.updateTrip(this.tripGuid, data).subscribe(response => { });
	}

	getStatus() {
		return parseInt(this.tripStatus);
	}

	getSensors() {
		let data = {
			"device_id": this.tripDetail['Device']['device_id']
		}
		this.dashboardService.getSensors(data).subscribe(response => {
			if (response['status'] === 200) {
				this.sensorData = response;
				this.sensorData['data'].forEach(element => {
					if (element['attributeName'] == 'airtemp') {
						this.airtempStyle = element['attributeValue'] + '%';
					} else if (element['attributeName'] == 'currentmpg') {
						this.currentmpgStyle = element['attributeValue'] + '%';
					} else if (element['attributeName'] == 'enginetemp') {
						this.enginetempStyle = element['attributeValue'] + '%';
					} else if (element['attributeName'] == 'fuellevel') {
						this.fuellevelStyle = element['attributeValue'] + '%';
					}
					this.sensorDetails[element['attributeName']] = element['attributeValue'];

				});
				this.spinner.hide();
			} else {
				this.spinner.hide();
			}
		});
	}

	getStompConfig() {
		this.dashboardService.getStompCon().subscribe(response => {
			this.stompConfiguration.url = response['data']['data']['url'];
			this.stompConfiguration.headers.login = response['data']['data']['user'];
			this.stompConfiguration.headers.passcode = response['data']['data']['password'];
			this.stompConfiguration.headers.host = response['data']['data']['vhost'];
			this.cpId = response['data']['data']['cpId'];
			this.initStomp();
		});
	}

	initStomp() {
		let config = this.stompConfiguration;
		this.stompService.config = config;
		this.stompService.initAndConnect();
		this.stompSubscribe();
	}

	public stompSubscribe() {
		if (this.subscribed) {
			return;
		}
		this.messages = this.stompService.subscribe('/topic/' + this.cpId + '-' + this.tripDetail['Device']['uniqueId']);
		this.subscription = this.messages.subscribe(this.on_next);
		this.subscribed = true;
	}

	public on_next = (message: Message) => {
		let obj: any = JSON.parse(message.body);
		this.isConnected = true;
		let now = moment().format("MM-DD-YYYY h:mm:ss A");
		obj.data.data.time = now;
		if (obj.data.data && obj.data.data.status && (obj.data.data.status === "on" || obj.data.data.status === "off")) { } else {
			this.currentmpgStyle = obj.data.data.reporting['currentmpg'] + '%';
			this.airtempStyle = obj.data.data.reporting['airtemp'] + '%';
			this.enginetempStyle = obj.data.data.reporting['enginetemp'] + '%';
			this.fuellevelStyle = obj.data.data.reporting['fuellevel'] + '%';

			this.sensorDetails = {
				'airtemp': obj.data.data.reporting['airtemp'],
				'currentmpg': obj.data.data.reporting['currentmpg'],
				'currentspeed': obj.data.data.reporting['currentspeed'],
				'enginetemp': obj.data.data.reporting['enginetemp'],
				'fuellevel': obj.data.data.reporting['fuellevel'],
				'humidity': obj.data.data.reporting['humidity'],
				'latitude': obj.data.data.reporting['latitude'],
				'longitude': obj.data.data.reporting['longitude'],
				'precipitation': obj.data.data.reporting['precipitation'],
				'temperature': obj.data.data.reporting['temperature'],
				'wind': obj.data.data.reporting['wind']
			}
		}
	}

	public stompUnsubscribe() {
		this.stompService.disconnect();
	}

	convertTimeToDate(startTimestamp) {
		let date = moment.unix(startTimestamp).tz(moment.tz.guess());
		return moment(date.toString()).format('HH:mm A, MM/DD/YYYY');
	}
}