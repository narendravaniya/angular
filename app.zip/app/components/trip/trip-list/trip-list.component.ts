import { Component, OnInit } from '@angular/core'
import { Router } from '@angular/router'
import { NgxSpinnerService } from 'ngx-spinner'
import * as moment from 'moment-timezone'

import { Notification, NotificationService, UserService, TripService } from './../../../services/index'

@Component({
  selector: 'app-trip-list',
  templateUrl: './trip-list.component.html',
  styleUrls: ['./trip-list.component.css']
})
export class TripListComponent implements OnInit {
	tripGuid;
	tripName;
	changeStatusUserName;
	isSearch = false;
	order = true;
	totalCount = 0;
	reverse = false;
	orderBy = 'name';
	searchParameters = {
		pageNumber: 1,
		pageSize: 10,
		searchText: '',
		sortBy: 'trip_id desc'
	};
	tripList = [];

	constructor(
		private spinner: NgxSpinnerService,
		private tripService: TripService,
		private userService: UserService,
		private router: Router,
		private _notificationService: NotificationService,
	) { }

	ngOnInit() {
		this.getTripList();
	}

	clickAdd() {
		this.router.navigate(['/trip/add']);
	}

	convertTimeToDate(startTimestamp) {
		let date = moment.unix(startTimestamp).tz(moment.tz.guess());
		return moment(date.toString()).format('HH:mm A, MM/DD/YYYY');
	}

	setOrder(value: string) {
		if (this.orderBy !== value) {
			this.reverse = true;
		}
		this.orderBy = value;
		if (this.reverse === true) {
			this.reverse = !this.reverse;
			this.searchParameters.sortBy = value + ' asc';
		} else {
			this.reverse = !this.reverse;
			this.searchParameters.sortBy = value + ' desc';
		}
		this.getTripList();
	}

	onPageSizeChangeCallback(pageSize) {
		this.searchParameters.pageSize = pageSize;
		this.searchParameters.pageNumber = 1;
		this.isSearch = true;
		this.getTripList();
	}

	ChangePaginationAsPageChange(pagechangeresponse) {
		this.searchParameters.pageNumber = pagechangeresponse;
		this.isSearch = true;
		this.getTripList();
	}

	searchTextCallback(filterText) {
		this.searchParameters.searchText = filterText;
		this.searchParameters.pageNumber = 1;
		this.getTripList();
		this.isSearch = true;
	}

	
	openDeleteDialog(guid, name) {
		this.tripGuid = guid;
		this.tripName = name;
	}

	getTripList() {
		this.spinner.show();
		this.tripService.getTrips(this.searchParameters).subscribe(response => {
			this.spinner.hide();
			this.totalCount = response.data.count;
			this.tripList = response.data.rows;
			this.isSearch = false;
		});
	}

	

	delete() {
		this.spinner.show();
		this.tripService.deleteTrip(this.tripGuid).subscribe(response => {
			this.spinner.hide();
			this._notificationService.add(new Notification('success', response.message));
			if (this.searchParameters.pageNumber !== 1 && this.tripList.length === 1) {
				this.searchParameters.pageNumber = this.searchParameters.pageNumber - 1;
			}
			this.getTripList();
		}, error => {
			this.spinner.hide();
			this._notificationService.add(new Notification('error', error));
		});
	}
}
