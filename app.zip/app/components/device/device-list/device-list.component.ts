import { Component, OnInit } from '@angular/core'
import { Router } from '@angular/router'
import { NgxSpinnerService } from 'ngx-spinner'

import { DeviceService, Notification, NotificationService } from './../../../services/index'

@Component({ selector: 'app-device-list', templateUrl: './device-list.component.html', styleUrls: ['./device-list.component.scss'] })

export class DeviceListComponent implements OnInit {
	changeStatusDeviceGuid;
	changeStatusDeviceStatus;
	changeStatusDeviceName;
	order = true;
	isSearch = false;
	totalDeviceCount = 0;
	reverse = false;
	orderBy = 'name';
	spaceSearchParameters = {
		pageNumber: 1,
		pageSize: 10,
		searchText: '',
		sortBy: 'device_id asc'
	};
	deviceList = [];

	constructor(
		private spinner: NgxSpinnerService,
		private deviceService: DeviceService,
		private router: Router,
		private _notificationService: NotificationService,
	) { }

	ngOnInit() {
		this.getDeviceList();
	}

	manageAddDevice() {
		this.router.navigate(['/truck/add']);
	}

	setOrder(value: string) {
		if (this.orderBy !== value) {
			this.reverse = true;
		}
		this.orderBy = value;
		if (this.reverse === true) {
			this.reverse = !this.reverse;
			this.spaceSearchParameters.sortBy = value + ' asc';
		} else {
			this.reverse = !this.reverse;
			this.spaceSearchParameters.sortBy = value + ' desc';
		}
		this.getDeviceList();
	}

	onPageSizeChangeCallback(pageSize) {
		this.spaceSearchParameters.pageSize = pageSize;
		this.spaceSearchParameters.pageNumber = 1;
		this.isSearch = true;
		this.getDeviceList();
	}

	ChangePaginationAsPageChange(pagechangeresponse) {
		this.spaceSearchParameters.pageNumber = pagechangeresponse;
		this.isSearch = true;
		this.getDeviceList();
	}

	searchTextCallback(filterText) {
		this.spaceSearchParameters.searchText = filterText;
		this.spaceSearchParameters.pageNumber = 1;
		this.getDeviceList();
		this.isSearch = true;
	}

	openChangeStatusDialog(guid, name, status) {
		this.changeStatusDeviceGuid = guid;
		this.changeStatusDeviceName = name;
		this.changeStatusDeviceStatus = status;
	}

	openDeleteDialog(guid, name) {
		this.changeStatusDeviceGuid = guid;
		this.changeStatusDeviceName = name;
	}

	getDeviceList() {
		this.spinner.show();
		this.deviceService.getDevices(this.spaceSearchParameters).subscribe(response => {
			this.spinner.hide();
			this.totalDeviceCount = response.recordsTotal;
			this.deviceList = response.data;
			this.isSearch = false;
		});
	}

	changeDeviceStatus() {
		let data;
		if (this.changeStatusDeviceStatus === 0) {
			data = {
				'status': 1
			}
		} else if (this.changeStatusDeviceStatus === 1) {
			data = {
				'status': 0
			}
		}

		this.spinner.show();
		this.deviceService.changeDeviceStatus(this.changeStatusDeviceGuid, data).subscribe(response => {
			this.spinner.hide();
			if (response.status === 200) {
				this._notificationService.add(new Notification('success', response.message));
				this.getDeviceList();
			} else {
				this.spinner.hide();
				this._notificationService.add(new Notification('error', response.message));
			}
		}, error => {
			this.spinner.hide();
			this._notificationService.add(new Notification('error', error));
		});
	}

	deleteDevice() {
		this.spinner.show();
		this.deviceService.deleteDevice(this.changeStatusDeviceGuid).subscribe(response => {
			this.spinner.hide();
			this._notificationService.add(new Notification('success', response.message));
			if (this.spaceSearchParameters.pageNumber !== 1 && this.deviceList.length === 1) {
				this.spaceSearchParameters.pageNumber = this.spaceSearchParameters.pageNumber - 1;
			}
			this.getDeviceList();
		}, error => {
			this.spinner.hide();
			this._notificationService.add(new Notification('error', error));
		});
	}
}