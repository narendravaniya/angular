import { Component, ElementRef, OnInit, ViewChild } from '@angular/core'
import { ActivatedRoute, Router } from '@angular/router'
import { FormControl, FormGroup, Validators } from '@angular/forms'
import { NgxSpinnerService } from 'ngx-spinner'

import {  DeviceService,  Notification, NotificationService } from './../../../services/index'

@Component({ selector: 'app-device-add', templateUrl: './device-add.component.html', styleUrls: ['./device-add.component.scss'] })

export class DeviceAddComponent implements OnInit {
	@ViewChild('floor_image_Ref', { static: false }) floor_image_Ref: ElementRef;
	fileUrl: any;
	fileName = '';
	fileToUpload: any = null;
	status;
	moduleName = "Add Fleet";
	deviceObject = {};
	deviceGuid = '';
	isEdit = false;
	deviceForm: FormGroup;
	checkSubmitStatus = false;
	buildingList = [];
	selectedBuilding = '';
	floorList = [];
	spaceList = [];
	templateList = [];

	constructor(
		private deviceService: DeviceService,
		private router: Router,
		private _notificationService: NotificationService,
		private activatedRoute: ActivatedRoute,
		private spinner: NgxSpinnerService
	) {
		this.createFormGroup();
		this.activatedRoute.params.subscribe(params => {
			if (params.deviceGuid) {
				this.getDeviceDetails(params.deviceGuid);
				this.deviceGuid = params.deviceGuid;
				this.moduleName = "Edit Fleet";
				this.isEdit = true;
			}else {
				this.deviceObject = { unique_id: '', display_name: '', email: '', type: '', device_template_id: '', note: '', status:'1' }
			}
		});
	}

	ngOnInit() {
		this.getTemplateLookup();
		
	}

	createFormGroup() {
		this.deviceForm = new FormGroup({
			unique_id: new FormControl('', [Validators.required]),
			display_name: new FormControl('', [Validators.required]),
			type: new FormControl('', [Validators.required]),
			device_template_id: new FormControl('', [Validators.required]),
			note: new FormControl(''),
			image: new FormControl(''),
			status: new FormControl('')
		});
	}
	
	getTemplateLookup() {
		this.deviceService.getTemplateLookup().subscribe(response => {
			this.templateList = response['data'];
			this.deviceForm.patchValue({'device_template_id':this.templateList[0]['device_template_id']});
		});
	}

	addDevice() {
		this.checkSubmitStatus = true;
		if (this.deviceForm.status === "VALID") {
			if (this.isEdit) {
				this.spinner.show();
				this.deviceService.updateDevice(this.deviceGuid, this.deviceForm.value).subscribe(response => {
					console.log("RESPNSE :::::::::::::",this.deviceForm.value)
					if (response.status === 200) {
						if (this.fileName.length > 0) {
							this.deviceService.uploadPicture(this.deviceGuid, this.fileToUpload).subscribe(response => {
								this.spinner.hide();
								this.router.navigate(['/truck']);
								this._notificationService.add(new Notification('success', "Truck has been updated successfully."));
							});
						} else {
							this.spinner.hide();
							this.router.navigate(['/truck']);
							this._notificationService.add(new Notification('success', "Truck has been updated successfully."));
						}
					} else {
						this.spinner.hide();
						this._notificationService.add(new Notification('error', response.message));
					}
				});
			} else {
				this.spinner.show();
				this.deviceForm.patchValue({'status': '1'});
				console.log("RESPNSE :::::::::::::",this.deviceForm.value)
				
				this.deviceService.addDevice(this.deviceForm.value).subscribe(response => {
					
					if (response.status === 200) {
						if (this.fileName.length > 0) {
							console.log("RES:::::::::::",response.data[0]['newid'])
							this.deviceService.uploadPicture(response.data[0]['newid'], this.fileToUpload).subscribe(response => {
								this.spinner.hide();
								this.router.navigate(['/truck']);
								this._notificationService.add(new Notification('success', "Truck has been added successfully."));
							});
						} else {
							this.spinner.hide();
							this.router.navigate(['/truck']);
							this._notificationService.add(new Notification('success', "Truck has been added successfully."));
						}
					} else {
						this.spinner.hide();
						this._notificationService.add(new Notification('error', response.message));
					}
				});
			}
		}
	}

	removeFile(type) {
		if (type === 'image') {
			this.fileUrl = '';
			this.floor_image_Ref.nativeElement.value = '';
		}
	}

	handleImageInput(event) {
		let files = event.target.files;
		if (files.length) {
			let fileType = files.item(0).name.split('.');
			let imagesTypes = ['jpeg', 'JPEG', 'jpg', 'JPG', 'png', 'PNG'];
			if (imagesTypes.indexOf(fileType[fileType.length - 1]) !== -1) {
				this.fileName = files.item(0).name;
				this.fileToUpload = files.item(0);
			} else {
				this.fileToUpload = null;
				this.fileName = '';
			}
		}

		if (event.target.files && event.target.files[0]) {
			var reader = new FileReader();
			reader.readAsDataURL(event.target.files[0]);
			reader.onload = (innerEvent: any) => {
				this.fileUrl = innerEvent.target.result;
			}
		}
	}

	getDeviceDetails(deviceGuid) {
		this.spinner.show();
		this.deviceService.getDeviceDetails(deviceGuid).subscribe(response => {
			this.spinner.hide();
			if (response.status === 200) {
				
				this.deviceObject = response.data;
				this.fileUrl = this.deviceObject['image'];
			}
		});
	}
}