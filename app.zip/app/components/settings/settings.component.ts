import { Component, OnInit } from '@angular/core'
import { ActivatedRoute } from '@angular/router'
import { NgxSpinnerService } from 'ngx-spinner'

import { Notification, NotificationService, SettingsService } from './../../services/index'

@Component({
	selector: 'app-settings',
	templateUrl: './settings.component.html',
	styleUrls: ['./settings.component.css']
})

export class SettingsComponent implements OnInit {
	googleConnected = false;
	officeConnected = false;
	constructor(
		private settingsService: SettingsService,
		private _notificationService: NotificationService,
		private spinner: NgxSpinnerService,
		private activatedRoute: ActivatedRoute
	) { }

	ngOnInit() {
		this.getSettingDetails();
		this.activatedRoute.queryParams.subscribe(params => {
			if (params && params.code && params.app === "google") {
				this.googleIntegrationInfo();
			} else if (params && params.code) {
				this.officeIntegrationInfo();
			}
		});
	}

	getSettingDetails() {
		this.spinner.show();
		this.settingsService.getSettingDetails().subscribe(response => {
			this.spinner.hide();
			this.googleConnected = response.data.googleIntegration === '1' ? true : false;
			this.officeConnected = response.data.officeIntegration === '1' ? true : false;
		});
	}

	officeIntegration() {
		if (this.officeConnected) {
			this.unRegisterOffice();
		} else {
			this.settingsService.getOfficeSignInUrl().subscribe(response => {
				this.apiWindow(response.data);
			});
		}
	}

	googleIntegration() {
		if (this.googleConnected) {
			this.unRegisterGoogle();
		} else {
			this.settingsService.getGoogleSignInUrl().subscribe(response => {
				this.apiWindow(response.data);
			});
		}
	}

	unRegisterGoogle() {
		this.settingsService.unRegisterGoogle().subscribe(response => {
			this.googleConnected = false;
		});
	}

	unRegisterOffice() {
		this.settingsService.unRegisterOffice().subscribe(response => {
			this.officeConnected = false;
		});
	}

	googleIntegrationInfo() {
		this.settingsService.apiIntegrationInfo().subscribe(response => {
			this.googleConnected = true;
			window.close()
		});
	}

	officeIntegrationInfo() {
		this.settingsService.apiIntegrationInfo().subscribe(response => {
			this.officeConnected = true;
			window.close()
		});
	}

	apiWindow(URL = null) {
		window.open(URL, '_blank', 'width=500,height=600,toolbars=no,menubar=no,location=no,scrollbars=no,resizable=0,Fullscreen=no');
	}
}