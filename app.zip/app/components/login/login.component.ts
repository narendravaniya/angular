import { Component, OnInit } from '@angular/core'
import { FormControl, FormGroup, Validators } from '@angular/forms'
import { Router } from '@angular/router'
import { NgxSpinnerService } from 'ngx-spinner'

import { Notification, NotificationService, UserService } from '../../services/index'

@Component({
	selector: 'app-login',
	templateUrl: './login.component.html',
	styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
	loginform: FormGroup;
	checkSubmitStatus = false;
	loginObject = {};

	constructor(
		private spinner: NgxSpinnerService,
		public router: Router,
		private UserService: UserService,
		private _notificationService: NotificationService
	) { }

	ngOnInit() {
		this.createFormGroup();
	}

	createFormGroup() {
		this.loginform = new FormGroup({
			username: new FormControl('', [Validators.required]),
			password: new FormControl('', [Validators.required]),
		});

		this.loginObject = {
			username: '',
			password: '',
		};
	}

	login() {
		this.checkSubmitStatus = true;
		
		if (this.loginform.status === "VALID" && this.checkSubmitStatus) {
			this.spinner.show();
			this.UserService.getBasicToken().subscribe(result => {
				this.UserService.login(this.loginObject).subscribe(response => {
					this.spinner.hide();
					if (response.status === 200 && response.access_token) {
						this._notificationService.add(new Notification('success', 'Logged in successfully'));
						this.router.navigate(['/']);
					}
					else {
						this._notificationService.add(new Notification('error', response.message));
						this.router.navigate(['/login']);
					}
				}, error => {
					this.spinner.hide();
					this._notificationService.add(new Notification('error', error.error.message));
				});
			});
		}
	}
}