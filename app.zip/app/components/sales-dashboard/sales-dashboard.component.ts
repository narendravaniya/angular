import * as moment from 'moment-timezone'
import { NgxSpinnerService } from 'ngx-spinner'
import { Component, OnInit, ViewChild } from '@angular/core'
import { DashboardService } from 'app/services'
import { StompRService } from '@stomp/ng2-stompjs'
import { Observable } from 'rxjs/Observable'
import { Subscription } from 'rxjs'
import { Message } from '@stomp/stompjs'
import { Router } from '@angular/router'

import { AzureMapComponent } from '../azure-map/azure-map.component'
import { environment } from './../../../environments/environment'
import { math } from 'azure-maps-control'

@Component({
	selector: 'app-sales-dashboard',
	templateUrl: './sales-dashboard.component.html',
	styleUrls: ['./sales-dashboard.component.css'],
	providers: [StompRService]
})

export class SalesDashboardComponent implements OnInit {
	@ViewChild(AzureMapComponent, { static: false }) child: AzureMapComponent;
	truckLookup = [];
	notificationList: any = [];
	truckGraphList = [];
	selectedTruck;
	sensorDetails = {}
	sensorTime = new Date()
	vehicle_ignition = false
	stompConfiguration = {
		url: '',
		headers: {
			login: '',
			passcode: '',
			host: ''
		},
		heartbeat_in: 0,
		heartbeat_out: 2000,
		reconnect_delay: 5000,
		debug: true
	}
	subscription: Subscription;
	isConnected = false;
	messages: Observable<Message>;
	subscribed;
	cpId = '';
	lineChart = {
		chartType: 'LineChart',
		dataTable: [['Days', 'Hours'], []],
		options: {
			'title': 'Gateway Uptime',
			vAxis: {
				title: "Hours"
			},
			hAxis: {
				title: "Days"
			},
			legend: { position: 'bottom', alignment: 'start' },
			height: '400',
			series: [{ color: '#05b76b', visibleInLegend: true }, { color: '#e8db36', visibleInLegend: true }]
		},
	};
	speedGaugeChart = {
		chartType: 'Gauge',
		dataTable: [
			['Label', 'Value'],
			['Speed', 0]
		],
		options: {
			yellowFrom: 80,
			yellowTo: 120,
			redFrom: 120,
			redTo: 160,
			max: 160,
			minorTicks: 5,
			majorTicks: [0, 20, 40, 60, 80, 100, 120, 140, 160]
		},
	};
	rpmGaugeChart = {
		chartType: 'Gauge',
		dataTable: [
			['Rpm', 0]
		],
		options: {
			max: 8000,
			minorTicks: 10,
			majorTicks: [0, 1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000]
		},
	};
	coolantGaugeChart = {
		chartType: 'Gauge',
		dataTable: [
			['Coolant', 0]
		],
		options: {
			min: -40,
			max: 215,
			minorTicks: 10,
			majorTicks: [-40, 10, 60, 110, 160, 215]
		},
	};
	fuel_color = 'primary';
	fuel_text = 'Low';
	fuel_value = 0;
	isAzureMap = true;
	lineChartData = true;

	constructor(
		private spinner: NgxSpinnerService,
		private dashboardService: DashboardService,
		private stompService: StompRService,
		private router: Router,
	) { }

	ngOnInit() {
		this.spinner.show();
		this.getTruckLookup();
		this.getNotificationList();
	}

	getTruckLookup() {
		this.dashboardService.getTruckLookup().subscribe(response => {
			this.truckLookup = response['data'];
			if (this.truckLookup.length) {
				this.selectedTruck = this.truckLookup[0];
				this.getSensors(true);
				this.getStompConfig();
				//this.getDeviceAttributeHistoricalData()
			}
		});
	}

	getSensors(flag = false) {
		if (!flag) {
			this.spinner.show();
			this.isAzureMap = false;
			setTimeout(() => {
				this.isAzureMap = true;
				this.spinner.hide();
			}, 100);

			this.subscribed = false;
			this.stompSubscribe();
			//this.getDeviceAttributeHistoricalData()
		} else {
			this.spinner.hide();
		}
		let data = {
			"device_id": this.selectedTruck['guid']
		}
		this.dashboardService.getSensors(data).subscribe(response => {
			if (response['status'] === 200) {
				response['data'].forEach(element => {
					this.sensorDetails[element['attributeName']] = element['attributeValue'];
				});
			}

			if (this.sensorDetails['fleet_uptime']) {
				this.sensorDetails['fleet_uptime'] = '8';
				let fleetUp = (parseInt(this.sensorDetails['fleet_uptime']) * 100) / 32;
				this.fuel_value = Math.floor(fleetUp);
				//this.fuel_value = parseInt(fleetUp) / 0.77;
				if (this.sensorDetails['fleet_uptime'] > 0 && this.sensorDetails['fleet_uptime'] <= 8) {
					this.fuel_color = 'warn';
					this.fuel_text = 'Low';
				} else if (this.sensorDetails['fleet_uptime'] > 8 && this.sensorDetails['fleet_uptime'] <= 20) {
					this.fuel_color = 'accent';
					this.fuel_text = 'Medium';
				} else {
					this.fuel_color = 'primary';
					this.fuel_text = 'Moderate';
				}
			}

			if (this.sensorDetails['can_vehicle_speed']) {
				this.speedGaugeChart = {
					chartType: 'Gauge',
					dataTable: [
						['Label', 'Value'],
						['Speed', this.convertToM(parseInt(this.sensorDetails['can_vehicle_speed']))]
					],
					options: {
						yellowFrom: 80,
						yellowTo: 120,
						redFrom: 120,
						redTo: 160,
						max: 160,
						minorTicks: 5,
						majorTicks: [0, 20, 40, 60, 80, 100, 120, 140, 160]
					},
				};
			} else {
				this.sensorDetails['can_vehicle_speed'] = 0;
				this.speedGaugeChart = {
					chartType: 'Gauge',
					dataTable: [
						['Label', 'Value'],
						['Speed', 0]
					],
					options: {
						yellowFrom: 80,
						yellowTo: 120,
						redFrom: 120,
						redTo: 160,
						max: 160,
						minorTicks: 5,
						majorTicks: [0, 20, 40, 60, 80, 100, 120, 140, 160]
					},
				};
			}

			if (this.sensorDetails['can_engine_rpm']) {
				this.rpmGaugeChart = {
					chartType: 'Gauge',
					dataTable: [
						['Label', 'Value'],
						['Rpm', parseInt(this.sensorDetails['can_engine_rpm'].replace(',', ''))]
					],
					options: {
						max: 8000,
						minorTicks: 10,
						majorTicks: [0, 1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000]
					},
				};
			} else {
				this.sensorDetails['can_engine_rpm'] = 0;
				this.rpmGaugeChart = {
					chartType: 'Gauge',
					dataTable: [
						['Label', 'Value'],
						['Rpm', 0]
					],
					options: {
						max: 8000,
						minorTicks: 10,
						majorTicks: [0, 1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000]
					},
				};
			}

			if (this.sensorDetails['can_coolant_temp']) {
				this.coolantGaugeChart = {
					chartType: 'Gauge',
					dataTable: [
						['Label', 'Value'],
						['Coolant', parseInt(this.sensorDetails['can_coolant_temp'])]
					],
					options: {
						min: -40,
						max: 215,
						minorTicks: 10,
						majorTicks: [-40, 10, 60, 110, 160, 215]
					},
				};
			} else {
				this.sensorDetails['can_coolant_temp'] = '0'
				this.coolantGaugeChart = {
					chartType: 'Gauge',
					dataTable: [
						['Label', 'Value'],
						['Coolant', 0]
					],
					options: {
						min: -40,
						max: 215,
						minorTicks: 10,
						majorTicks: [-40, 10, 60, 110, 160, 215]
					},
				};
			}
		});
		// this.startSimulator();
	}

	getStompConfig() {
		this.dashboardService.getStompCon().subscribe(response => {
			this.stompConfiguration.url = response['data']['data']['url'];
			this.stompConfiguration.headers.login = response['data']['data']['user'];
			this.stompConfiguration.headers.passcode = response['data']['data']['password'];
			this.stompConfiguration.headers.host = response['data']['data']['vhost'];
			this.cpId = response['data']['data']['cpId'];
			this.initStomp();
		});
	}

	initStomp() {
		let config = this.stompConfiguration;
		this.stompService.config = config;
		this.stompService.initAndConnect();
		this.stompSubscribe();
	}

	public stompSubscribe() {
		if (this.subscribed) {
			return;
		}

		this.messages = this.stompService.subscribe('/topic/' + this.cpId + '-' + this.selectedTruck['uniqueId']);
		this.subscription = this.messages.subscribe(this.on_next);
		this.subscribed = true;
	}

	public on_next = (message: Message) => {
		var refThis = this;
		var env = environment.env;
		let messageId = (message['headers']['destination']).split('/')[2].split(env)[1];
		let obj: any = JSON.parse(message.body);
		let now = moment().format("MM-DD-YYYY h:mm:ss A");
		obj.data.data.time = now;
		if (obj.data.data.status && obj.data.data.status === 'on') {
			refThis.vehicle_ignition = true;
		} else if (obj.data.data.status && obj.data.data.status === 'off') {
			refThis.vehicle_ignition = false;
		}
		if (obj.data.data && obj.data.data.status && (obj.data.data.status === "on" || obj.data.data.status === "off")) {
			console.log('messageId -> ', messageId);
			console.log('refThis.selectedTruck -> uniqueId -> ', refThis.selectedTruck['uniqueId']);
		} else {
			console.log('messageId=============', messageId);
			console.log('messageId=============', refThis.selectedTruck['uniqueId']);
			if (messageId === refThis.selectedTruck['uniqueId']) {
				if (obj.data.data.reporting['can_coolant_temp'])
					refThis.sensorDetails['can_coolant_temp'] = obj.data.data.reporting['can_coolant_temp']
				if (obj.data.data.reporting['can_engine_rpm'])
					refThis.sensorDetails['can_engine_rpm'] = obj.data.data.reporting['can_engine_rpm']
				if (obj.data.data.reporting['can_engine_rpm_total'])
					refThis.sensorDetails['can_engine_rpm_total'] = obj.data.data.reporting['can_engine_rpm_total']
				if (obj.data.data.reporting['can_fuel_level'])
					refThis.sensorDetails['can_fuel_level'] = obj.data.data.reporting['can_fuel_level']
				if (obj.data.data.reporting['can_hours_operation'])
					refThis.sensorDetails['can_hours_operation'] = obj.data.data.reporting['can_hours_operation']
				if (obj.data.data.reporting['can_odometer'])
					refThis.sensorDetails['can_odometer'] = obj.data.data.reporting['can_odometer']
				if (obj.data.data.reporting['can_vehicle_speed'])
					refThis.sensorDetails['can_vehicle_speed'] = obj.data.data.reporting['can_vehicle_speed']
				if (obj.data.data.reporting['fleet_uptime'])
					refThis.sensorDetails['fleet_uptime'] = obj.data.data.reporting['fleet_uptime']
				if (obj.data.data.reporting['gps_lat'])
					refThis.sensorDetails['gps_lat'] = obj.data.data.reporting['gps_lat']
				if (obj.data.data.reporting['gps_lng'])
					refThis.sensorDetails['gps_lng'] = obj.data.data.reporting['gps_lng']
				if (obj.data.data.reporting['gps_num_sats'])
					refThis.sensorDetails['gps_num_sats'] = obj.data.data.reporting['gps_num_sats']

				refThis.sensorTime = obj.data.data.time;
				refThis.vehicle_ignition = true;
				if (obj.data.data.reporting['can_vehicle_speed']) {
					refThis.speedGaugeChart = {
						chartType: 'Gauge',
						dataTable: [
							['Label', 'Value'],
							['Speed', this.convertToM(parseInt(obj.data.data.reporting['can_vehicle_speed']))]
						],
						options: {
							yellowFrom: 80,
							yellowTo: 120,
							redFrom: 120,
							redTo: 160,
							max: 160,
							minorTicks: 5,
							majorTicks: [0, 20, 40, 60, 80, 100, 120, 140, 160]
						},
					};
				}

				if (obj.data.data.reporting['can_engine_rpm']) {
					refThis.rpmGaugeChart = {
						chartType: 'Gauge',
						dataTable: [
							['Label', 'Value'],
							['Rpm', parseInt(obj.data.data.reporting['can_engine_rpm'].replace(',', ''))]
						],
						options: {
							max: 8000,
							minorTicks: 10,
							majorTicks: [0, 1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000]
						},
					};
				}

				if (obj.data.data.reporting['can_coolant_temp']) {
					this.coolantGaugeChart = {
						chartType: 'Gauge',
						dataTable: [
							['Label', 'Value'],
							['Coolant', parseInt(obj.data.data.reporting['can_coolant_temp'])]
						],
						options: {
							min: -40,
							max: 215,
							minorTicks: 10,
							majorTicks: [-40, 10, 60, 110, 160, 215]
						},
					};
				}

				if (obj.data.data.reporting['fleet_uptime']) {
					let fleetUp = (parseInt(this.sensorDetails['fleet_uptime']) * 100) / 32;
					refThis.fuel_value = Math.floor(fleetUp);
					if (obj.data.data.reporting['fleet_uptime'] > 0 && obj.data.data.reporting['fleet_uptime'] <= 8) {
						refThis.fuel_color = 'warn';
						refThis.fuel_text = 'Low';
					} else if (obj.data.data.reporting['fleet_uptime'] > 8 && obj.data.data.reporting['fleet_uptime'] <= 20) {
						refThis.fuel_color = 'accent';
						refThis.fuel_text = 'Medium';
					} else {
						refThis.fuel_color = 'primary';
						refThis.fuel_text = 'Moderate';
					}
				}
			}
		}
	}

	public stompUnsubscribe() {
		this.stompService.disconnect();
		this.subscribed = false;
	}

	// startSimulator() {
	// 	this.dashboardService.startSimulator(this.selectedTruck['uniqueId']).subscribe(response => {
	// 	this.child.play();
	// 	});
	// }

	getNotificationList() {
		this.dashboardService.getNotificationList().subscribe(response => {
			this.notificationList = response['rows'];
		});
	}

	getDeviceAttributeHistoricalData() {
		this.dashboardService.getDeviceAttributeHistoricalData({
			templateAttributeGuid: "fleet_uptime",
			uniqueId: this.selectedTruck['uniqueId'],
			endDate: moment().tz('UTC').format('YYYY-MM-DD'),
			startDate: moment(moment().tz('UTC').format()).subtract(7, 'days').endOf('day').tz('UTC').format('YYYY-MM-DD')
		}).subscribe(response => {
			if (response['data'].length > 0) {
				this.truckGraphList = response['data'];
				this.truckGraphList.unshift(['Days', 'Hours']);
				this.lineChart.dataTable = this.truckGraphList;
				this.lineChart = {
					chartType: 'LineChart',
					dataTable: this.truckGraphList,
					options: {
						'title': 'Gateway Uptime',
						vAxis: {
							title: "Hours"
						},
						hAxis: {
							title: "Days"
						},
						legend: { position: 'bottom', alignment: 'start' },
						height: '400',
						series: [{ color: '#05b76b', visibleInLegend: true }, { color: '#e8db36', visibleInLegend: true }]
					},
				};
			} else {
				this.lineChartData = false;
			}
		});
	}

	convertToM(km) {
		let miles = Math.floor(km / 1.609)
		return miles;
	}
}