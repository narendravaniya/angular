import * as _ from 'lodash'
import { Title } from '@angular/platform-browser'
import { Component } from '@angular/core'
import { Event as RouterEvent, NavigationCancel, NavigationEnd, NavigationError, NavigationStart, Router } from '@angular/router'
import { UserService } from './services';
import { ConfigService } from './services/config/config.service';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.css']
})

export class AppComponent {
	loading: boolean = true;
	isLoginURL = false;
	loginURL = '';

	isAdminLoading = false;
	isAdmin = false;
	checkedAfterLogin = false;

	constructor(
		private router: Router,
		private titleService: Title,
		private userService: UserService,
		private configService: ConfigService) {
		let routesArray = ['forgotPassword', 'login', 'resetpassword'];
		this.router.events.subscribe((event: RouterEvent) => {
			this.navigationInterceptor(event);
			if (event instanceof NavigationEnd) {
				var title = this.getTitle(this.router.routerState, this.router.routerState.root);
				if (title[0]) {
					this.titleService.setTitle('Fleet Management' + ' - ' + title[0]);
				} else {
					this.titleService.setTitle('Fleet Management ');
				}

				this.loginURL = event.url;
				let newRoute = _.toString(_.split(this.loginURL, '/')[1]) || '/';
				if (routesArray.indexOf(newRoute) > -1) {
					this.isLoginURL = false;
					this.checkedAfterLogin = false;
				} else {
					this.isLoginURL = true;
					if (!this.checkedAfterLogin) {
						this.checkUser();
					}
				}
			}
		});

	}

	checkUser() {
		this.isAdminLoading = true;
		this.isAdmin = false;
		this.userService.getUserInfo().subscribe(userData => {
			this.isAdminLoading = false;
			if (userData['data']['parentEntityGuid'] === null) {
				this.isAdmin = true;
				this.configService.isShowLeftMenu = 'true';
			} else {
				this.isAdmin = false;
				this.configService.isShowLeftMenu = 'false';
			}
			this.checkedAfterLogin = true;
		});
	}

	getTitle(state, parent) {
		var data = [];
		if (parent && parent.snapshot.data && parent.snapshot.data.title) {
			data.push(parent.snapshot.data.title);
		}

		if (state && parent) {
			data.push(... this.getTitle(state, state.firstChild(parent)));
		}
		return data;
	}

	// Shows and hides the loading spinner during RouterEvent changes
	navigationInterceptor(event: RouterEvent): void {
		if (event instanceof NavigationStart) {
			this.loading = true;
		}
		if (event instanceof NavigationEnd) {
			this.loading = false;
		}

		// Set loading state to false in both of the below events to hide the spinner in case a request fails
		if (event instanceof NavigationCancel) {
			this.loading = false;
		}
		if (event instanceof NavigationError) {
			this.loading = false;
		}
	}
}