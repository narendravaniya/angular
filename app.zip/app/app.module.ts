import { BrowserModule } from '@angular/platform-browser'
import { NgModule } from '@angular/core'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { HttpModule } from '@angular/http'
import { HttpClientModule } from '@angular/common/http'
import { NgxSpinnerModule } from 'ngx-spinner'
import { CookieService } from 'ngx-cookie-service'
import { SocketIoConfig, SocketIoModule } from 'ng-socket-io'
import { NgxPaginationModule } from 'ngx-pagination'
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { TagInputModule } from 'ngx-chips'
import { DateTimeAdapter, OWL_DATE_TIME_FORMATS, OWL_DATE_TIME_LOCALE, OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime'
import { MomentDateTimeAdapter } from 'ng-pick-datetime-moment'
import { MatButtonModule, MatCheckboxModule, MatInputModule, MatProgressBarModule, MatSelectModule, MatSlideToggleModule, MatTabsModule } from '@angular/material'
import { Ng2GoogleChartsModule } from 'ng2-google-charts'
import { FullCalendarModule } from '@fullcalendar/angular'
import { AgmCoreModule } from '@agm/core'
import { AgmJsMarkerClustererModule } from '@agm/js-marker-clusterer'
import { AgmDirectionModule } from 'agm-direction'

import { AppRoutingModule } from './app-routing.module'
import { AppComponent } from './app.component'
import { PageNotFoundComponent } from './page-not-found.component'
import { ConfirmDialogComponent, DashboardComponent, DeleteDialogComponent, DeviceAddComponent, DeviceListComponent, ExtendMeetingComponent, FooterComponent, HeaderComponent, LeftMenuComponent, LoginComponent, Notifications, PageSizeRenderComponent, PaginationRenderComponent, ProfileComponent, ResetpasswordComponent, SalesDashboardComponent, SearchRenderComponent, SettingsComponent, TripAddComponent, TripDetailComponent, TripListComponent, UserAddComponent, UserListComponent, AzureMapComponent, AdminDashboardComponent } from './components/index'
import { AuthService, DashboardService, DeviceService, LeftMenuService, NotificationService, SettingsService, TripService, UserService, ConfigService } from './services/index';




const config: SocketIoConfig = { url: 'http://localhost:2722', options: {} };
const MY_NATIVE_FORMATS = {
	parseInput: 'DD-MM-YYYY',
	fullPickerInput: 'DD-MM-YYYY hh:mm a',
	datePickerInput: 'DD-MM-YYYY',
	timePickerInput: 'HH:mm',
	monthYearLabel: 'MMM-YYYY',
	dateA11yLabel: 'HH:mm',
	monthYearA11yLabel: 'MMMM-YYYY'
};

@NgModule({
	declarations: [
		AppComponent,
		Notifications,
		PageNotFoundComponent,
		LoginComponent,
		HeaderComponent,
		FooterComponent,
		LeftMenuComponent,
		ExtendMeetingComponent,
		DashboardComponent,
		PageSizeRenderComponent,
		PaginationRenderComponent,
		SearchRenderComponent,
		ConfirmDialogComponent,
		DeleteDialogComponent,
		DeviceAddComponent,
		DeviceListComponent,
		UserAddComponent,
		UserListComponent,
		ResetpasswordComponent,
		ProfileComponent,
		SettingsComponent,
		TripAddComponent,
		TripListComponent,
		TripDetailComponent,
		AzureMapComponent,
		SalesDashboardComponent,
		AdminDashboardComponent
	],
	imports: [
		MatSelectModule,
		MatButtonModule,
		MatCheckboxModule,
		MatTabsModule,
		MatProgressBarModule,
		MatSlideToggleModule,
		MatInputModule,
		BrowserModule,
		TagInputModule,
		BrowserAnimationsModule,
		FormsModule,
		ReactiveFormsModule,
		AppRoutingModule,
		HttpModule,
		HttpClientModule,
		NgxSpinnerModule,
		NgxPaginationModule,
		OwlDateTimeModule,
		Ng2GoogleChartsModule,
		OwlNativeDateTimeModule,
		FullCalendarModule,
		SocketIoModule.forRoot(config),
		AgmCoreModule.forRoot({ apiKey: 'AIzaSyDf7yFrQU0RsJpULnEgj8wU6JlGNPeQ6k4' }),
		AgmJsMarkerClustererModule,
		AgmDirectionModule
	],
	providers: [
		AuthService,
		SettingsService,
		NotificationService,
		CookieService,
		UserService,
		DeviceService,
		TripService,
		LeftMenuService,
		DashboardService,
		ConfigService,
		{
			provide: DateTimeAdapter,
			useClass: MomentDateTimeAdapter,
			deps: [OWL_DATE_TIME_LOCALE]
		}, {
			provide: OWL_DATE_TIME_FORMATS,
			useValue: MY_NATIVE_FORMATS
		},
	],
	bootstrap: [AppComponent]
})

export class AppModule { }