import { Injectable } from '@angular/core'
import { CanActivate, Router } from '@angular/router'
import { CookieService } from 'ngx-cookie-service'

@Injectable({
	providedIn: 'root'
})

export class AuthService implements CanActivate {
	public cookieName = 'FM';
	constructor(private cookieService: CookieService, private router: Router) { }

	canActivate() {
		if (this.isCheckLogin()) {
			return true;
		} else {
			this.removeAllCookies();
			this.router.navigate(['/login']);
			return false;
		}
	}

	isCheckLogin() {
		if (this.cookieService.get(this.cookieName + 'access_token') !== '') {
			return true;
		} else {
			return false;
		}
	}

	removeAllCookies() {
		this.cookieService.deleteAll();
		localStorage.clear();
	}
}