import { Injectable } from '@angular/core'
import { CookieService } from 'ngx-cookie-service'
import { HttpClient } from '@angular/common/http'

import { environment } from './../../../environments/environment'

@Injectable()

export class UserService {
	cookieName = 'FM';

	constructor(private http: HttpClient, private cookieService: CookieService) { }

	getBasicToken() {
		return this.http.get<any>(environment.baseUrl + 'user/basic-token').map(response => {
			this.cookieService.set(this.cookieName + 'basic_token', response.data, 1, '/');
			return response;
		});
	}

	login(loginData) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Basic ' + this.cookieService.get(this.cookieName + 'basic_token')
			}
		};

		return this.http.post<any>(environment.baseUrl + 'user/login', loginData, configHeader).map(response => {
			this.cookieService.set(this.cookieName + 'access_token', response.access_token, 1, '/');
			this.cookieService.set(this.cookieName + 'refresh_token', response.refresh_token, 1, '/');
			return response;
		});
	}

	resetPassword(passwordData, basicToken) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Basic ' + basicToken
			}
		};

		return this.http.post<any>(environment.baseUrl + 'user/resetPassword', passwordData, configHeader).map(response => {
			return response;
		});
	}

	getUserInfo() {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.get(environment.baseUrl + 'user/info', configHeader).map(response => {
			return response;
		});
	}

	getCompanyRole() {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.get(environment.baseUrl + 'role', configHeader).map(response => {
			return response;
		});
	}

	getAccessRights() {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.get(environment.baseUrl + 'accessRights', configHeader).map(response => {
			return response;
		});
	}

	getCompanyUserInfo(userId) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.get(environment.baseUrl + 'companyInfo/' + userId, configHeader).map(response => {
			return response;
		});
	}

	getCountry() {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.get(environment.baseUrl + 'country', configHeader).map(response => {
			return response;
		});
	}

	getState(countryGuid) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.get(environment.baseUrl + 'country/' + countryGuid + '/state', configHeader).map(response => {
			return response;
		});
	}

	getEntity() {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.get(environment.baseUrl + 'entity', configHeader).map(response => {
			return response;
		});
	}

	getTimezone() {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.get(environment.baseUrl + 'timezone', configHeader).map(response => {
			return response;
		});
	}

	addUser(data) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.post(environment.baseUrl + 'user', data, configHeader).map(response => {
			return response;
		});
	}

	updateUser(userGuid, data) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.put<any>(environment.baseUrl + 'user/' + userGuid, data, configHeader).map(response => {
			return response;
		});
	}

	uploadPicture(userGuid, file) {
		var configHeader = {
			headers: {
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};
		const data = new FormData();
		data.append('profile_picture', file);

		return this.http.put<any>(environment.baseUrl + 'user/' + userGuid + '/image', data, configHeader).map(response => {
			return response;
		});
	}

	getUsers(parameters) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		const parameter = {
			params: {
				'pageNumber': parameters.pageNumber,
				'pageSize': parameters.pageSize,
				'searchText': parameters.searchText,
				'sortBy': parameters.sortBy
			},
			timestamp: Date.now()
		};
		var reqParameter = Object.assign(parameter, configHeader);

		return this.http.get<any>(environment.baseUrl + 'user', reqParameter).map(response => {
			return response;
		});
	}

	changeUserStatus(userGuid, data) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.put<any>(environment.baseUrl + 'user/' + userGuid + '/status', data, configHeader).map(response => {
			return response;
		});
	}

	deleteUser(userGuid) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.delete<any>(environment.baseUrl + 'user/' + userGuid, configHeader).map(response => {
			return response;
		});
	}

	getUserDetails(userGuid) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.get<any>(environment.baseUrl + 'user/' + userGuid, configHeader).map(response => {
			return response;
		});
	}

	getUserLookup() {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.get<any>(environment.baseUrl + 'users/lookup', configHeader).map(response => {
			return response;
		});
	}
	
	getVisitorLookup() {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.get<any>(environment.baseUrl + 'visitor/lookup', configHeader).map(response => {
			return response;
		});
	}

	updatePassword(data) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.post<any>(environment.baseUrl + 'user/change-password', data, configHeader).map(response => {
			return response;
		});
	}

	// Below Remaining to convert
	getBuildingList() {
		return this.http.get(environment.baseUrl + 'floor/building-list').map(res => {
			console.log("TCL: UserService -> updatePassword -> res", res)
		})
	}

	forgotPassword(data) {
		return this.http.post(environment.baseUrl + 'users/forgotPassword', data).map(res => {
			console.log("TCL: UserService -> updatePassword -> res", res)
		})
	}

	addDriver(data) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.post(environment.baseUrl + 'driver', data, configHeader).map(response => {
			return response;
		});
	}

	getDrivers(parameters) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		const parameter = {
			params: {
				'pageNumber': parameters.pageNumber,
				'pageSize': parameters.pageSize,
				'searchText': parameters.searchText,
				'sortBy': parameters.sortBy
			},
			timestamp: Date.now()
		};
		var reqParameter = Object.assign(parameter, configHeader);

		return this.http.get<any>(environment.baseUrl + 'driver', reqParameter).map(response => {
			return response;
		});
	}

	getDriverDetails(userGuid) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.get<any>(environment.baseUrl + 'driver/' + userGuid, configHeader).map(response => {
			return response;
		});
	}

	updateDriver(userGuid, data) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.put<any>(environment.baseUrl + 'driver/' + userGuid, data, configHeader).map(response => {
			return response;
		});
	}

	deleteDriver(userGuid) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.delete<any>(environment.baseUrl + 'driver/' + userGuid, configHeader).map(response => {
			return response;
		});
	}

	getDevice(hasDriver = false) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		const parameter = {
			params: {
				'hasDriver':hasDriver,
			},
			timestamp: Date.now()
		};
		var reqParameter = Object.assign(parameter, configHeader);

		return this.http.get(environment.baseUrl + 'device/lookup',reqParameter,).map(response => {
			return response;
		});
	}

	uploadImage(userGuid, file) {
		var configHeader = {
			headers: {
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};
		const data = new FormData();
		data.append('image', file);

		return this.http.put<any>(environment.baseUrl + 'driver/' + userGuid + '/image', data, configHeader).map(response => {
			return response;
		});
	}

	changeDriverStatus(userGuid, data) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.put<any>(environment.baseUrl + 'driver/' + userGuid + '/status', data, configHeader).map(response => {
			return response;
		});
	}
}