import { Injectable } from '@angular/core'
import { CookieService } from 'ngx-cookie-service'
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs/Observable'

import { environment } from './../../../environments/environment'

@Injectable({
	providedIn: 'root'
})

export class TripService {
	cookieName = 'FM';

	constructor(private http: HttpClient, private cookieService: CookieService, ) { }

	addTrip(data) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.post(environment.baseUrl + 'trip', data, configHeader).map(response => {
			return response;
		});
	}

	getTrips(parameters) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		const parameter = {
			params: {
				'pageNumber': parameters.pageNumber,
				'pageSize': parameters.pageSize,
				'searchText': parameters.searchText,
				'sortBy': parameters.sortBy
			},
			timestamp: Date.now()
		};
		var reqParameter = Object.assign(parameter, configHeader);

		return this.http.get<any>(environment.baseUrl + 'trips', reqParameter).map(response => {
			return response;
		});
	}

	updateTrip(guid, data) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.put<any>(environment.baseUrl + 'trip/' + guid, data, configHeader).map(response => {
			return response;
		});
	}

	getDetails(guid) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.get<any>(environment.baseUrl + 'trip/' + guid, configHeader).map(response => {
			return response;
		});
	}

	getDuration(from,to) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.get<any>(environment.baseUrl + 'trip/getDuration/' + from+'/'+to, configHeader).map(response => {
			return response;
		});
	}

	

	deleteTrip(guid) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.delete<any>(environment.baseUrl + 'trip/' + guid, configHeader).map(response => {
			return response;
		});
	}

	getLocation(address): Observable<any> {
		return this.http.get<any>('https://maps.googleapis.com/maps/api/geocode/json?address=' + address + '&key=AIzaSyDf7yFrQU0RsJpULnEgj8wU6JlGNPeQ6k4').map(response => {
			return response.results;
		});
	}

	getGeoCoordinates(origin,destination) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.http.get<any>(environment.baseUrl + 'trip/getGeoCoordinates/' + origin+'/'+destination, configHeader).map(response => {
			return response;
		});
	}
}