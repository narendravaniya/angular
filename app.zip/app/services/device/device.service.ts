import 'rxjs/add/operator/map'

import { Injectable } from '@angular/core'
import { HttpClient } from '@angular/common/http'
import { CookieService } from 'ngx-cookie-service'

import { environment } from './../../../environments/environment'

@Injectable({
	providedIn: 'root'
})

export class DeviceService {
	cookieName = 'FM';

	constructor(
		private cookieService: CookieService,
		private httpClient: HttpClient
	) { }

	getTemplateLookup() {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.httpClient.get<any>(environment.baseUrl + 'device/template/lookup', configHeader).map(response => {
			return response;
		});
	}

	addDevice(data) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.httpClient.post<any>(environment.baseUrl + 'device/', data, configHeader).map(response => {
			return response;
		});
	}

	getDevices(parameters) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		const parameter = {
			params: {
				'pageNumber': parameters.pageNumber,
				'pageSize': parameters.pageSize,
				'searchText': parameters.searchText,
				'sortBy': parameters.sortBy
			},
			timestamp: Date.now()
		};
		var reqParameter = Object.assign(parameter, configHeader);

		return this.httpClient.get<any>(environment.baseUrl + 'device', reqParameter).map(response => {
			return response;
		});
	}

	changeDeviceStatus(deviceGuid, data) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.httpClient.put<any>(environment.baseUrl + 'device/' + deviceGuid + '/status', data, configHeader).map(response => {
			return response;
		});
	}

	deleteDevice(deviceGuid) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.httpClient.delete<any>(environment.baseUrl + 'device/' + deviceGuid, configHeader).map(response => {
			return response;
		});
	}

	uploadPicture(deviceGuid, file) {
		var configHeader = {
			headers: {
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};
		const data = new FormData();
		data.append('image', file);

		return this.httpClient.put<any>(environment.baseUrl + 'device/' + deviceGuid + '/image', data, configHeader).map(response => {
			return response;
		});
	}

	getSelectdFloorSpace(floorGuid) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.httpClient.get<any>(environment.baseUrl + 'floor/' + floorGuid + '/space', configHeader).map(response => {
			return response;
		});
	}

	getDeviceDetails(deviceGuid) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.httpClient.get<any>(environment.baseUrl + 'device/' + deviceGuid, configHeader).map(response => {
			return response;
		});
	}

	getTabletDetails(guid) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.httpClient.get<any>(environment.baseUrl + 'space-tablet/' + guid, configHeader).map(response => {
			return response;
		});
	}

	updateTabletmapping(guid, data) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.httpClient.put<any>(environment.baseUrl + 'space-tablet/' + guid, data, configHeader).map(response => {
			return response;
		});
	}

	updateDevice(deviceGuid, data) {
		var configHeader = {
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + this.cookieService.get(this.cookieName + 'access_token')
			}
		};

		return this.httpClient.put<any>(environment.baseUrl + 'device/' + deviceGuid, data, configHeader).map(response => {
			return response;
		});
	}
}