
'use strict';
var jwt    = require('jsonwebtoken');
var verifyToken = function (token, callback) {
var authorization = token;
var items = authorization.split(/[ ]+/);

if (items.length > 1 && items[0].trim() == "Bearer") {
    var token = items[1];
jwt.verify(token, 'worldisfullofdevelopers', (err, decoded) => {
 if (!err) {

            callback(null, decoded)
        }
        else {
            callback(err, null)
        }
//console.log("this err...",err);
//console.log("this decoded...",decoded);
});
    // verify token
}
//console.log("this header",headers);
/*
    iotSDK.AuthSDK.verifyToken(headers, function (err, response, body) {
        if (!err) {

            callback(null, body)
        }
        else {
            callback(err, null)
        }
    });
\*/
};

/**
 * @title: Validation error message
 * @description: This will make error json error object with params and messages object 
 * @param: errors  
 * @param: callback
 */
var setValidationError = function (errors, callback) {
    var err = [];
    var errorsObject = Object.keys(errors).map(function (obj) {
        var errObj = errors[obj];
        delete errObj.location;
        delete errObj.value;
        err.push(errObj);
    });
    return callback({
        status: '412',
        message: 'validation faild',
        error: err,
    });
};


module.exports = {
    verifyToken: verifyToken,
    setValidationError: setValidationError
}
