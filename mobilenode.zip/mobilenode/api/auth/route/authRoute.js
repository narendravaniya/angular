/**
 * @module: Auth Module
 * @description: 
 * - Define all the routes of Auth Module
 */
'use strict';

var authController = require('../controller/authController');
//var multipart = require('connect-multiparty');
//var multipartMiddleware = multipart();

module.exports = function(app) {
    /**
     * @swagger
     * /api/auth/signin:
     *   post:
     *     description: Get New Tokens
     *     tags:
     *       - Auth
     *     produces:
     *       - application/x-www-form-urlencoded
     *     parameters:
     *       - name: body
     *         in: body
     *         description: json object used as input
     *         required: true
     *         schema:
     *           type: object
     *           properties:
     *             email:
     *               type: string
     *             password:
     *               type: string
     *           example: {"email":"","password":""}
     *     responses:
     *       200:
     *         description: It will generating new tokens.
     *         schema:
     *           type: object
     *           example: {"token_type": "","access_token": "","expires_in":"","refresh_token": ""}
     *       401:
     *         description: Not authorised
     *         schema:
     *           type: object
     *           properties:
     *             status:
     *               type: integer
     *               example: 401
     *             error:
     *               type: array
     *               example: []
     *             message:
     *               type: string
     *               example: ""
     */
    app.post('/api/auth/signin', authController.signIn);

    

};
