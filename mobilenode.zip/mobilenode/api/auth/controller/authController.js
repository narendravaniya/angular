/**
 * @module: Auth Management
 * @author: Narendra
 * @description: 
 * - Get Basic token
 * - 
 */
'use strict';
var jwt    = require('jsonwebtoken');
var request = require('request');
var commonMethods = require('/var/www/html/mobilenode/common/commonMethods');
var mappedErrors;
/**
 * @description User Login
 * @method Post
 * @param {req} req
 * @param {res} res
 * @author Narendra Vaniya
 */
exports.signIn = function (req, res) {
 if (req.body != "") {
        //req.sanitize('username').trim();
        req.checkBody('email', 'email is required').notEmpty();
        req.checkBody('email', 'Please enter a valid email address').isEmail();
	req.checkBody('password', 'password is required').notEmpty();
        mappedErrors = req.validationErrors(true);
    }
 if (mappedErrors == false) {
   var userData = req.body;
const payload = userData;
        var token = jwt.sign(payload, 'worldisfullofdevelopers', {
           expiresIn : 20     
        });
res.json({
          success: true,
          message: 'Enjoy your token!',
          token: token
        });
   console.log("i am here....",token);
}else {
        commonMethods.setValidationError(mappedErrors, function (response) {
            res.status(response.status).json(response);
        });
    }
};
