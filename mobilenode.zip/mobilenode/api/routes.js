/**
 * @module: Main Route for Web Services
 * @author: SOFTWEB-Narendra
 * @description:
 * - Initial defination for the Swagger Documentation
 * - Define the base routes for all the modules under
 */
'use strict';


var commonMethods = require('../common/commonMethods');

module.exports = function (app) {
	// Varify Token
	app.all('/api/*', function (req, res, next) {
		var token = '';
		if (req.headers.authorization) {
			token = req.headers.authorization
		}
		var allowerdRouteArray = ['/api/auth/signin'
		];
		if (allowerdRouteArray.indexOf(req.path) == -1) {
			if (token == '') {
				res.json({
					"status": 401,
					"error": [
						{
							"params": "OAuth",
							"message": "No token supplied"
						}
					],
					"message": "No token supplied"
				});
			} else {
				commonMethods.verifyToken(token, function (err, result) {


					if (!err) {
console.log("i am here.....");
/*
						if (result.status == 200) {
							next()
						} else {
							res.status(result.status).json(result);
						} */
					} else {
						var error = [{
							params: err.name,
							message: err.message
						}];
						res.status(500).json({
							"status": 500,
							"error": error,
							"message": "Unable to connect"
						});
					}

				});
			}
		} else {
			next();
		}
	});



	//Define the routes for all the modules

	//  Auth Module
	var authRoute = require('../api/auth/route/authRoute.js');
	new authRoute(app);

	

};
