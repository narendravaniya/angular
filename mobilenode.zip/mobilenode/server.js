var express = require("express");
var bodyParser = require("body-parser");
var mysql = require('mysql');
var app = express();
var jwt    = require('jsonwebtoken');
var path = require('path');
var expressValidator = require('express-validator');
app.use(expressValidator());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use(function (req, res, next) {
	
    // Website you wish to allow to connect
    res.header('Access-Control-Allow-Origin', '*');

    // Request methods you wish to allow
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.header('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.header('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
});

/*Define the Web services server initial part*/
var router = require('./api/routes');
router(app);

//module.exports = app;
app.listen(8000, function () {
    console.log('Example app listening on port 8000!')
})

var swaggerRoute = [
   './api/auth/route/authRoute.js'
];

// ***** Start Swagger ***** //
var swaggerJSDoc = require('swagger-jsdoc');
var swaggerDefinition = {
        info: {
                title: 'Api Docs',
                version: '1.0.0'
        },
        host: '192.168.3.197:8000',
        basePath: '/',
};
var options = {
        swaggerDefinition: swaggerDefinition,
        apis: swaggerRoute //Add modules here for api docs
};
var swaggerSpec = swaggerJSDoc(options);
app.get('/swagger.json', function(req, res) {
        res.setHeader('Content-Type', 'application/json');
        res.send(swaggerSpec);
});

app.use(express.static(path.join(__dirname, '/swagger-ui')));

